"use strict";

/**
 * POST /verifyDonation (admin) — marks a donation verified and
 * regenerates the receipt as a definitive PDF (logo instead of a blank
 * signature line — see receiptPdf.js), stored on Cloudinary.
 *
 * For a gala ticket (kind "billet") it ALSO generates the access badge
 * (lib/badgePdf.js) and stores its link as `badgePdfUrl`; the admin sends
 * the badge the same way as the receipt (e-mail or WhatsApp). No badge for
 * donations or sponsoring.
 *
 * No automatic email: the association wants full
 * manual control over how each definitive receipt actually reaches the
 * donor: DonationsReviewPanel.tsx shows the generated `receiptPdfUrl`
 * with two ready-made options once this returns —
 *  - a mailto: link (opens the ADMIN's own email app, prefilled with the
 *    donor's address, subject and a body containing the receipt link)
 *  - a wa.me link with no phone number (opens WhatsApp's own contact
 *    picker so the admin can choose who to send it to), prefilled with a
 *    message containing the same receipt link
 * Both are just prefilled drafts in the admin's own apps — nothing is
 * sent by this server either way, and the PDF itself is identical
 * regardless of which one they pick.
 */

const { getDb, admin } = require("./lib/firebaseAdmin");
const { json, handlePreflight, requireAdminAuth, parseBody } = require("./lib/http");
const { uploadBuffer } = require("./lib/cloudinaryStorage");
const { generateDefinitiveReceiptPdf, detectReceiptKind } = require("./lib/receiptPdf");
const { generateBadgePdf } = require("./lib/badgePdf");
const { readSiteConfig } = require("./lib/siteConfig");

async function uploadReceiptPdf(receiptId, bytes) {
  const result = await uploadBuffer(Buffer.from(bytes), {
    folder: "ugd/receipts",
    publicId: receiptId,
    resourceType: "raw",
  });
  return result.secure_url;
}

async function uploadBadgePdf(ticketId, bytes) {
  const result = await uploadBuffer(Buffer.from(bytes), {
    folder: "ugd/badges",
    publicId: ticketId,
    resourceType: "raw",
  });
  return result.secure_url;
}

/** Builds the badge for a gala ticket, uploads it and returns its URL. */
async function createBadge(db, donation, lang) {
  const config = await readSiteConfig(db).catch(() => null);
  const jmsa = (config && config.jmsaConfig) || {};
  const badgeBytes = await generateBadgePdf(
    {
      ticketId: donation.receiptId,
      fullName: donation.donorName,
      ticketName: donation.ticketName || donation.context,
      eventShortTitle: jmsa.shortTitle,
      eventFullName: jmsa.eventName,
      eventDates: jmsa.dateRange,
      location: jmsa.location,
    },
    lang,
  );
  return uploadBadgePdf(donation.receiptId, badgeBytes);
}

exports.handler = async (event) => {
  const preflight = handlePreflight(event);
  if (preflight) return preflight;
  if (event.httpMethod !== "POST") {
    return json(405, { ok: false, error: "Méthode non autorisée." });
  }
  const auth = await requireAdminAuth(event);
  if (auth.error) return auth.error;

  try {
    const body = parseBody(event);
    const id = String(body.id || "").trim();
    const actorEmail = auth.email; // verified identity, not the client-supplied body value
    if (!id) {
      return json(400, { ok: false, error: "id manquant." });
    }

    const db = getDb();
    const ref = db.collection("donations").doc(id);
    const snap = await ref.get();
    if (!snap.exists) {
      return json(404, { ok: false, error: "Don introuvable." });
    }
    const donation = snap.data();
    const isTicket = (donation.kind || detectReceiptKind(donation.context)) === "billet";
    if (donation.status === "verifie") {
      // A ticket verified before badges existed has none yet: create it now
      // (the admin panel offers "Générer le badge" for exactly that case).
      let existingBadgeUrl = donation.badgePdfUrl || null;
      if (isTicket && !existingBadgeUrl) {
        existingBadgeUrl = await createBadge(db, donation, donation.lang === "en" ? "en" : "fr");
        await ref.update({ badgePdfUrl: existingBadgeUrl });
      }
      return json(200, {
        ok: true,
        id,
        alreadyVerified: true,
        receiptPdfUrl: donation.receiptPdfUrl || null,
        badgePdfUrl: existingBadgeUrl,
      });
    }

    const donationLang = donation.lang === "en" ? "en" : "fr";
    const dateLocale = donationLang === "en" ? "en-GB" : "fr-BE";
    const now = new Date();
    const dateLabel = now.toLocaleDateString(dateLocale);

    const pdfBytes = await generateDefinitiveReceiptPdf(
      {
        receiptId: donation.receiptId,
        donorName: donation.donorName,
        donorEmail: donation.email || undefined,
        amount: donation.amount,
        currency: donation.currency,
        method: donation.method,
        purpose: donation.context,
        dateLabel: donation.clientCreatedAt
          ? new Date(donation.clientCreatedAt).toLocaleDateString(dateLocale)
          : dateLabel,
        verifiedBy: actorEmail,
        verifiedDateLabel: dateLabel,
      },
      donationLang,
    );

    const receiptPdfUrl = await uploadReceiptPdf(id, pdfBytes);

    // The access badge exists ONLY for a verified gala ticket (billet): it
    // is created here, at the moment the admin confirms the payment, and
    // its QR code carries the ticket reference the door scanner checks.
    // Sponsoring and donations get a receipt only.
    let badgePdfUrl = null;
    if (isTicket) {
      badgePdfUrl = await createBadge(db, donation, donationLang);
    }

    await ref.update({
      status: "verifie",
      verifiedAt: admin.firestore.FieldValue.serverTimestamp(),
      verifiedBy: actorEmail,
      receiptPdfUrl,
      ...(isTicket ? { badgePdfUrl, checkedIn: false, checkedInAt: null, checkedInBy: null } : {}),
    });

    return json(200, { ok: true, id, receiptPdfUrl, badgePdfUrl });
  } catch (err) {
    console.error("verifyDonation failed", err);
    return json(500, { ok: false, error: "Erreur serveur." });
  }
};
