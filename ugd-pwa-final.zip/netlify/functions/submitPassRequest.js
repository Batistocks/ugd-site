"use strict";

/**
 * POST /submitPassRequest (public) — receives a JMSA 2026 registration
 * from PassRequestForm.tsx and writes it to Firestore (`registrations`
 * collection). Rejected while the "jmsa-2026" space is disabled (see
 * getSpaces.js) so a stale deep-link can't register someone after the
 * event has been closed. Netlify Functions port of the Cloud Function
 * of the same name in functions/index.js.
 */

const { getDb, admin } = require("./lib/firebaseAdmin");
const { json, handlePreflight, parseBody } = require("./lib/http");
const { readSiteConfig, isSpaceEnabled } = require("./lib/siteConfig");
const { toInternationalNumber, isValidEmail, clip } = require("./lib/phone");
const { checkRateLimit } = require("./lib/rateLimit");

exports.handler = async (event) => {
  const preflight = handlePreflight(event);
  if (preflight) return preflight;
  if (event.httpMethod !== "POST") {
    return json(405, { ok: false, error: "Méthode non autorisée." });
  }

  try {
    if (!(await checkRateLimit(event, "submitPassRequest", { max: 8, windowSeconds: 600 }))) {
      return json(429, { ok: false, error: "Trop de demandes depuis cette connexion. Réessayez dans quelques minutes." });
    }

    const body = parseBody(event);
    const registrationId = clip(body.registrationId, 64);
    const fullName = clip(body.fullName, 120);
    const email = clip(body.email, 254);

    if (!registrationId || !fullName || !email) {
      return json(400, { ok: false, error: "Champs requis manquants (registrationId, fullName, email)." });
    }

    if (!isValidEmail(email)) {
      return json(400, { ok: false, error: "Adresse e-mail invalide." });
    }

    // WhatsApp number mandatory, with country code (enforced here too, not only in the form).
    const phone = toInternationalNumber(body.phone);
    if (!phone) {
      return json(400, { ok: false, error: "Un numéro WhatsApp valide avec indicatif du pays (ex. +32…) est requis." });
    }

    const db = getDb();
    const config = await readSiteConfig(db);
    if (!isSpaceEnabled(config, "jmsa-2026")) {
      return json(403, { ok: false, error: "Les inscriptions JMSA 2026 sont actuellement fermées.", closed: true });
    }

    const ref = db.collection("registrations").doc(registrationId);
    const existing = await ref.get();
    if (existing.exists) {
      // Idempotent, same reasoning as submitProof: the offline sync queue
      // may retry a mutation more than once.
      return json(200, { ok: true, id: registrationId, alreadyExists: true });
    }

    const doc = {
      registrationId,
      fullName,
      email: email || null,
      phone,
      organization: clip(body.organization, 160) || null,
      day: clip(body.day, 120) || null,
      ticketType: clip(body.ticketType, 120) || null,
      lang: body.lang === "en" ? "en" : "fr",
      status: "inscrit",
      checkedIn: false,
      checkedInAt: null,
      checkedInBy: null,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      clientCreatedAt: body.createdAt || null,
    };

    try {
      // create() fails if the document already exists: no duplicate even
      // when two retries of the same mutation arrive at the same instant.
      await ref.create(doc);
    } catch (err) {
      if (err && (err.code === 6 || /already exists/i.test(String(err.message)))) {
        return json(200, { ok: true, id: registrationId, alreadyExists: true });
      }
      throw err;
    }
    return json(200, { ok: true, id: registrationId });
  } catch (err) {
    console.error("submitPassRequest failed", err);
    return json(500, { ok: false, error: "Erreur serveur." });
  }
};
