"use strict";

/**
 * GET /listRegistrations (admin) — lists registrations for the admin
 * "Inscriptions" panel. Netlify Functions port of the Cloud Function of
 * the same name in functions/index.js.
 */

const { getDb } = require("./lib/firebaseAdmin");
const { json, handlePreflight, requireAdminAuth } = require("./lib/http");

exports.handler = async (event) => {
  const preflight = handlePreflight(event);
  if (preflight) return preflight;
  const auth = await requireAdminAuth(event);
  if (auth.error) return auth.error;

  try {
    const checkedInParam = event.queryStringParameters ? event.queryStringParameters.checkedIn : null;
    const db = getDb();
    let query = db.collection("registrations").orderBy("createdAt", "desc").limit(500);
    if (checkedInParam === "true" || checkedInParam === "false") {
      query = db
        .collection("registrations")
        .where("checkedIn", "==", checkedInParam === "true")
        .orderBy("createdAt", "desc")
        .limit(500);
    }

    const snapshot = await query.get();
    const items = snapshot.docs.map((d) => {
      const data = d.data();
      return {
        ...data,
        createdAt: data.createdAt ? data.createdAt.toMillis() : null,
        checkedInAt: data.checkedInAt ? data.checkedInAt.toMillis() : null,
      };
    });
    return json(200, { ok: true, items });
  } catch (err) {
    console.error("listRegistrations failed", err);
    return json(500, { ok: false, error: "Erreur serveur." });
  }
};
