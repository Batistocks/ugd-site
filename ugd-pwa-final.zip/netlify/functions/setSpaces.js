"use strict";

/**
 * POST /setSpaces (admin) — persists an updated { spaces, jmsaConfig,
 * flyers, speakers, bank }. Netlify Functions port of the Cloud
 * Function of the same name in functions/index.js.
 */

const { getDb, admin } = require("./lib/firebaseAdmin");
const { json, handlePreflight, requireAdminAuth, parseBody } = require("./lib/http");
const { readSiteConfig, settingsDoc, normalizeImpact } = require("./lib/siteConfig");

exports.handler = async (event) => {
  const preflight = handlePreflight(event);
  if (preflight) return preflight;
  if (event.httpMethod !== "POST") {
    return json(405, { ok: false, error: "Méthode non autorisée." });
  }
  const auth = await requireAdminAuth(event);
  if (auth.error) return auth.error;

  try {
    const body = parseBody(event);
    const spaces = Array.isArray(body.spaces) ? body.spaces : null;
    const jmsaConfig = body.jmsaConfig && typeof body.jmsaConfig === "object" ? body.jmsaConfig : null;
    const flyers = Array.isArray(body.flyers) ? body.flyers : null;
    const speakers = Array.isArray(body.speakers) ? body.speakers : null;
    const mediaPhotos = Array.isArray(body.mediaPhotos) ? body.mediaPhotos : null;
    const mediaVideos = Array.isArray(body.mediaVideos) ? body.mediaVideos : null;
    const fixedTabs = body.fixedTabs && typeof body.fixedTabs === "object" ? body.fixedTabs : null;
    const bank = body.bank && typeof body.bank === "object" ? body.bank : null;
    const documents = body.documents && typeof body.documents === "object" ? body.documents : null;
    const impact = body.impact && typeof body.impact === "object" ? body.impact : null;
    if (!spaces && !jmsaConfig && !flyers && !speakers && !mediaPhotos && !mediaVideos && !fixedTabs && !bank && !documents && !impact) {
      return json(400, { ok: false, error: "spaces, jmsaConfig, flyers, speakers, mediaPhotos, mediaVideos, fixedTabs, bank, documents ou impact requis." });
    }

    const db = getDb();
    const current = await readSiteConfig(db);
    const next = {
      spaces: spaces || current.spaces,
      jmsaConfig: jmsaConfig ? { ...current.jmsaConfig, ...jmsaConfig } : current.jmsaConfig,
      flyers: flyers || current.flyers,
      speakers: speakers || current.speakers,
      mediaPhotos: mediaPhotos || current.mediaPhotos,
      mediaVideos: mediaVideos || current.mediaVideos,
      fixedTabs: fixedTabs
        ? {
            accueil: { ...current.fixedTabs.accueil, ...(fixedTabs.accueil || {}) },
            contact: { ...current.fixedTabs.contact, ...(fixedTabs.contact || {}) },
          }
        : current.fixedTabs,
      bank: bank ? { ...current.bank, ...bank } : current.bank,
      documents: documents || current.documents,
      impact: impact ? normalizeImpact(impact) : current.impact,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedBy: auth.email,
    };
    await settingsDoc(db).set(next, { merge: true });

    return json(200, {
      ok: true,
      spaces: next.spaces,
      jmsaConfig: next.jmsaConfig,
      flyers: next.flyers,
      speakers: next.speakers,
      mediaPhotos: next.mediaPhotos,
      mediaVideos: next.mediaVideos,
      fixedTabs: next.fixedTabs,
      bank: next.bank,
      documents: next.documents,
      impact: next.impact,
    });
  } catch (err) {
    console.error("setSpaces failed", err);
    return json(500, { ok: false, error: "Erreur serveur." });
  }
};
