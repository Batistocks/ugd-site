"use strict";

/**
 * GET /listDonations (admin) — lists donations for the admin review
 * panel, filterable by status. Netlify Functions port of the Cloud
 * Function of the same name in functions/index.js.
 */

const { getDb } = require("./lib/firebaseAdmin");
const { json, handlePreflight, requireAdminAuth } = require("./lib/http");

exports.handler = async (event) => {
  const preflight = handlePreflight(event);
  if (preflight) return preflight;
  const auth = await requireAdminAuth(event);
  if (auth.error) return auth.error;

  try {
    const status = event.queryStringParameters ? event.queryStringParameters.status : null;
    const db = getDb();
    let query = db.collection("donations").orderBy("createdAt", "desc").limit(200);
    if (status) {
      query = db.collection("donations").where("status", "==", status).orderBy("createdAt", "desc").limit(200);
    }

    const snapshot = await query.get();
    const items = snapshot.docs.map((d) => {
      const data = d.data();
      return {
        ...data,
        createdAt: data.createdAt ? data.createdAt.toMillis() : null,
        verifiedAt: data.verifiedAt ? data.verifiedAt.toMillis() : null,
        checkedInAt: data.checkedInAt ? data.checkedInAt.toMillis() : null,
      };
    });
    return json(200, { ok: true, items });
  } catch (err) {
    console.error("listDonations failed", err);
    return json(500, { ok: false, error: "Erreur serveur." });
  }
};
