"use strict";

/**
 * POST /submitProof (public) — receives a donation/sponsoring transfer
 * proof from the PWA and writes it to Firestore (`donations` collection,
 * status "en_attente"). Netlify Functions port of the Cloud Function of
 * the same name in functions/index.js — same logic, Cloudinary instead
 * of Firebase Storage for the proof file.
 */

const { getDb, admin } = require("./lib/firebaseAdmin");
const { json, handlePreflight, parseBody } = require("./lib/http");
const { decodeDataUrl, resourceTypeForMime, uploadBuffer } = require("./lib/cloudinaryStorage");
const { detectReceiptKind } = require("./lib/receiptPdf");
const { toInternationalNumber, isValidEmail, clip } = require("./lib/phone");
const { checkRateLimit } = require("./lib/rateLimit");

// The client caps proofs at 2 MB (images are compressed first); base64 adds
// ~33%, and we leave some margin: 3 MB of decoded file at most.
const MAX_PROOF_BYTES = 3 * 1024 * 1024;
const MAX_BODY_CHARS = 5 * 1024 * 1024; // raw JSON body (data URL included)

async function uploadProofFile(receiptId, dataUrl) {
  const decoded = decodeDataUrl(dataUrl);
  if (!decoded) return null;
  if (decoded.buffer.byteLength > MAX_PROOF_BYTES) {
    throw new Error("Fichier de preuve trop volumineux.");
  }
  const result = await uploadBuffer(decoded.buffer, {
    folder: "ugd/proofs",
    publicId: receiptId,
    resourceType: resourceTypeForMime(decoded.mime),
  });
  return { url: result.secure_url, mime: decoded.mime };
}

exports.handler = async (event) => {
  const preflight = handlePreflight(event);
  if (preflight) return preflight;
  if (event.httpMethod !== "POST") {
    return json(405, { ok: false, error: "Méthode non autorisée." });
  }

  try {
    if (event.body && event.body.length > MAX_BODY_CHARS) {
      return json(413, { ok: false, error: "Fichier de preuve trop volumineux (2 Mo maximum)." });
    }
    if (!(await checkRateLimit(event, "submitProof", { max: 8, windowSeconds: 600 }))) {
      return json(429, { ok: false, error: "Trop de demandes depuis cette connexion. Réessayez dans quelques minutes." });
    }

    const body = parseBody(event);
    const receiptId = clip(body.receiptId, 64);
    const donorName = clip(body.donorName, 120);
    const amount = clip(body.amount, 20);

    if (!receiptId || !donorName || !amount) {
      return json(400, { ok: false, error: "Champs requis manquants (receiptId, donorName, amount)." });
    }

    const kind = detectReceiptKind(body.context);
    const email = clip(body.email, 254);
    if (email && !isValidEmail(email)) {
      return json(400, { ok: false, error: "Adresse e-mail invalide." });
    }
    if (!(Number(amount) > 0)) {
      return json(400, { ok: false, error: "Montant invalide." });
    }
    const rawPhone = String(body.phone || "").trim();
    const phone = toInternationalNumber(rawPhone) || "";

    // A gala ticket (billet) is delivered on WhatsApp once the payment is
    // verified: a number with its country code is mandatory.
    if (kind === "billet" && !phone) {
      return json(400, { ok: false, error: "Un numéro WhatsApp valide avec indicatif du pays (ex. +32…) est requis pour recevoir le ticket." });
    }

    const db = getDb();
    const ref = db.collection("donations").doc(receiptId);
    const existing = await ref.get();
    if (existing.exists) {
      // Idempotent: the sync queue may retry the same mutation more than
      // once (e.g. connection drop mid-request) — don't create duplicates.
      return json(200, { ok: true, id: receiptId, alreadyExists: true });
    }

    let proof = null;
    if (body.proofDataUrl) {
      proof = await uploadProofFile(receiptId, body.proofDataUrl);
    }

    const doc = {
      receiptId,
      donorName,
      email: email || null,
      phone: phone || null,
      amount,
      currency: body.currency || "EUR",
      method: clip(body.method, 60) || null,
      context: clip(body.context, 160) || "Don",
      kind,
      // Ticket category chosen in the Billetterie (e.g. "VIP Or") — printed on the badge.
      ticketName: kind === "billet" ? clip(body.ticketName, 120) || null : null,
      checkedIn: false,
      checkedInAt: null,
      checkedInBy: null,
      badgePdfUrl: null,
      lang: body.lang === "en" ? "en" : "fr",
      proofFileName: clip(body.proofFileName, 160) || null,
      proofUrl: proof ? proof.url : null,
      proofStoragePath: null, // Cloudinary: the URL alone is the reference now
      status: "en_attente",
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      clientCreatedAt: body.createdAt || null,
      verifiedAt: null,
      verifiedBy: null,
      receiptPdfUrl: null,
    };

    try {
      // create() = atomic "only if absent" (see submitPassRequest.js).
      await ref.create(doc);
    } catch (err) {
      if (err && (err.code === 6 || /already exists/i.test(String(err.message)))) {
        return json(200, { ok: true, id: receiptId, alreadyExists: true });
      }
      throw err;
    }
    return json(200, { ok: true, id: receiptId });
  } catch (err) {
    console.error("submitProof failed", err);
    return json(500, { ok: false, error: "Erreur serveur." });
  }
};
