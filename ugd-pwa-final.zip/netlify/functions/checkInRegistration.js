"use strict";

/**
 * POST /checkInRegistration (admin) — marks someone checked in at the
 * door (QR scanner / manual id), verified against the real Firestore
 * lists rather than just a local duplicate-scan guard. A scanned badge is
 * matched to a VERIFIED gala ticket (`donations`, kind "billet"); a plain
 * summit registration id (manual pointage from the Inscriptions panel) is
 * matched to `registrations`. Netlify
 * Functions port of the Cloud Function of the same name in
 * functions/index.js.
 */

const { getDb, admin } = require("./lib/firebaseAdmin");
const { json, handlePreflight, requireAdminAuth, parseBody } = require("./lib/http");
const { detectReceiptKind } = require("./lib/receiptPdf");

exports.handler = async (event) => {
  const preflight = handlePreflight(event);
  if (preflight) return preflight;
  if (event.httpMethod !== "POST") {
    return json(405, { ok: false, error: "Méthode non autorisée." });
  }
  const auth = await requireAdminAuth(event);
  if (auth.error) return auth.error;

  try {
    const body = parseBody(event);
    const id = String(body.id || "").trim();
    const actorEmail = auth.email; // verified identity, not the client-supplied body value
    if (!id) {
      return json(400, { ok: false, error: "id manquant." });
    }

    const db = getDb();

    // Everything runs in ONE transaction: two scanners reading the same
    // badge at the same instant can't both "check it in" — the second one
    // is retried by Firestore, sees checkedIn = true, and gets the
    // "already checked in" answer.
    const outcome = await db.runTransaction(async (tx) => {
      // 1) Gala ticket — the only thing that comes with a badge. The id read
      //    from the badge's QR code is the ticket reference (donations/<id>);
      //    it is accepted only once the payment has been verified.
      const ticketRef = db.collection("donations").doc(id);
      const ticketSnap = await tx.get(ticketRef);
      if (ticketSnap.exists) {
        const ticket = ticketSnap.data();
        const kind = ticket.kind || detectReceiptKind(ticket.context);
        if (kind !== "billet") {
          // A sponsoring/donation receipt number is not an entrance ticket.
          return { status: 404, body: { ok: false, error: "Ce numéro n'est pas un billet de gala.", notFound: true } };
        }
        if (ticket.status !== "verifie") {
          return {
            status: 402,
            body: {
              ok: false,
              error: "Paiement non vérifié : ce billet n'a pas encore été validé.",
              notPaid: true,
              fullName: ticket.donorName,
            },
          };
        }
        if (ticket.checkedIn) {
          return {
            status: 200,
            body: {
              ok: true,
              id,
              alreadyCheckedIn: true,
              fullName: ticket.donorName,
              checkedInAt: ticket.checkedInAt ? ticket.checkedInAt.toMillis() : null,
              checkedInBy: ticket.checkedInBy,
            },
          };
        }
        tx.update(ticketRef, {
          checkedIn: true,
          checkedInAt: admin.firestore.FieldValue.serverTimestamp(),
          checkedInBy: actorEmail,
        });
        return { status: 200, body: { ok: true, id, fullName: ticket.donorName, ticketName: ticket.ticketName || null } };
      }

      // 2) Summit registration (manual attendance list in the "Inscriptions"
      //    panel — registrations get no badge).
      const ref = db.collection("registrations").doc(id);
      const snap = await tx.get(ref);
      if (!snap.exists) {
        return { status: 404, body: { ok: false, error: "Inscription introuvable.", notFound: true } };
      }
      const registration = snap.data();
      if (registration.checkedIn) {
        return {
          status: 200,
          body: {
            ok: true,
            id,
            alreadyCheckedIn: true,
            fullName: registration.fullName,
            checkedInAt: registration.checkedInAt ? registration.checkedInAt.toMillis() : null,
            checkedInBy: registration.checkedInBy,
          },
        };
      }
      tx.update(ref, {
        checkedIn: true,
        checkedInAt: admin.firestore.FieldValue.serverTimestamp(),
        checkedInBy: actorEmail,
      });
      return { status: 200, body: { ok: true, id, fullName: registration.fullName } };
    });

    return json(outcome.status, outcome.body);
  } catch (err) {
    console.error("checkInRegistration failed", err);
    return json(500, { ok: false, error: "Erreur serveur." });
  }
};
