"use strict";

/**
 * GET /getSpaces (public) — returns { spaces, jmsaConfig, flyers,
 * speakers, bank } read by every visitor's browser on load. Netlify
 * Functions port of the Cloud Function of the same name in
 * functions/index.js.
 */

const { getDb } = require("./lib/firebaseAdmin");
const { json, handlePreflight } = require("./lib/http");
const { readSiteConfig } = require("./lib/siteConfig");

exports.handler = async (event) => {
  const preflight = handlePreflight(event);
  if (preflight) return preflight;

  try {
    const config = await readSiteConfig(getDb());
    return json(200, { ok: true, ...config });
  } catch (err) {
    console.error("getSpaces failed", err);
    return json(500, { ok: false, error: "Erreur serveur." });
  }
};
