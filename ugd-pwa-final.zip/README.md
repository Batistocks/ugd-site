# UGD — Un Geste Divin — PWA

Codebase de l'application PWA pour l'AISBL UN GESTE DIVIN.

Ce livrable couvre les **Sections 1 à 5** du cahier des charges :

## Section 1 — Design System, Header & Hamburger Navigation
- `src/constants/theme.ts` — jetons de couleur de la marque (bleu océan,
  vert émeraude, or/jaune chaud, charbon, blanc/slate clair), repris dans
  `tailwind.config.js`.
- `src/components/Navbar.tsx` — logo en haut à gauche, sélecteur de
  langue, déclencheur d'installation PWA, bouton de partage, déclencheur
  de chat/WhatsApp. Le menu hamburger a été retiré : sur desktop/grand
  écran les onglets s'affichent directement dans la barre du header ;
  sur mobile/tablette, ils vivent dans une barre glissante distincte
  sous le header (`src/components/TopTabBar.tsx`) plutôt que dans un
  tiroir latéral.
- `src/components/LanguageSwitcher.tsx` — FR / EN, entièrement traduit
  (site public + panneau admin), voir `src/i18n/translations.ts`.
- `src/components/WhatsAppButton.tsx` — bouton flottant d'assistance.
- `src/components/PWAInstallBanner.tsx` — bannière d'installation PWA.
- `src/components/SectionCard.tsx` — conteneur modulaire avec titres
  stylés `[ ESPACE : ... ]`, utilisé pour structurer chaque écran en
  cartes distinctes plutôt qu'en une page qui défile indéfiniment.
- `src/i18n/` — dictionnaire de traductions et contexte React.

## Section 2 — PWA Core & Offline-First Infrastructure
- `vite.config.ts` — `vite-plugin-pwa` avec manifest complet (icônes,
  couleurs de thème, `display: standalone`) et stratégies Workbox
  (cache-first pour les images, stale-while-revalidate pour la vidéo,
  network-first pour les appels `/api/*`).
- `src/services/db.ts` — persistance locale IndexedDB (via `idb`) : file
  d'attente de mutations hors ligne + cache de contenu en lecture
  (comptes bancaires, titres de section, etc.).
- `src/services/syncService.ts` — gestionnaire de synchronisation
  automatique : vide la file dès le retour du réseau (`online` event),
  au démarrage, et par sondage périodique de sécurité.
- `src/hooks/useOnlineStatus.ts`, `src/hooks/usePWAInstall.ts` — hooks
  d'état réseau et d'installation.

## Section 3 — Public Modules & Interactive Flyer Lightbox
- `src/components/HeroSection.tsx` — Espace 1 : lecteur vidéo (prêt pour une
  URL Cloudinary — voir le commentaire `VIDEO_SRC`), barre de progression
  de campagne et compteurs d'impact animés (`ImpactCounter.tsx`).
- `src/components/JMSAHub.tsx` — Espace 2 : galerie de flyers, onglets
  d'agenda vendredi/samedi (données réelles dans
  `src/data/jmsaProgramme.ts`), intervenants, niveaux de sponsoring et
  billetterie de gala (données réelles dans `src/data/sponsoringTiers.ts`,
  issues du dossier de sponsoring JMSA 2026).
- `src/components/FlyerZoomModal.tsx` — lightbox avec **pinch-to-zoom**
  (Pointer Events, deux doigts), **double-tap / double-clic** pour
  basculer 100 % ↔ 200 %, et glisser/déplacer une fois zoomé.
- `src/components/DonationsSection.tsx` — Espace 3 : IBAN/BIC et Mobile
  Money (TMoney, Flooz, Orange Money, MTN) avec bouton "Copier" par
  compte (`src/hooks/useClipboard.ts`). ⚠️ Les numéros bancaires/Mobile
  Money réels n'étaient pas fournis dans les documents sources : ils sont
  affichés comme placeholders désactivés (`isPlaceholder: true` dans
  `src/data/donationAccounts.ts`) jusqu'à confirmation par l'association.
  Seul le compte PayPal (`liguedesassociationsmondiale@gmail.com`) est réel.
- `src/components/MissionsTransparency.tsx` — Espace 4 : résumé des
  actions de terrain (Cameroun, RDC, Burkina Faso, Togo, Mali, Ghana,
  Côte d'Ivoire, France) et téléchargement des dossiers officiels (les
  deux PDF fournis sont inclus dans `public/reports/`). L'emplacement du
  futur rapport financier audité est prévu mais marqué "à publier".
- `src/components/MediaLibrary.tsx` — Espace 5 : playlist vidéo, lue en
  plein écran via `src/components/VideoPlayerModal.tsx` (lecteur `<video>`
  natif, même charpente que `FlyerZoomModal.tsx`).
- `src/components/HomeGallery.tsx` — bandeau photo de l'association sur
  la page d'accueil (`src/data/homeGallery.ts`), avec le même lightbox
  zoomable que la galerie de flyers ; volontairement sans aucune image
  JMSA sur cette page.
- `src/components/LegalModal.tsx` — mentions légales / politique de
  confidentialité (RGPD), accessible depuis le footer
  (`src/data/legalContent.ts`).
- `src/components/RegistrationLanding.tsx` — lien profond d'inscription
  (ex. `https://<domaine>/?inscription=jmsa2026`) qui ouvre directement le
  formulaire de pass JMSA en plein écran, sans le reste du hub (agenda,
  intervenants, sponsoring) — pratique pour un lien partagé sur
  WhatsApp/Facebook/SMS.
- **Espaces devenus entièrement pilotés par le CMS** : en plus des 4
  modules historiques (Sommet JMSA / Dons / Missions / Médiathèque,
  renommables et activables/désactivables mais jamais supprimables) et
  des onglets fixes Accueil/Contact, un admin peut désormais créer un
  nombre illimité d'onglets génériques (titre + texte libre + images,
  FR/EN) directement depuis le panneau admin — voir Section 5,
  `EspacesPanel.tsx` et `src/components/CustomSpacePanel.tsx` pour le
  rendu public. Sur mobile/tablette, la navigation entre onglets se fait
  via `src/components/TopTabBar.tsx` (barre glissante sous le header).

## Section 4 — Ticketing, PDF Generation & QR Code System
- `src/services/pdfService.ts` — génère, entièrement côté client avec
  `jspdf` + `qrcode` (donc même hors ligne) :
  - ~~Badge d'entrée côté client~~ : `generateBadgePdf` n'est plus appelé
    depuis le navigateur. **Le badge est créé côté serveur**
    (`netlify/functions/lib/badgePdf.js`, via `verifyDonation`) au moment où
    l'admin valide le paiement d'un **billet de gala** — et seulement pour
    les billets (pas pour les inscrits au sommet, ni les sponsors/dons).
    Format carte 100×150 mm, ruban or avec la catégorie du billet, nom de
    l'acheteur, QR code (payload `{ event, id, name }` où `id` = référence du
    billet `GAL26-…`).
  - **Reçu de don provisoire** (`generateReceiptPdf`) : A4, en-tête avec
    les coordonnées légales réelles de l'association (numéro d'entreprise
    1014.435.995, TVA BE1014.435.995, Rue du Collège 25 bte 21, 6000
    Charleroi), détails du don, mention explicite qu'il s'agit d'un reçu
    provisoire en attente de vérification.
  - `generateReferenceCode(prefix)` produit les identifiants courts
    (`JMSA26-…`, `DON26-…`) utilisés par les deux formulaires ci-dessous.
- `src/components/PassRequestForm.tsx` — formulaire de demande de pass
  JMSA 2026 (nom, email, numéro WhatsApp obligatoire avec indicatif, organisation, jour(s), type de
  billet). **Le 1er choix de jour (vendredi 20, Bruxelles) est gratuit** :
  simple inscription, mise en file d'attente IndexedDB
  (`enqueueMutation("pass-request", …)`, fonctionne hors ligne et sera
  synchronisée automatiquement — voir Section 2), confirmation sur
  WhatsApp, **pas de badge**. **Tout autre choix (samedi 21 à Charleroi ou
  les 2 jours) est payant** : le formulaire n'inscrit personne et renvoie
  vers la Billetterie (`onGoToTickets`, voir `services/navIntent.ts`).
- `src/components/DonationProofForm.tsx` — formulaire de dépôt de preuve
  de virement (nom, email, numéro WhatsApp obligatoire pour un billet de gala, montant, mode de paiement, fichier
  image/PDF converti en data URL, 2 Mo maximum ; les photos sont compressées dans le navigateur avant l'envoi, un PDF de plus de 2 Mo est refusé). À la soumission : la
  preuve est mise en file d'attente (`enqueueMutation("donation-proof", …)`)
  et un reçu provisoire est généré et téléchargé, avant même la
  vérification manuelle du virement par l'association.

## Section 5 — Secret Admin Panel & CMS Management
- `src/hooks/useTripleClick.ts` — détecte un triple-tap / triple-clic en
  moins de 800 ms. Branché sur `src/components/Footer.tsx` (nouveau
  composant, monté en bas de `App.tsx`) : le pied de page a l'air tout à
  fait ordinaire, sans aucun indice visuel — conformément au caractère
  « secret » du déclencheur.
- `src/services/authService.ts` — Authentification & Whitelist (v2,
  entièrement réécrite depuis la version « locale » décrite plus haut
  dans une ancienne itération de ce document) :
  - Connexion **sans mot de passe** : Firebase Auth « email link »
    (passwordless). L'admin tape son e-mail, reçoit un vrai e-mail
    contenant un lien de connexion à usage unique, et clique dessus sur
    le même appareil pour ouvrir une session — équivalent gratuit d'un
    code à usage unique, sans Cloud Functions ni plan payant.
  - Liste d'admins **partagée** dans Firestore (collection `admins`, un
    document par e-mail), donc identique pour toute l'équipe, sur tous
    les appareils — plus de liste « par appareil » ni d'étape
    « créer le tout premier compte » dans l'app : le tout premier admin
    est ajouté à la main dans la console Firebase (voir
    [`GUIDE-ACCES-ADMIN.md`](./GUIDE-ACCES-ADMIN.md)).
  - Multi-Email Admin Whitelist Manager (`admin/panels/WhitelistPanel.tsx`,
    onglet « Équipe ») : tout administrateur peut ajouter ou retirer
    n'importe quel autre administrateur (accès CRUD complet et égal,
    aucun « super-admin ») ; seul le tout dernier compte restant ne peut
    jamais être supprimé depuis l'app (il reste toujours possible d'en
    rajouter un directement dans la console Firebase si la liste est
    vidée en dehors de l'app).
- `src/components/admin/AdminLoginModal.tsx` — modal de connexion secret,
  écrans : chargement/vérification du lien, saisie de l'e-mail, « lien
  envoyé », confirmation de l'e-mail (si le lien est ouvert sur un autre
  appareil/navigateur que celui qui l'a demandé), erreur.
- `src/components/admin/AdminPanel.tsx` — panneau d'administration en
  plein écran, structuré en onglets (pas de long scroll) :
  - `panels/EspacesPanel.tsx` — Espaces : remplace les anciens panneaux
    « Titres » et « Ordre ». Gère en un seul endroit le renommage,
    l'activation/désactivation et le glisser-déposer (+ boutons
    Monter/Descendre) des 4 modules historiques *et* la création
    d'onglets génériques illimités (titre + texte libre + images,
    FR/EN) rendus par `CustomSpacePanel.tsx` côté public.
  - `panels/JmsaConfigPanel.tsx` — Config JMSA : nom/dates/lieu/thème de
    l'événement, listes de jours et de types de billets, sans toucher à
    l'agenda détaillé ni aux paliers de sponsoring.
  - `panels/SpeakersPanel.tsx` — Intervenants : ajout/édition/suppression
    et réordonnancement, avec upload de photo (Cloudinary si configuré,
    sinon data URL locale).
  - `panels/FlyerMediaPanel.tsx` — Flyer & Media Manager : ajout par
    upload (Cloudinary si configuré, sinon converti en data URL, donc
    fonctionne hors ligne) ou par URL, légende, suppression,
    réordonnancement. Alimente en direct la galerie de flyers de
    l'Espace 2 (`JMSAHub.tsx`).
  - `panels/MediaLibraryPanel.tsx` — Médiathèque : gère la playlist vidéo
    et les photos de l'Espace 5, avec extraction automatique d'une
    vignette + durée pour chaque vidéo ajoutée
    (`services/videoThumbnail.ts`).
  - `panels/BankAccountsPanel.tsx` — Bank/Mobile Money Account Editor :
    remplace les placeholders IBAN/BIC/Mobile Money de la Section 3 ; le
    bouton « Copier » de `DonationsSection.tsx` se débloque automatiquement
    dès qu'une vraie valeur remplace un placeholder.
  - `panels/DonationsReviewPanel.tsx` — « Dons à vérifier » : liste les
    dons/sponsorings/billets soumis (`listDonations`) et permet de les
    valider (`verifyDonation`), ce qui régénère un reçu PDF définitif et
    l'envoie par e-mail au donateur — voir
    [`README-BACKEND.md`](./README-BACKEND.md).
  - `panels/InscriptionsPanel.tsx` — Inscriptions : liste les inscriptions
    JMSA reçues (`listRegistrations`) et permet un pointage manuel
    (`checkInRegistration`) — la liste que le scanner QR ci-dessous
    alimente aussi.
  - `panels/WhitelistPanel.tsx` — voir ci-dessus (onglet « Équipe »).
  - `panels/ExportAuditPanel.tsx` — One-click Database Export (JSON/CSV) et
    consultation du journal d'audit (`services/auditLog.ts`).
- `src/components/QRScannerModal.tsx` — QR Badge Scanner : lit en caméra
  (API native `BarcodeDetector`, avec repli en saisie manuelle du numéro
  de ticket si l'appareil/le navigateur ne la supporte pas) le QR code du
  badge d'un billet de gala, enregistre le check-in via la fonction
  `checkInRegistration` : la référence lue est comparée à la liste des
  **billets dont le paiement est vérifié** (collection `donations`, type
  « billet »). Billet inconnu → « introuvable » ; billet existant mais
  paiement non validé → « paiement non vérifié » ; déjà scanné → doublon.
  Chaque passage est journalisé.
- `src/services/cmsService.ts` — couche de contenu éditable (espaces,
  config JMSA, flyers, médiathèque, coordonnées de dons). Depuis le
  branchement backend (voir [`README-BACKEND.md`](./README-BACKEND.md)),
  la source de vérité est un document Firestore partagé
  (`settings/site`), lu/écrit via les fonctions Netlify `getSpaces`
  (publique) / `setSpaces` (protégée par l'identité admin) — donc une
  modification faite par un admin est visible par **tous les
  visiteurs**, pas seulement sur son propre appareil. IndexedDB
  (`cachedContent`, clé `cms:site-config`) reste utilisée comme cache
  local pour un affichage instantané et un repli hors ligne.
- `src/services/donationsAdminApi.ts`, `src/services/registrationsAdminApi.ts`,
  `src/services/adminApiClient.ts` — clients HTTP partagés par les
  panneaux admin protégés : envoient le jeton d'identité Firebase de
  l'admin connecté (`Authorization: Bearer <idToken>`) à chaque appel aux
  fonctions Netlify correspondantes.
- `src/services/auditLog.ts` / `src/services/exportService.ts` — trace
  d'audit et export.
- `src/services/db.ts` — stores IndexedDB : `auditLog`, `checkins` (`adminAccounts`
  est un vestige inutilisé, conservé pour la mise à niveau des bases locales existantes) (version de base passée à 2, migration automatique
  via le callback `upgrade` d'`idb`).

Aucune dépendance npm supplémentaire n'a été nécessaire pour cette
section : lecture QR via
`BarcodeDetector` (natif, avec repli manuel), drag-and-drop HTML5 natif.

**Sponsoring relié aux comptes de paiement.** Les tiers de sponsoring
(Or/Diamant/Platinum/Partenaire/etc.) affichaient au départ juste un prix,
sans aucun moyen d'agir dessus. Chaque tier a maintenant un bouton
« Je sponsorise ce tier » qui ouvre, directement sous le tier choisi dans
l'Espace 2, les mêmes comptes bancaires/Mobile Money que l'Espace 3
(extraits dans `PaymentAccountsPanel.tsx`, partagé entre les deux) et le
même formulaire de preuve/reçu (`DonationProofForm.tsx`), avec le montant
du tier déjà rempli et le libellé « Sponsoring — <nom du tier> » tagué sur
la preuve mise en file d'attente et sur le reçu PDF (`pdfService.ts`,
préfixe de référence `SPO26` au lieu de `DON26`). Aucun agrégateur de
paiement n'est nécessaire pour ce flux : c'est le même mécanisme manuel
« comptes affichés + preuve uploadée » que pour un don classique, pas un
paiement en carte/Mobile Money intégré à l'app (voir « Ce qui manque » plus
bas si un vrai paiement en ligne est souhaité un jour). **La billetterie de
gala a reçu le même traitement** : chaque billet (Entrée simple/VIP
Or/VIP Diamant) devient sélectionnable, ouvre le même panneau de comptes +
formulaire, tagué « Billet gala — <nom> » avec le préfixe de référence
`GAL26`. `pdfService.ts` détecte maintenant trois types de reçu
(sponsoring / billetterie / don) à partir du texte de `purpose` et adapte
le titre du PDF (« REÇU DE SPONSORING » / « REÇU DE BILLETTERIE » / « REÇU
DE DON ») et le libellé du payeur (Sponsor / Acheteur / Donateur) en
conséquence.

Les deux formulaires sont intégrés respectivement dans `JMSAHub.tsx`
(Espace 2) et `DonationsSection.tsx` (Espace 3), et affichent un bandeau
d'avertissement quand l'appareil est hors ligne (`useOnlineStatus`).

Les images de flyers (`public/flyers/`) et les PDF (`public/reports/`)
sont des copies des documents fournis, redimensionnées pour le web ; en
production, elles peuvent être migrées vers Cloudinary (Section 6)
plutôt que livrées statiquement avec l'app.

`src/App.tsx` assemble tout dans une coquille fonctionnelle : Hero,
Sommet JMSA 2026, Dons & Mobile Money, Missions & Transparence,
Médiathèque, Contact.

## Section 6 — Cloudinary, Metadata & Deployment Configuration
- `src/services/cloudinaryService.ts` — intégration de l'API d'upload
  **non signée** de Cloudinary (aucun SDK ajouté, un simple `XMLHttpRequest`
  pour bénéficier de la progression d'envoi) :
  - `uploadToCloudinary(file, options)` envoie une image HD, une vidéo MP4
    ou un PDF (le type de ressource Cloudinary — `image` / `video` / `raw`
    — est déduit du type MIME du fichier via `resourceTypeForFile`, ou
    imposé explicitement) et retourne l'URL sécurisée (`secureUrl`), le
    `publicId` et les métadonnées (poids, dimensions, durée…).
  - `buildDeliveryUrl(publicId, resourceType, transformation?)` construit
    une URL de diffusion optimisée (`f_auto,q_auto` par défaut).
  - `isCloudinaryConfigured()` renvoie `false` tant que les deux variables
    d'environnement ci-dessous ne sont pas définies — toute l'app continue
    alors de fonctionner avec son comportement existant (stockage local en
    data URL), donc **aucune configuration Cloudinary n'est requise** pour
    faire tourner le PWA.
  - Configuration via `.env` (voir `.env.example`, ignoré par Git) :
    `VITE_CLOUDINARY_CLOUD_NAME` et `VITE_CLOUDINARY_UPLOAD_PRESET` (un
    preset créé en mode *Unsigned* dans la console Cloudinary — jamais de
    clé/secret API côté navigateur).
  - Branché dans `admin/panels/FlyerMediaPanel.tsx` (Section 5) : quand
    Cloudinary est configuré, un fichier téléversé part directement vers
    Cloudinary avec une barre de progression ; sinon le comportement
    précédent (data URL locale) reste inchangé. Un indicateur textuel dans
    le panneau précise lequel des deux modes est actif.
- `src/services/imageCompression.ts` — compression **côté client**, avant
  tout envoi (Cloudinary ou local) : redimensionne d'abord (bord le plus
  long plafonné à 1920 px), puis réduit la qualité JPEG par paliers
  jusqu'à ~200 Ko cible, sans jamais descendre sous un plancher de
  qualité (0.6) qui donnerait un rendu flou ou pixelisé — si ce plancher
  est atteint avant les 200 Ko, la résolution est réduite par étapes
  (1920 → 1600 → 1280 → 1024 → 800 px) plutôt que de sacrifier davantage
  la netteté. Un fichier déjà sous la cible n'est pas ré-encodé. Branché
  automatiquement dans `FlyerMediaPanel.tsx` avant l'upload : le panneau
  affiche "Photo compressée : 3,2 Mo → 187 Ko (1920×1440px)" à titre de
  confirmation.
  ⚠️ Cette compression ne s'applique qu'aux **images**. La compression
  vidéo (MP4) n'est *pas* faite dans le navigateur — voir la note
  ci-dessous.
- `index.html` — balises **Open Graph** (`og:type`, `og:title`,
  `og:description`, `og:image` 1200×630, `og:url`, `og:site_name`,
  `og:locale` + alternate FR/EN) et **Twitter Card**
  (`summary_large_image`) pour un aperçu correct du lien sur WhatsApp,
  Facebook et LinkedIn, plus un `<link rel="canonical">`. ⚠️ Le domaine
  utilisé (`https://www.ungestedivin.org`) vient des documents fournis ; à
  mettre à jour si le premier déploiement se fait sur une URL Netlify
  provisoire avant le rattachement du domaine.
- `netlify.toml` — configuration de déploiement : commande de build,
  fallback SPA (`/* → /index.html`), en-têtes dédiés au PWA (le service
  worker et le manifest ne sont jamais mis en cache par le CDN pour éviter
  qu'un client reste bloqué sur une ancienne version après un déploiement),
  cache long pour les assets Vite hashés, cache court pour les icônes et
  flyers statiques, et en-têtes de sécurité de base (dont
  `Permissions-Policy: camera=(self)`, nécessaire au scanner QR de la
  Section 5).

### Compression vidéo — pourquoi ce n'est pas fait dans le navigateur
Ré-encoder une vidéo MP4 côté client demanderait une bibliothèque
type `ffmpeg.wasm` (~25 Mo à télécharger, plusieurs dizaines de secondes
de calcul sur un téléphone d'entrée de gamme) — trop lourd pour un PWA
destiné à fonctionner sur des connexions et appareils modestes en Afrique
comme en Europe. La bonne pratique Cloudinary consiste plutôt à laisser
le **preset d'upload** compresser à la réception (aucun code
supplémentaire nécessaire) :
1. Cloudinary console → *Settings* → *Upload* → ouvrir le preset non
   signé utilisé par `cloudinaryService.ts`.
2. Dans *Upload Manipulations* / *Incoming Transformation*, ajouter par
   exemple : `q_auto,vc_auto,w_1280,h_720,c_limit` — qualité et codec
   automatiques, résolution plafonnée à 720p. Cloudinary encode alors le
   fichier une seule fois à la réception, à son coût de traitement plutôt
   qu'à celui du téléphone de l'admin.
3. Optionnel : ajouter `f_auto` dans les URLs de lecture (déjà fait par
   `buildDeliveryUrl()`) pour servir le format le plus léger que le
   navigateur du visiteur supporte (WebM/AV1 quand possible).

## Limites connues de ce livrable
- **i18n** : FR/EN couvre tout le site public et le panneau admin
  (`src/i18n/translations.ts` + données bilingues dans `src/data/`). Les
  titres d'espace modifiables dans l'admin (Section 5, `EspacesPanel.tsx`)
  ont désormais chacun une version FR et une version EN séparées
  (`title`/`titleEn`), y compris pour les onglets fixes Accueil/Contact et
  les 4 modules historiques ; seul le contenu libre (texte + images) des
  onglets génériques créés par l'admin est bilingue de la même façon
  (`body`/`bodyEn`). Le badge d'entrée JMSA / les reçus PDF impriment la
  langue choisie par le visiteur (voir `src/services/pdfService.ts` +
  `netlify/functions/lib/receiptPdf.js`) — mais la langue est figée au moment de la
  soumission : si le visiteur change de langue après coup, ses documents
  déjà générés ne se retraduisent pas rétroactivement.
- **Design des reçus** : reçu provisoire (client, `pdfService.ts`) et reçu
  définitif (backend, `netlify/functions/lib/receiptPdf.js`) partagent un thème
  violet/or dédié (`RECEIPT_PALETTE` / `COLORS`), volontairement distinct
  du bleu océan du reste du site — reprend le gabarit Word officiel de
  l'association. Le badge JMSA garde le thème bleu océan/or du site.
- **Logo** : icônes PWA (`public/icons/`) et logo des reçus
  (`netlify/functions/lib/assets/logo.png`) régénérés à partir du logo officiel
  fourni par l'association (mains + globe + drapeaux + bandeau "UN GESTE
  DIVIN"), fond blanc nettoyé, version *maskable* avec marge de sécurité
  pour Android.
- Les numéros bancaires/Mobile Money réels n'étaient toujours pas fournis
  au moment de ce livrable : ils restent des placeholders désactivés
  (`isPlaceholder: true`) jusqu'à confirmation par l'association via le
  panneau admin (Section 5, `BankAccountsPanel.tsx`).
- Aucun `npm install` / `npm run build` complet n'a pu être exécuté dans
  cet environnement de développement (pas d'accès réseau sortant) :
  chaque fichier a été vérifié individuellement (`node --check` pour le
  backend, un `tsc` isolé avec stubs de types pour le frontend, résolution
  manuelle des imports et des clés de traduction). Un `npm run build`
  complet reste à faire de ton côté avant déploiement.

## Démarrage

```bash
npm install
npm run dev       # serveur de développement
npm run build     # build de production (nécessaire pour tester le PWA/Service Worker)
npm run preview   # sert le build de production localement
```

Aucune signature ou branding tiers n'apparaît dans le code, le footer,
les métadonnées ou l'interface.

## Prochaines étapes (non incluses dans ce livrable)
- ~~Brancher `authService.ts` et `cmsService.ts` sur un vrai backend
  (Firebase Auth + Firestore)~~ — **fait : voir
  [`README-BACKEND.md`](./README-BACKEND.md)** (Netlify Functions
  `submitProof`/`verifyDonation`/`listDonations` pour les dons,
  `submitPassRequest`/`listRegistrations`/`checkInRegistration` pour les
  inscriptions, panneaux admin "Dons à vérifier" et "Inscriptions", reçu
  définitif, envoyé manuellement par l'admin par e-mail ou WhatsApp). `cmsService.ts` (Espaces, Config JMSA,
  etc.) passe aussi par les fonctions Netlify. ~~Protégées par le jeton
  admin partagé~~ — **fait : le jeton partagé (`ADMIN_API_TOKEN`) a été
  retiré**, toutes ces routes vérifient désormais l'identité Firebase
  individuelle de l'admin connecté (voir "Sécurité — jeton partagé
  retiré" dans `README-BACKEND.md`). La gestion de la liste des admins
  (`authService.ts`, onglet "Équipe") reste, elle, en accès direct à
  Firestore depuis le navigateur (protégée par `firestore.rules`), sans
  passer par une fonction serveur.
- Créer le compte Cloudinary réel, le preset non signé, et renseigner
  `.env` (voir `.env.example`) ; migrer la vidéo de présentation
  (`HeroSection.tsx` → `VIDEO_SRC`) et la playlist de la médiathèque
  (`MediaLibrary.tsx`) vers des URLs Cloudinary une fois les fichiers
  vidéo réels disponibles.
- Remplacer l'image 1200×630 utilisée pour `og:image` /
  `twitter:image` (actuellement le flyer principal JMSA 2026) par une
  bannière dédiée aux réseaux sociaux, et confirmer le domaine final dans
  `index.html` avant la mise en production.


## Parcours billet de gala → badge (récapitulatif)
1. Billetterie (`JMSAHub.tsx` → `PaymentFlowBlock` → `DonationProofForm`) :
   la personne choisit son billet, paie (virement / mobile money) et remplit
   la fiche. **Email ou numéro WhatsApp obligatoire** (au moins un des deux) :
   c'est là que le ticket sera envoyé. Reçu provisoire immédiat, puis bouton
   WhatsApp pour signaler le paiement.
2. Panneau admin « Dons à vérifier » : l'admin contrôle le virement et clique
   « Marquer vérifié ». Le serveur crée alors le **reçu définitif** *et* le
   **badge** (PDF avec QR) — stockés sur Cloudinary (`ugd/receipts`,
   `ugd/badges`), liens dans Firestore (`receiptPdfUrl`, `badgePdfUrl`).
3. Dans l'onglet « Vérifiés », un seul message prêt à envoyer contient le
   badge + le reçu : par **email**, ou par **WhatsApp** directement vers le
   numéro de l'acheteur (s'il l'a saisi avec son indicatif pays, ex.
   `+32…` ; sinon le sélecteur de contacts WhatsApp s'ouvre). Un billet
   vérifié avant l'arrivée des badges a un bouton « Générer le badge ».
4. À l'entrée, le scanner lit le QR et valide le billet (voir plus haut).

Les **sponsors et les dons** suivent les mêmes étapes 1–3 mais n'ont qu'un
reçu définitif, jamais de badge. Les **inscrits au sommet** (gratuit le 20)
ne passent pas par ce parcours.

Champs Firestore ajoutés sur `donations` : `phone`, `ticketName`,
`badgePdfUrl`, `checkedIn`, `checkedInAt`, `checkedInBy`.
