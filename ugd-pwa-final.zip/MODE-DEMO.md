# Mode démo — panneau admin sans Firebase ni variables

## Principe
Si le site est construit **sans** aucune variable (`VITE_FIREBASE_*` et
`VITE_API_BASE_URL` absentes), le mode démo s'active tout seul. Dès qu'une vraie
configuration existe, il disparaît automatiquement (rien à retirer du code).

## Déployer par glisser-déposer
1. Sur ton ordinateur : `npm install` puis `npm run build` (sans fichier `.env`).
2. Glisse le dossier **`dist/`** sur https://app.netlify.com/drop

## Accéder au panneau
Triple-clic (ou triple-tap) sur le pied de page « AISBL UN GESTE DIVIN »
→ bouton **« Entrer dans le panneau (démo) »**. Pas d'e-mail, pas de lien.

## Ce qui marche
- Tous les panneaux de modification : Espaces, Compteurs, Config JMSA, Intervenants,
  Flyers, Médiathèque, Documents, Coordonnées de dons, Équipe, Export/Audit.
- Inscriptions et preuves de paiement envoyées depuis le même navigateur : elles
  apparaissent dans « Inscriptions » et « Dons ». « Vérifier » génère un vrai reçu PDF
  et, pour un billet de gala, le badge PDF avec QR code ; le scanner et le pointage
  manuel fonctionnent sur ces données.

## Limites (normales sans backend)
- Les données restent dans le navigateur de l'appareil : les autres visiteurs
  ne voient pas les modifications.
- Pas d'envoi réel d'e-mails ni de stockage Cloudinary (les fichiers ajoutés sont gardés
  dans le navigateur ; les vidéos lourdes peuvent saturer le stockage).
- Le bandeau doré « MODE DÉMO » a un bouton **Réinitialiser** qui efface tout.
