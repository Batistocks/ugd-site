# Accès admin partagé — guide simple

## Ce qui a changé

- Il n'y a plus de "premier compte à créer". La liste des admins est
  maintenant une liste unique, partagée, valable pour toute l'équipe,
  peu importe l'appareil.
- Il n'y a plus de mot de passe. Pour se connecter, un admin tape son
  e-mail, reçoit un vrai e-mail avec un lien à usage unique, et clique
  dessus. C'est l'équivalent gratuit d'un code à usage unique, sans
  passer par une carte bancaire.
- Ça fonctionne avec un compte Google gratuit (Firebase), sans carte
  bancaire. Le reste du site (dons, CMS partagé, inscriptions) tourne
  maintenant sur des fonctions Netlify + Cloudinary — voir
  `README-BACKEND.md` — et n'a plus besoin du plan payant Blaze non
  plus : tout le projet reste gratuit de bout en bout.

## Ce qu'il te reste à faire (une fois, 10 minutes)

1. Va sur console.firebase.google.com, connecte-toi avec un compte
   Google, clique "Ajouter un projet". Aucune carte bancaire n'est
   demandée à cette étape.
2. Dans le projet : menu de gauche → **Compilation** → **Authentication**
   → "Commencer" → onglet "Sign-in method" → active **"E-mail/lien"**
   (Email link / passwordless).
3. Toujours dans le projet : menu de gauche → **Compilation** →
   **Firestore Database** → "Créer une base de données" → mode
   production → région Europe.
4. Une fois la base créée, va dans l'onglet "Règles" et colle le contenu
   du fichier `firestore.rules` fourni ici, puis "Publier".
5. Ajoute les premiers admins à la main : dans Firestore, "Démarrer une
   collection" → nom `admins` → pour chaque admin, crée un document dont
   l'ID est son e-mail en minuscules (ex. `marie@example.com`), sans
   avoir besoin d'y mettre de champs particuliers.
6. Toujours dans le projet : icône ⚙️ → "Paramètres du projet" → onglet
   "Général" → tout en bas, "Vos applications" → "Ajouter une
   application" → choisis le symbole Web (`</>`) → donne-lui un nom →
   Firebase affiche un petit bloc de 4 valeurs.
7. Copie ces 4 valeurs dans le fichier `.env` du projet (crée-le en
   copiant `.env.example`), dans les 4 lignes qui commencent par
   `VITE_FIREBASE_...`.
8. Redéploie le site sur Netlify (et ajoute aussi ces 4 mêmes valeurs
   dans Netlify → Site settings → Environment variables, puisque c'est
   Netlify qui construit le site).

À partir de là, chaque personne dont l'e-mail est dans la liste
`admins` peut se connecter depuis son propre téléphone ou ordinateur, en
tapant juste son e-mail et en cliquant sur le lien reçu.

## Ajouter ou retirer quelqu'un plus tard

Une fois qu'au moins une personne est connectée, elle peut ajouter ou
retirer d'autres admins directement depuis l'onglet "Équipe" du panneau
admin — plus besoin de retourner dans Firebase pour ça.
