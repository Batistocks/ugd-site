# UGD — Backend (Netlify Functions + Firestore + Cloudinary)

## Architecture actuelle

```
DonationProofForm.tsx (React)
        │  enqueueMutation("donation-proof", …)   ← IndexedDB, marche hors ligne
        ▼
syncService.ts  ──POST──▶  Netlify Function  submitProof
                                  │  écrit dans Firestore (donations/{id}, "en_attente")
                                  │  upload la preuve vers Cloudinary si besoin
                                  ▼
                            Firestore  +  Cloudinary

Panneau admin "Dons à vérifier" (DonationsReviewPanel.tsx)
        │  GET  listDonations   (Authorization: Bearer <jeton d'identité Firebase de l'admin>)
        │  POST verifyDonation  (idem)
        ▼
                            Netlify Function verifyDonation
                                  │  régénère le PDF (pdf-lib), logo UGD au lieu d'une signature
                                  │  stocke le PDF sur Cloudinary
                                  │  pas d'envoi automatique — l'admin envoie lui-même
                                  │  (lien mailto: / WhatsApp prêts dans DonationsReviewPanel.tsx)
                                  ▼
                            Firestore mis à jour (status "verifie", verifiedBy = email vérifié côté serveur)
```

Même schéma d'authentification (jeton d'identité Firebase de l'admin, vérifié
contre la collection `admins`) pour le panneau "Inscriptions"
(`InscriptionsPanel.tsx` → `listRegistrations` / `checkInRegistration`) et
pour le scanner QR (`QRScannerModal.tsx` → `checkInRegistration`, qui vérifie
les **billets de gala dont le paiement est validé** — collection `donations` —
et garde la liste `registrations` pour le pointage manuel), et pour la
CMS partagée (`cmsService.ts` → `getSpaces` en lecture publique, `setSpaces`
protégé en écriture).

Tout le backend tourne désormais en **Netlify Functions** (`netlify/functions/`),
plus **Firestore** (base de données, plan gratuit Spark) et **Cloudinary**
(stockage des fichiers/images). Il n'y a plus de Firebase Cloud Functions
ni de plan payant Blaze — voir `MIGRATION-NOTES-index-js.md` pour le détail
de cette migration.

## Mise en place

1. **Firestore** : créer un projet Firebase (console.firebase.google.com),
   activer Firestore (plan Spark, gratuit), coller les règles de
   `firestore.rules`. Voir `GUIDE-ACCES-ADMIN.md` pour la partie
   authentification admin (email-link).
2. **Cloudinary** : créer un compte gratuit, récupérer Cloud name / API
   Key / API Secret (upload signé, côté serveur) — séparé du preset
   public non signé déjà utilisé côté client pour les flyers.
3. **Compte de service Firebase** (pour que les fonctions Netlify
   puissent écrire dans Firestore avec les droits admin) : Console
   Firebase → Paramètres du projet → Comptes de service → Générer une
   nouvelle clé privée → encoder le JSON obtenu en base64.

## Variables d'environnement (Netlify → Site settings → Environment variables)

```
FIREBASE_SERVICE_ACCOUNT_KEY   # JSON du compte de service, encodé en base64
CLOUDINARY_CLOUD_NAME
CLOUDINARY_API_KEY
CLOUDINARY_API_SECRET
VITE_FIREBASE_API_KEY
VITE_FIREBASE_AUTH_DOMAIN
VITE_FIREBASE_PROJECT_ID
VITE_FIREBASE_APP_ID
VITE_API_BASE_URL=/.netlify/functions
VITE_CLOUDINARY_CLOUD_NAME
VITE_CLOUDINARY_UPLOAD_PRESET
ALLOWED_ORIGINS                # optionnel : domaines autorisés (CORS), séparés par des virgules
```

## Sécurité — jeton partagé retiré

Toutes les routes qui exigent un droit admin (`listDonations`,
`verifyDonation`, `checkInRegistration`, `listRegistrations`,
`setSpaces`) vérifient désormais l'identité individuelle de l'admin
(jeton d'identité Firebase + présence de son email dans la collection
`admins`), comme le reste du panneau (voir `GUIDE-ACCES-ADMIN.md`).
Le `verifiedBy` / `updatedBy` / `checkedInBy` enregistré reflète
l'identité réellement vérifiée par le serveur, jamais une valeur
envoyée par le client.

Il n'y a donc plus de jeton unique partagé (`ADMIN_API_TOKEN`) nulle
part dans le projet — variable à retirer de Netlify si elle y était
encore configurée. `getSpaces` et `submitPassRequest`/`submitProof`
restent volontairement publiques (lecture de la configuration du site,
et soumission d'un formulaire par un visiteur), sans identité requise.

## Sécurité des endpoints publics (ajouts)

- **CORS** : variable Netlify `ALLOWED_ORIGINS` (domaines séparés par des virgules). Vide = `*`.
  Changer de nom de domaine = modifier cette variable, aucun redéploiement de code.
- **Limitation de débit** : `submitPassRequest` et `submitProof` acceptent 8 appels / 10 min / IP
  (réponse 429 ensuite). Les compteurs sont dans la collection Firestore `rateLimits`.
  Active une politique TTL : Firestore → TTL → groupe de collections `rateLimits`, champ `expireAt`.
- **Preuves de paiement** : 2 Mo maximum côté site (les photos sont compressées avant l'envoi),
  3 Mo décodés maximum côté serveur.
- **Anti-doublons** : création atomique (`create()`), pointage QR dans une transaction.
- **WhatsApp** : numéro avec indicatif obligatoire (inscription et billets), enregistré en `+<chiffres>`.
