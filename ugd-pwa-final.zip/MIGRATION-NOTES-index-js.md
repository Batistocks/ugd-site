# Migration index.js → Netlify Functions (fait dans ce lot)

> **Note (mise à jour ultérieure) :** ce document décrit l'état au
> moment de cette migration, y compris `ADMIN_API_TOKEN` et
> `x-admin-token` ci-dessous. Ce jeton partagé a depuis été retiré —
> toutes les routes admin utilisent maintenant l'identité Firebase
> individuelle de chaque admin. Voir `README-BACKEND.md` pour l'état
> actuel.

## Ce qui a été créé

`netlify/functions/` — les 8 routes, un fichier par route (au lieu d'un
gros `index.js` façon Cloud Functions), plus `lib/` :

- `lib/firebaseAdmin.js` — Firestore via `firebase-admin` + compte de
  service (Firestore reste gratuit, plan Spark, sans carte).
- `lib/cloudinaryStorage.js` — remplace Firebase Storage (qui exige
  maintenant le plan payant Blaze) : upload signé vers Cloudinary.
- `lib/http.js` — CORS, vérification `x-admin-token`, parsing JSON
  (équivalent des helpers Express de l'ancien `functions/index.js`).
- `lib/siteConfig.js` — config "espaces/JMSA/flyers/speakers/bank"
  partagée, identique à l'original.
- `lib/receiptPdf.js` — déjà migré avant ce lot, inchangé ici.
- `submitProof.js`, `listDonations.js`, `verifyDonation.js`,
  `getSpaces.js`, `setSpaces.js`, `submitPassRequest.js`,
  `listRegistrations.js`, `checkInRegistration.js` — logique identique
  à `functions/index.js`, adaptée à la signature Netlify
  `exports.handler = async (event) => {...}`.

`package.json` — ajout de `firebase-admin` et `cloudinary` aux
dépendances (nécessaires pour que Netlify les bundle avec `esbuild`).

`firebase.json` — retrait des sections `functions` et `storage` (plus
besoin, plus de déploiement Cloud Functions). Seul Firestore reste géré
côté Firebase.

## Variables d'environnement à ajouter (Netlify → Site settings →
Environment variables)

```
FIREBASE_SERVICE_ACCOUNT_KEY   # JSON du compte de service, encodé en base64 (voir lib/firebaseAdmin.js)
CLOUDINARY_CLOUD_NAME
CLOUDINARY_API_KEY
CLOUDINARY_API_SECRET
ALLOWED_ORIGINS                # optionnel : domaines autorisés (CORS), séparés par des virgules
```

Et côté build (`VITE_API_BASE_URL`) : mettre `/.netlify/functions` (les
noms de fichiers = noms de routes, donc `donationsAdminApi.ts` /
`registrationsAdminApi.ts` / `cmsService.ts` continuent de fonctionner
sans modification — ils appellent déjà `${API_BASE_URL}/listDonations`
etc.).

## Ce qu'il reste à faire (hors scope de ce lot)

- Générer le compte de service Firebase (Project settings → Service
  accounts → Generate new private key), l'encoder en base64, le coller
  dans Netlify.
- Créer/retrouver le compte Cloudinary (déjà utilisé côté client pour
  les flyers) et récupérer API Key + Secret dans le dashboard.
- Une fois testé en prod : supprimer l'ancien dossier `functions/`
  (Cloud Functions Firebase) et `storage.rules`, devenus inutiles, et
  mettre à jour `README-BACKEND.md` / `GUIDE-ACCES-ADMIN.md` qui
  décrivent encore l'ancien flux Blaze.
