/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // "Verni" palette — bleu roi / vert émeraude / jaune safran, kept
        // fully saturated and jewel-like on purpose so the three brand
        // colors read as an immediate, glossy accent rather than a muted
        // institutional tint (previous values were deliberately desaturated;
        // this direction reverses that call). Saffron especially is now
        // allowed as a small solid fill (badges, active states, glow),
        // not just a hairline — see the new shadow-royal/emerald/saffron
        // "glow" tokens below and .btn-sheen / .gloss in index.css, which
        // pair with these colors for the lacquered look.
        ocean: {
          DEFAULT: "#3563E9", // bleu roi, brighter — links/secondary buttons/hovers
          deep: "#122F9E", // bleu roi, primary — header, main CTAs
        },
        emerald: {
          DEFAULT: "#00966D", // vert émeraude, vivid jewel tone
          deep: "#00543D", // deeper shade for text-on-white / contrast
        },
        // Official WhatsApp brand green — kept separate from the
        // institutional palette on purpose. Used only for the floating
        // WhatsApp contact button, where visitors expect the standard
        // recognizable color rather than the site's own green, and where
        // straying too far from it risks looking like an unauthorized
        // recoloring of WhatsApp's own icon.
        whatsapp: "#25D366",
        gold: {
          DEFAULT: "#F4C430", // jaune safran — the real named "saffron" hex
          warm: "#C9960A", // deeper safran/amber — text-on-white, hover, hairlines
        },
        charcoal: "#24313A", // anthracite
        slate: {
          light: "#EEF1F0",
        },
        ivory: "#FCFCFA",
      },
      fontFamily: {
        // Bold geometric sans (was Cormorant Garamond, a serif) — matches
        // the rounded, heavy headline/number style the person pointed to
        // on their reference screenshot (the "UGD" wordmark, the "35/19/8"
        // counters). Body text (IBM Plex Sans) is unchanged.
        display: ["'Poppins'", "system-ui", "sans-serif"],
        sans: ["'IBM Plex Sans'", "system-ui", "sans-serif"],
      },
      borderRadius: {
        card: "0.375rem",
      },
      boxShadow: {
        card: "0 1px 2px rgba(36, 49, 58, 0.05), 0 2px 6px rgba(36, 49, 58, 0.05)",
        // "Verni" glow shadows — a soft, color-matched halo under a
        // solid-fill CTA, like light catching a lacquered/varnished
        // surface. Pair with .btn-sheen (index.css) on the app's primary
        // action buttons (S'inscrire, Faire un don, choisir un palier…).
        royal: "0 10px 24px -8px rgba(18, 47, 158, 0.5), 0 2px 6px rgba(18, 47, 158, 0.18)",
        emeraldGlow: "0 10px 24px -8px rgba(0, 150, 109, 0.5), 0 2px 6px rgba(0, 150, 109, 0.18)",
        saffron: "0 10px 24px -8px rgba(244, 196, 48, 0.55), 0 2px 6px rgba(201, 150, 10, 0.2)",
      },
      maxWidth: {
        content: "72ch",
      },
    },
  },
  plugins: [],
};
