import * as pdfjsLib from "pdfjs-dist";
// Vite-bundled worker file (own-origin, so it works from the Netlify build
// exactly like the rest of the app's own JS -- no CDN dependency, no
// separate deploy step to remember).
import pdfjsWorkerUrl from "pdfjs-dist/build/pdf.worker.min.mjs?url";

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorkerUrl;
