import {
  isSignInWithEmailLink,
  onAuthStateChanged,
  sendSignInLinkToEmail,
  signInWithEmailLink,
  signOut,
  type User,
} from "firebase/auth";
import {
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  collection,
  serverTimestamp,
  setDoc,
} from "firebase/firestore";
import { auth, firestore } from "./firebaseConfig";
import { recordAuditEvent } from "./auditLog";
import { DEMO_ADMIN_EMAIL, isDemoMode, readDemo, removeDemo, writeDemo } from "./demoMode";

/**
 * Secret Admin Panel — Authentication & Whitelist (v2).
 *
 * WHY THIS WAS REWRITTEN
 * -----------------------
 * The previous version stored one admin account "in a notebook that lived
 * inside each admin's own phone/computer" (a local IndexedDB store). That
 * meant:
 *   - Every device had to create its OWN "first admin" — teammates could
 *     never share the same admin list.
 *   - The "OTP code" was never actually sent anywhere — it was just shown
 *     on screen, because sending a real email needs a server, and this
 *     app has no free server that isn't the local device.
 *
 * WHAT CHANGED
 * ------------
 * There is now ONE shared list of admin emails, kept in Firestore (a
 * free Google database — see firebaseConfig.ts), so every teammate sees
 * the same list from their own device. There is no more "create the
 * first admin" step: whoever owns the Firebase project adds the first
 * email(s) directly in the Firebase console (Firestore → `admins`
 * collection → one document per email, doc ID = the email address,
 * lowercase). After that, any admin can add/remove any other admin from
 * the in-app "Équipe" panel — same equal-access model as before.
 *
 * Login no longer uses a password + a fake on-screen code. Instead it
 * uses Firebase's built-in passwordless "email link" sign-in: the admin
 * types their email, Firebase itself sends a real email with a one-time
 * secure link, and clicking it on the same device logs them in. This is
 * the free, no-credit-card equivalent of a one-time code — it doesn't
 * need Cloud Functions, an e-mail service, or the paid Blaze plan.
 */

const PENDING_EMAIL_KEY = "ugd:admin-pending-email";

/**
 * Thrown by any admin-panel action when Firebase hasn't been configured
 * on this deployment (see firebaseConfig.ts). Callers already catch and
 * display errors from these functions (see AdminLoginModal.tsx), so this
 * surfaces as a normal on-screen message instead of crashing the app.
 */
class FirebaseNotConfiguredError extends Error {
  constructor() {
    super(
      "Le panneau administrateur n'est pas encore disponible : Firebase n'est pas configuré sur ce déploiement.",
    );
    this.name = "FirebaseNotConfiguredError";
  }
}

function requireAuth() {
  if (!auth) throw new FirebaseNotConfiguredError();
  return auth;
}

function requireFirestore() {
  if (!firestore) throw new FirebaseNotConfiguredError();
  return firestore;
}

export interface AdminSession {
  email: string;
}

export interface AdminListItem {
  email: string;
  createdAt: number;
  createdBy: string;
}

type SessionListener = (session: AdminSession | null) => void;
const listeners = new Set<SessionListener>();

let currentSession: AdminSession | null = null;
let authReady = false;
const readyWaiters: Array<() => void> = [];

function emit() {
  listeners.forEach((l) => l(currentSession));
}

export function subscribeSession(listener: SessionListener): () => void {
  listeners.add(listener);
  listener(currentSession);
  return () => listeners.delete(listener);
}

export function getSession(): AdminSession | null {
  return currentSession;
}

export function isAuthenticated(): boolean {
  return currentSession !== null;
}

function normalize(email: string): string {
  return email.trim().toLowerCase();
}

async function isWhitelisted(email: string): Promise<boolean> {
  const snap = await getDoc(doc(requireFirestore(), "admins", email));
  return snap.exists();
}

// Keeps `currentSession` in sync with Firebase's own auth state, and
// double-checks the signed-in email is still on the shared admin list
// (e.g. in case another admin removed them since their last visit).
// Skipped entirely when Firebase isn't configured — the site still needs
// to render, it just starts with no admin session, same as a signed-out
// visitor.
if (auth) {
  const activeAuth = auth;
  onAuthStateChanged(activeAuth, async (user: User | null) => {
    if (!user || !user.email) {
      currentSession = null;
      emit();
    } else {
      const email = normalize(user.email);
      const allowed = await isWhitelisted(email);
      if (!allowed) {
        await signOut(activeAuth);
        currentSession = null;
      } else {
        currentSession = { email };
      }
      emit();
    }
    authReady = true;
    readyWaiters.splice(0).forEach((fn) => fn());
  });
} else {
  // Mode démo : on restaure la session démo mémorisée sur cet appareil.
  if (isDemoMode && readDemo<boolean>("session", false)) {
    currentSession = { email: DEMO_ADMIN_EMAIL };
  }
  authReady = true;
}

// --- Mode démo ----------------------------------------------------------------

/** Ouvre une session admin locale (sans Firebase). Ne fonctionne qu'en mode démo. */
export async function enterDemoMode(): Promise<AdminSession> {
  if (!isDemoMode) throw new Error("Le mode démo n'est pas disponible sur ce déploiement.");
  writeDemo("session", true);
  currentSession = { email: DEMO_ADMIN_EMAIL };
  emit();
  await recordAuditEvent(DEMO_ADMIN_EMAIL, "admin.login", "Connexion en mode démo");
  return currentSession;
}

function demoAdmins(): AdminListItem[] {
  return readDemo<AdminListItem[]>("admins", [
    { email: DEMO_ADMIN_EMAIL, createdAt: Date.now(), createdBy: "démo" },
  ]);
}

/** Resolves once Firebase has reported the initial auth state at least once. */
export function waitUntilReady(): Promise<void> {
  if (authReady) return Promise.resolve();
  return new Promise((resolve) => readyWaiters.push(resolve));
}

// --- Passwordless email-link login ------------------------------------------

/**
 * True if the current page URL is a sign-in link Firebase just emailed.
 * Called unconditionally on every page load (see Footer.tsx), so it
 * returns false — rather than throwing — when Firebase isn't configured.
 */
export function isAdminSignInLink(): boolean {
  if (!auth) return false;
  return isSignInWithEmailLink(auth, window.location.href);
}

/**
 * Step 1: send the one-time sign-in link to the given email. Anyone can
 * request a link (there is no way to check the whitelist without being
 * signed in first — see firestore.rules), but the link only grants real
 * admin access if that email is on the shared list.
 */
export async function sendAdminSignInLink(email: string): Promise<void> {
  const normalized = normalize(email);
  const url = new URL(window.location.href);
  url.search = ""; // drop any old link params before re-using this URL as the return target
  await sendSignInLinkToEmail(requireAuth(), normalized, {
    url: url.toString(),
    handleCodeInApp: true,
  });
  window.localStorage.setItem(PENDING_EMAIL_KEY, normalized);
}

/**
 * Step 2: called after the admin clicks the link in their email. If they
 * opened the link on the same device/browser they requested it from, the
 * email is already known (`storedPendingEmail`); otherwise the caller
 * must ask them to re-type it to confirm their identity.
 */
export function storedPendingEmail(): string | null {
  return window.localStorage.getItem(PENDING_EMAIL_KEY);
}

export async function completeAdminSignIn(email: string): Promise<AdminSession> {
  const activeAuth = requireAuth();
  const normalized = normalize(email);
  const credential = await signInWithEmailLink(activeAuth, normalized, window.location.href);
  window.localStorage.removeItem(PENDING_EMAIL_KEY);
  // Clean the one-time link parameters out of the visible URL.
  window.history.replaceState({}, document.title, window.location.pathname);

  const allowed = await isWhitelisted(normalized);
  if (!allowed) {
    await signOut(activeAuth);
    throw new Error(
      "Cette adresse e-mail n'est pas autorisée à accéder au panneau administrateur.",
    );
  }
  currentSession = { email: normalized };
  emit();
  await recordAuditEvent(normalized, "admin.login", "Connexion réussie (lien e-mail)");
  return { email: normalized };
  // (credential is unused beyond confirming sign-in succeeded)
  void credential;
}

/**
 * Firebase's own short-lived identity token for the signed-in admin —
 * proves WHO they are to a Netlify Function, unlike the old shared
 * ADMIN_API_TOKEN which only proved someone knew a secret. Used by
 * donationsAdminApi.ts. Returns null if no admin is signed in.
 */
export async function getIdToken(): Promise<string | null> {
  if (isDemoMode) return currentSession ? "demo-token" : null;
  if (!auth?.currentUser) return null;
  return auth.currentUser.getIdToken();
}

export async function logout(): Promise<void> {
  if (isDemoMode) {
    if (currentSession) await recordAuditEvent(currentSession.email, "admin.logout", "Déconnexion (démo)");
    removeDemo("session");
    currentSession = null;
    emit();
    return;
  }
  if (currentSession) await recordAuditEvent(currentSession.email, "admin.logout", "Déconnexion");
  await signOut(requireAuth());
}

// --- Shared whitelist CRUD (Firestore, no server involved) ------------------

export async function listAdmins(): Promise<AdminListItem[]> {
  if (isDemoMode) return demoAdmins().sort((a, b) => a.createdAt - b.createdAt);
  const snap = await getDocs(collection(requireFirestore(), "admins"));
  return snap.docs
    .map((d) => {
      const data = d.data() as { createdAt?: { toMillis: () => number }; createdBy?: string };
      return {
        email: d.id,
        createdAt: data.createdAt ? data.createdAt.toMillis() : Date.now(),
        createdBy: data.createdBy ?? "?",
      };
    })
    .sort((a, b) => a.createdAt - b.createdAt);
}

/** Adds a teammate's email to the shared list. Equal access, as before. */
export async function addAdmin(actorEmail: string, newEmail: string): Promise<void> {
  if (isDemoMode) {
    const normalized = normalize(newEmail);
    const list = demoAdmins();
    if (list.some((a) => a.email === normalized)) throw new Error("Cette adresse est déjà administratrice.");
    list.push({ email: normalized, createdAt: Date.now(), createdBy: actorEmail });
    writeDemo("admins", list);
    await recordAuditEvent(actorEmail, "admin.add", `Ajout de ${normalized} (démo)`);
    return;
  }
  const db = requireFirestore();
  const normalized = normalize(newEmail);
  const existing = await getDoc(doc(db, "admins", normalized));
  if (existing.exists()) {
    throw new Error("Cette adresse est déjà administratrice.");
  }
  await setDoc(doc(db, "admins", normalized), {
    createdAt: serverTimestamp(),
    createdBy: actorEmail,
  });
  await recordAuditEvent(actorEmail, "admin.add", `Ajout de ${normalized}`);
}

/** Removes a teammate. Client-side guard only: blocks removing the last one. */
export async function removeAdmin(actorEmail: string, targetEmail: string): Promise<void> {
  if (isDemoMode) {
    const normalized = normalize(targetEmail);
    const list = demoAdmins();
    if (list.length <= 1) throw new Error("Impossible de supprimer le dernier compte administrateur.");
    writeDemo("admins", list.filter((a) => a.email !== normalized));
    await recordAuditEvent(actorEmail, "admin.remove", `Retrait de ${normalized} (démo)`);
    return;
  }
  const normalized = normalize(targetEmail);
  const all = await listAdmins();
  if (all.length <= 1) {
    throw new Error("Impossible de supprimer le dernier compte administrateur.");
  }
  await deleteDoc(doc(requireFirestore(), "admins", normalized));
  await recordAuditEvent(actorEmail, "admin.remove", `Retrait de ${normalized}`);
  if (currentSession?.email === normalized) await signOut(requireAuth());
}
