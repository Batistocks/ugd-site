/**
 * Client for the admin-protected registration endpoints
 * (listRegistrations, checkInRegistration). See adminApiClient.ts for
 * the shared per-admin auth model.
 */

import { adminFetch, isBackendConfigured, AdminApiError } from "./adminApiClient";

export { isBackendConfigured, AdminApiError };

export interface RegistrationRecord {
  registrationId: string;
  fullName: string;
  email: string | null;
  phone: string | null;
  organization: string | null;
  day: string | null;
  ticketType: string | null;
  lang: "fr" | "en";
  status: string;
  checkedIn: boolean;
  checkedInAt: number | null;
  checkedInBy: string | null;
  createdAt: number | null;
  clientCreatedAt: number | null;
}

export async function fetchRegistrations(checkedIn?: boolean): Promise<RegistrationRecord[]> {
  const query = checkedIn === undefined ? "" : `?checkedIn=${checkedIn}`;
  const data = await adminFetch(`/listRegistrations${query}`);
  return data.items as RegistrationRecord[];
}

export async function checkInRegistrationRemote(
  id: string,
): Promise<{ id: string; alreadyCheckedIn?: boolean; fullName?: string }> {
  const data = await adminFetch("/checkInRegistration", {
    method: "POST",
    body: JSON.stringify({ id }),
  });
  return data;
}
