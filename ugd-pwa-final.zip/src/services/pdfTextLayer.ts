import { TextLayer } from "pdfjs-dist";
import type { PDFPageProxy } from "pdfjs-dist";

/**
 * Draws pdf.js's built-in selectable text layer into `container`, matching
 * it to a page rendered at `cssScale` (i.e. the *logical* / CSS-pixel scale
 * the canvas is displayed at - not the higher physical-pixel scale used
 * for a crisp high-DPI raster). The text itself stays invisible (styled by
 * pdfjs-dist/web/pdf_viewer.css, imported once in PdfReader.tsx); only the
 * browser's native selection highlight shows, over the real pixels drawn
 * underneath.
 *
 * This never changes the source PDF - it's a second, transparent DOM layer
 * pdf.js positions from the same page content, purely so the visitor can
 * select/copy text.
 */
export async function renderPdfTextLayer(
  page: PDFPageProxy,
  container: HTMLDivElement,
  cssScale: number,
): Promise<void> {
  const viewport = page.getViewport({ scale: cssScale });
  container.innerHTML = "";
  container.style.setProperty("--scale-factor", String(viewport.scale));
  container.style.width = `${viewport.width}px`;
  container.style.height = `${viewport.height}px`;

  const textContent = await page.getTextContent();
  const textLayer = new TextLayer({
    textContentSource: textContent,
    container,
    viewport,
  });
  await textLayer.render();
}
