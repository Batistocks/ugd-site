/**
 * One-shot "take me to the Billetterie" request.
 *
 * The summit registration form (PassRequestForm) can be shown in two places:
 * inside the JMSA hub, right above the gala tickets, and in the full-screen
 * deep-link landing (`?inscription=…`) where the tickets are not on screen.
 * When a visitor picks the paid day, the form sends them to the Billetterie;
 * from the landing that means closing the overlay, switching to the JMSA
 * space and opening its tickets — across components that don't share state.
 *
 * `requestBilletterie()` records the request and notifies a hub that is
 * already mounted; a hub that mounts afterwards picks it up with
 * `consumeBilletterieRequest()`. Either way the request is used only once.
 */

const EVENT_NAME = "ugd:open-billetterie";
let pending = false;

export function requestBilletterie(): void {
  pending = true;
  window.dispatchEvent(new Event(EVENT_NAME));
}

/** True (once) if a request is waiting. */
export function consumeBilletterieRequest(): boolean {
  const wasPending = pending;
  pending = false;
  return wasPending;
}

/** Subscribe a mounted hub; returns the unsubscribe function. */
export function onBilletterieRequest(callback: () => void): () => void {
  window.addEventListener(EVENT_NAME, callback);
  return () => window.removeEventListener(EVENT_NAME, callback);
}
