import { jsPDF } from "jspdf";
import QRCode from "qrcode";
import { colors } from "../constants/theme";
import type { Lang } from "../i18n/translations";

/**
 * PDF Generator — Section 4: Ticketing, PDF Generation & QR Code System.
 *
 * Two client-side generators built on jsPDF, run entirely in the browser
 * (no server round-trip needed to produce the file):
 *
 *  - generateBadgePdf   : JMSA 2026 entrance badge with a unique QR code
 *                         and the official UGD logo header. Ocean-blue/gold
 *                         theme, matches the rest of the site.
 *  - generateReceiptPdf : provisional donation receipt, issued as soon as
 *                         a transfer proof is submitted. Purple/gold
 *                         "certificate" theme (see RECEIPT_PALETTE), with
 *                         a JMSA 2026 header/footer banner (see
 *                         loadReceiptBanner) — kept deliberately distinct
 *                         from the site's own blue branding, mirrored by
 *                         the backend's definitive receipt in
 *                         netlify/functions/lib/receiptPdf.js.
 *
 * Both accept a `lang` ("fr" | "en", defaults to "fr") so the printed
 * document matches whichever language the visitor was using on the site —
 * see PDF_LABELS below. This mirrors (and stays independent from) the
 * app's own i18n dictionary in src/i18n/translations.ts: PDF layout text
 * is a separate, smaller set of labels since it prints on a fixed A4/card
 * layout rather than a reflowing UI.
 *
 * The underlying registration/donation record is queued for sync
 * separately (see services/db.ts + services/syncService.ts) so PDF
 * generation works even while fully offline.
 */

const ASSOCIATION = {
  legalName: "AISBL UN GESTE DIVIN",
  shortName: "UN GESTE DIVIN",
  address: "Rue du Collège 25 bte 21, 6000 Charleroi, Belgique",
  companyNumber: "1014.435.995",
  vatNumber: "BE1014.435.995",
  email: "internationaleungestedivin@gmail.com",
  phone: "0032 472 28 50 39",
  site: "www.ungestedivin.org",
};

// Dedicated receipt palette (matches the association's official Word
// receipt template) — intentionally separate from the site's ocean-blue
// theme (src/constants/theme.ts), which the badge still uses.
const RECEIPT_PALETTE = {
  purpleDark: "32106F",
  purpleMed: "5A20A8",
  gold: "D6A62B",
  navy: "17265C",
  grey: "667085",
  rowTint: [245, 243, 250] as [number, number, number],
};

const PDF_LABELS = {
  // orgTagline and footerTagline are no longer drawn on the receipt — the
  // JMSA 2026 header/footer banners replaced the text blocks that used to
  // carry them (see generateReceiptPdf below). Still used as-is by nothing
  // else; left in place in case a future banner-less fallback needs them.
  fr: {
    eventFullName: "La Journée Mondiale du Sommet des Associations",
    eventDates: "20–21 novembre 2026 · Charleroi, Belgique",
    dayLabel: "Jour(s) :",
    registrationPrefix: "N°",
    organizedBy: "Organisé par l'AISBL UN GESTE DIVIN · www.ungestedivin.org",
    companyLine: (c: string, v: string) => `N° d'entreprise : ${c}  ·  TVA : ${v}`,
    receiptTitles: {
      sponsoring: "REÇU DE SPONSORING",
      billet: "REÇU DE BILLETTERIE",
      don: "REÇU DE DON",
    } as Record<ReceiptKind, string>,
    payerLabels: {
      sponsoring: "Sponsor",
      billet: "Acheteur",
      don: "Donateur",
    } as Record<ReceiptKind, string>,
    statusProvisional: "PROVISOIRE",
    orgTagline: "Ensemble pour un monde meilleur",
    tagline: "SOLIDARITÉ  ·  DIGNITÉ  ·  COOPÉRATION  ·  ACTION",
    tableHeaderInfo: "INFORMATION",
    tableHeaderValue: "VALEUR",
    reference: "Référence",
    email: "Email",
    purpose: "Objet",
    date: "Date du don",
    paymentMethod: "Mode de paiement",
    amount: "Montant",
    certificationHeading: "CERTIFICATION",
    provisionalNotice:
      "Ce reçu est délivré à titre provisoire dès réception de votre preuve de transfert, dans l'attente " +
      "de sa vérification par l'association. Un reçu définitif pourra être établi sur demande une fois le " +
      "versement confirmé.",
    signatureLabel: "Signature autorisée",
    thankYouTitle: "MERCI POUR VOTRE SOUTIEN",
    thankYouSubtitle: "Votre engagement contribue à notre action internationale.",
    footerTagline: "ENSEMBLE, IMPACTONS DES VIES",
  },
  en: {
    eventFullName: "World Day of the Associations Summit",
    eventDates: "20–21 November 2026 · Charleroi, Belgium",
    dayLabel: "Day(s):",
    registrationPrefix: "No.",
    organizedBy: "Organized by AISBL UN GESTE DIVIN · www.ungestedivin.org",
    companyLine: (c: string, v: string) => `Company No.: ${c}  ·  VAT: ${v}`,
    receiptTitles: {
      sponsoring: "SPONSORSHIP RECEIPT",
      billet: "TICKET RECEIPT",
      don: "DONATION RECEIPT",
    } as Record<ReceiptKind, string>,
    payerLabels: {
      sponsoring: "Sponsor",
      billet: "Buyer",
      don: "Donor",
    } as Record<ReceiptKind, string>,
    statusProvisional: "PROVISIONAL",
    orgTagline: "Together for a better world",
    tagline: "SOLIDARITY  ·  DIGNITY  ·  COOPERATION  ·  ACTION",
    tableHeaderInfo: "INFORMATION",
    tableHeaderValue: "VALUE",
    reference: "Reference",
    email: "Email",
    purpose: "Subject",
    date: "Donation date",
    paymentMethod: "Payment method",
    amount: "Amount",
    certificationHeading: "CERTIFICATION",
    provisionalNotice:
      "This receipt is issued on a provisional basis upon receipt of your transfer proof, pending " +
      "verification by the association. A final receipt can be issued on request once the payment has " +
      "been confirmed.",
    signatureLabel: "Authorized signature",
    thankYouTitle: "THANK YOU FOR YOUR SUPPORT",
    thankYouSubtitle: "Your commitment supports our international action.",
    footerTagline: "TOGETHER, LET'S IMPACT LIVES",
  },
};

function labelsFor(lang: Lang = "fr") {
  return PDF_LABELS[lang] ?? PDF_LABELS.fr;
}

// --- Shared helpers ---------------------------------------------------------

let logoDataUrlCache: string | null | undefined;

/**
 * Loads the app's own PWA icon (public/icons/icon-512.png) as a data URL so
 * it can be embedded in a jsPDF document. Cached after the first successful
 * fetch. Returns null (badge/receipt still render, just without the mark)
 * if the icon can't be fetched — e.g. fully offline on first-ever load
 * before the service worker has cached it.
 */
async function loadLogoDataUrl(): Promise<string | null> {
  if (logoDataUrlCache !== undefined) return logoDataUrlCache;
  try {
    const response = await fetch("/icons/icon-512.png");
    const blob = await response.blob();
    logoDataUrlCache = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(blob);
    });
  } catch {
    logoDataUrlCache = null;
  }
  return logoDataUrlCache;
}

/**
 * JMSA 2026 header/footer banners for the receipt only (the badge keeps
 * its own logo header via loadLogoDataUrl above). Loaded from public/
 * as a data URL, same offline-friendly pattern as the logo, plus the
 * image's native pixel size (read via a throwaway <img>) so the banner
 * can be drawn full-width at its real aspect ratio — mirrors the
 * cursor-based layout in netlify/functions/lib/receiptPdf.js.
 */
interface BannerAsset {
  dataUrl: string;
  width: number;
  height: number;
}

const bannerCache: Partial<Record<"header" | "footer", BannerAsset | null>> = {};

async function loadReceiptBanner(kind: "header" | "footer"): Promise<BannerAsset | null> {
  if (bannerCache[kind] !== undefined) return bannerCache[kind] ?? null;
  try {
    const response = await fetch(`/receipts/receipt-${kind}.png`);
    const blob = await response.blob();
    const dataUrl = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(blob);
    });
    const { width, height } = await new Promise<{ width: number; height: number }>((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve({ width: img.naturalWidth, height: img.naturalHeight });
      img.onerror = () => reject(new Error("banner image failed to decode"));
      img.src = dataUrl;
    });
    bannerCache[kind] = { dataUrl, width, height };
  } catch {
    bannerCache[kind] = null;
  }
  return bannerCache[kind] ?? null;
}

function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace("#", "");
  return [
    parseInt(clean.slice(0, 2), 16),
    parseInt(clean.slice(2, 4), 16),
    parseInt(clean.slice(4, 6), 16),
  ];
}

/** Short, human-readable, collision-resistant-enough reference code. */
export function generateReferenceCode(prefix: string): string {
  const stamp = Date.now().toString(36).toUpperCase().slice(-4);
  const rand = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `${prefix}-${stamp}${rand}`;
}

/** Triggers a browser download for a generated PDF Blob. */
export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

// --- Entrance badge ---------------------------------------------------------

export interface BadgeData {
  registrationId: string;
  fullName: string;
  organization?: string;
  ticketType: string;
  day: string;
  /** Overrides for the CMS-editable event particulars (see JmsaConfigPanel.tsx) — falls back to the static fr/en labels below when omitted. */
  eventShortTitle?: string;
  eventFullName?: string;
  eventDates?: string;
}

/**
 * Draws a very light decorative "globe" motif (a few concentric circles +
 * meridian arcs) filling most of the card, in a near-white grey. Drawn
 * first so the header/ribbon bands (painted next, opaque) naturally clip
 * the part that falls under them — the motif only shows through in the
 * lighter attendee/QR area below, exactly where it won't compete with
 * text. Plain stroked shapes only (no image/opacity plugin dependency),
 * so it renders identically in every jsPDF build.
 */
function drawBackgroundMotif(doc: jsPDF): void {
  const faint: [number, number, number] = [237, 240, 244];
  doc.setDrawColor(...faint);
  doc.setLineWidth(0.35);
  const cx = 50;
  const cy = 95;
  [46, 36, 26].forEach((r) => doc.circle(cx, cy, r, "S"));
  // A couple of "meridian" arcs across the main circle, approximated with
  // thin ellipses (jsPDF has no true arc primitive without extra config).
  doc.ellipse(cx, cy, 18, 46, "S");
  doc.ellipse(cx, cy, 46, 18, "S");
}

/**
 * Generates a portrait, card-sized (100×150mm) JMSA 2026 entrance badge:
 * ocean-blue header with logo, gold ticket-type ribbon, attendee name, and
 * a QR code encoding the registration id for the admin panel's badge
 * scanner (Section 5, `QRScannerModal.tsx`) to check attendees in.
 *
 * Visual "real badge" touches (Section 5 follow-up): a dashed lanyard-hole
 * guide, a gold decorative border with rounded corners, a faint globe
 * watermark, and a ticket-style perforated tear line above the footer —
 * all drawn as plain jsPDF vector shapes, nothing printed as an actual
 * functional hole/perforation (that's for whoever laminates the badge to
 * cut along).
 */
export async function generateBadgePdf(data: BadgeData, lang: Lang = "fr"): Promise<Blob> {
  const L = labelsFor(lang);
  const doc = new jsPDF({ unit: "mm", format: [100, 150] });
  const [oceanR, oceanG, oceanB] = hexToRgb(colors.primary);
  const [goldR, goldG, goldB] = hexToRgb(colors.accent);
  const eventFullName = data.eventFullName || L.eventFullName;
  const eventDates = data.eventDates || L.eventDates;
  const eventShortTitle = data.eventShortTitle || "JMSA 2026";

  // Faint background motif — behind everything, clipped by the opaque
  // bands painted next.
  drawBackgroundMotif(doc);

  // Header band
  doc.setFillColor(oceanR, oceanG, oceanB);
  doc.rect(0, 0, 100, 32, "F");

  const logo = await loadLogoDataUrl();
  if (logo) {
    doc.addImage(logo, "PNG", 6, 9, 20, 20);
  }

  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(14);
  doc.text(eventShortTitle, 30, 16);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  doc.text(eventFullName, 30, 22, { maxWidth: 64 });
  doc.text(eventDates, 30, 29, { maxWidth: 64 });

  // Ticket-type ribbon
  doc.setFillColor(goldR, goldG, goldB);
  doc.rect(0, 32, 100, 8, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text(data.ticketType.toUpperCase(), 50, 37.5, { align: "center" });

  // Attendee block
  doc.setTextColor(...hexToRgb(colors.charcoal));
  doc.setFont("helvetica", "bold");
  doc.setFontSize(15);
  doc.text(data.fullName, 50, 56, { align: "center", maxWidth: 90 });

  if (data.organization) {
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.text(data.organization, 50, 63, { align: "center", maxWidth: 90 });
  }

  doc.setFontSize(9);
  doc.setTextColor(90, 90, 90);
  doc.text(`${L.dayLabel} ${data.day}`, 50, 71, { align: "center" });

  // QR code — verification payload for the admin check-in scanner
  const qrPayload = JSON.stringify({
    event: "JMSA2026",
    id: data.registrationId,
    name: data.fullName,
  });
  const qrDataUrl = await QRCode.toDataURL(qrPayload, { margin: 1, width: 320 });
  doc.addImage(qrDataUrl, "PNG", 25, 79, 50, 50);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.setTextColor(...hexToRgb(colors.charcoal));
  doc.text(`${L.registrationPrefix} ${data.registrationId}`, 50, 134, { align: "center" });

  // Ticket-style tear line — a small zigzag across the width, just above
  // the footer, echoing a raffle-ticket stub. Purely decorative.
  doc.setDrawColor(200, 200, 200);
  doc.setLineWidth(0.3);
  const teardY = 137.5;
  const teeth = 24;
  const toothW = 100 / teeth;
  const zigzag: [number, number][] = [];
  for (let i = 0; i <= teeth; i++) {
    zigzag.push([i * toothW, teardY + (i % 2 === 0 ? 0 : 0.8)]);
  }
  for (let i = 0; i < zigzag.length - 1; i++) {
    doc.line(zigzag[i][0], zigzag[i][1], zigzag[i + 1][0], zigzag[i + 1][1]);
  }

  // Footer
  doc.setDrawColor(oceanR, oceanG, oceanB);
  doc.line(8, 141, 92, 141);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  doc.setTextColor(130, 130, 130);
  doc.text(L.organizedBy, 50, 146, {
    align: "center",
    maxWidth: 90,
  });

  // Lanyard hole guide — a dashed circle near the top edge, purely
  // visual: it does NOT punch through the PDF, it just marks where to
  // perforate if the badge is laminated. Drawn after the header so the
  // dashes read clearly against the ocean-blue band.
  doc.setDrawColor(255, 255, 255);
  doc.setLineWidth(0.4);
  doc.setLineDashPattern([0.6, 0.6], 0);
  doc.circle(50, 6, 2.4, "S");
  doc.setLineDashPattern([], 0);

  // Decorative gold border with pronounced rounded corners — drawn last,
  // on top of everything, inset from the trim edge.
  doc.setDrawColor(goldR, goldG, goldB);
  doc.setLineWidth(0.7);
  doc.roundedRect(3, 3, 94, 144, 5, 5, "S");

  return doc.output("blob");
}

// --- Donation receipt --------------------------------------------------------

export interface ReceiptData {
  receiptId: string;
  donorName: string;
  donorEmail?: string;
  amount: string;
  currency?: string;
  method: string;
  /** e.g. "Sponsoring — Sponsor Diamant" or "Billet gala — VIP Or". Defaults to a plain donation receipt when omitted. */
  purpose?: string;
  dateLabel: string;
}

export type ReceiptKind = "sponsoring" | "billet" | "don";

export function detectReceiptKind(purpose?: string): ReceiptKind {
  if (purpose && /sponsor/i.test(purpose)) return "sponsoring";
  if (purpose && /(billet|ticket)/i.test(purpose)) return "billet";
  return "don";
}

/**
 * Generates an A4 provisional donation receipt, issued client-side the
 * moment a transfer proof is submitted (before the association has
 * manually verified the underlying payment — see DonationProofForm.tsx).
 * Doubles as a sponsoring or gala-ticket receipt when `purpose` is set
 * (e.g. from the "Je sponsorise ce tier" / "Je réserve ce billet" flows
 * in JMSAHub.tsx) — same layout, the title, payer label and an extra
 * "Objet" row reflect the tier/ticket instead of a generic donation.
 *
 * Purple/gold "certificate" layout matching the association's official
 * Word receipt template — mirrored server-side (definitive receipt) in
 * netlify/functions/lib/receiptPdf.js, which adds "Vérifié par" / "Date de
 * vérification" rows and swaps the PROVISOIRE tag for DÉFINITIF/FINAL.
 */
export async function generateReceiptPdf(data: ReceiptData, lang: Lang = "fr"): Promise<Blob> {
  const L = labelsFor(lang);
  const P = RECEIPT_PALETTE;
  const [purpleR, purpleG, purpleB] = hexToRgb(P.purpleDark);
  const [purpleMedR, purpleMedG, purpleMedB] = hexToRgb(P.purpleMed);
  const [goldR, goldG, goldB] = hexToRgb(P.gold);
  const [navyR, navyG, navyB] = hexToRgb(P.navy);
  const [greyR, greyG, greyB] = hexToRgb(P.grey);
  const kind = detectReceiptKind(data.purpose);

  const doc = new jsPDF({ unit: "mm", format: "a4" });

  // --- Header: JMSA 2026 banner (replaces the logo + org-name block) ------
  // Positions below the banner are relative to its actual height ("cursor",
  // in mm from the top) rather than a fixed offset — mirrors the
  // server-side layout in netlify/functions/lib/receiptPdf.js so both stages of the
  // receipt (provisional here, definitive on the backend) match exactly.
  let cursor = 36; // fallback gap if the banner is ever missing
  const headerBanner = await loadReceiptBanner("header");
  if (headerBanner) {
    const headerHeightMm = 210 * (headerBanner.height / headerBanner.width);
    doc.addImage(headerBanner.dataUrl, "PNG", 0, 0, 210, headerHeightMm);
    cursor = headerHeightMm + 6;
  }

  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(navyR, navyG, navyB);
  doc.text(ASSOCIATION.legalName, 105, cursor, { align: "center" });
  cursor += 6;

  // --- Title block -------------------------------------------------------
  doc.setTextColor(purpleR, purpleG, purpleB);
  doc.setFont("times", "bold");
  doc.setFontSize(22);
  doc.text(L.receiptTitles[kind], 105, cursor + 10, { align: "center" });

  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.setTextColor(goldR, goldG, goldB);
  doc.text(L.statusProvisional, 105, cursor + 18, { align: "center" });

  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(purpleMedR, purpleMedG, purpleMedB);
  doc.text(L.tagline, 105, cursor + 25, { align: "center" });
  cursor += 32;

  doc.setFillColor(goldR, goldG, goldB);
  doc.rect(15, cursor + 5, 180, 5, "F");
  cursor += 13;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(greyR, greyG, greyB);
  doc.text(`${ASSOCIATION.address}  ·  ${L.companyLine(ASSOCIATION.companyNumber, ASSOCIATION.vatNumber)}`, 15, cursor, {
    maxWidth: 180,
  });
  cursor += 8;

  // --- Information / Value table -----------------------------------------
  const tableLeft = 15;
  const tableWidth = 180;
  const labelColWidth = 62;
  const rowHeight = 8;
  let y = cursor;

  doc.setFillColor(purpleR, purpleG, purpleB);
  doc.rect(tableLeft, y, tableWidth, rowHeight, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(255, 255, 255);
  doc.text(L.tableHeaderInfo, tableLeft + 5, y + rowHeight / 2 + 1.5);
  doc.text(L.tableHeaderValue, tableLeft + labelColWidth + 5, y + rowHeight / 2 + 1.5);
  y += rowHeight;

  let rowIndex = 0;
  const row = (label: string, value: string) => {
    if (rowIndex % 2 === 0) {
      doc.setFillColor(...P.rowTint);
      doc.rect(tableLeft, y, tableWidth, rowHeight, "F");
    }
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(navyR, navyG, navyB);
    doc.text(label, tableLeft + 5, y + rowHeight / 2 + 1.5);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(40, 40, 40);
    doc.text(value, tableLeft + labelColWidth + 5, y + rowHeight / 2 + 1.5, {
      maxWidth: tableWidth - labelColWidth - 10,
    });
    y += rowHeight;
    rowIndex += 1;
  };

  row(L.reference, data.receiptId);
  row(L.payerLabels[kind], data.donorName);
  if (data.donorEmail) row(L.email, data.donorEmail);
  if (data.purpose) row(L.purpose, data.purpose);
  row(L.date, data.dateLabel);
  row(L.paymentMethod, data.method);
  row(L.amount, `${data.amount} ${data.currency ?? "EUR"}`);

  // --- Certification box ---------------------------------------------------
  y += 8;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(goldR, goldG, goldB);
  doc.text(L.certificationHeading, tableLeft, y);
  y += 4;

  const boxTop = y;
  const boxHeight = 24;
  doc.setDrawColor(goldR, goldG, goldB);
  doc.setLineWidth(0.5);
  doc.rect(tableLeft, boxTop, tableWidth, boxHeight);
  doc.setLineWidth(0.2);

  doc.setFont("helvetica", "italic");
  doc.setFontSize(8.5);
  doc.setTextColor(greyR, greyG, greyB);
  doc.text(L.provisionalNotice, tableLeft + 5, boxTop + 7, { maxWidth: tableWidth - 10, lineHeightFactor: 1.5 });

  // --- Signature / thank-you row --------------------------------------------
  const sigY = boxTop + boxHeight + 16;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(navyR, navyG, navyB);
  doc.text(L.signatureLabel, tableLeft, sigY);

  doc.setDrawColor(goldR, goldG, goldB);
  doc.line(tableLeft, sigY + 10, tableLeft + 55, sigY + 10);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.text(ASSOCIATION.shortName, tableLeft + 27.5, sigY + 15, { align: "center" });

  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(navyR, navyG, navyB);
  doc.text(L.thankYouTitle, 150, sigY, { align: "center" });
  doc.setFont("helvetica", "italic");
  doc.setFontSize(8.5);
  doc.setTextColor(greyR, greyG, greyB);
  doc.text(L.thankYouSubtitle, 150, sigY + 6, { align: "center", maxWidth: 90 });

  // --- Footer: JMSA 2026 banner (replaces the plain purple contact band) --
  const footerBanner = await loadReceiptBanner("footer");
  if (footerBanner) {
    const footerHeightMm = 210 * (footerBanner.height / footerBanner.width);
    doc.addImage(footerBanner.dataUrl, "PNG", 0, 297 - footerHeightMm, 210, footerHeightMm);
  }

  return doc.output("blob");
}
