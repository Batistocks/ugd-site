import { isFirebaseConfigured } from "./firebaseConfig";

/**
 * MODE DÉMO — panneau admin sans Firebase ni backend.
 *
 * Activé AUTOMATIQUEMENT quand le site est construit sans configuration
 * (ni VITE_FIREBASE_*, ni VITE_API_BASE_URL) : c'est le cas d'un simple
 * glisser-déposer du dossier `dist/` sur Netlify, sans variables.
 * Dès qu'une vraie configuration est présente, le mode démo disparaît
 * tout seul et le site se comporte comme en production.
 *
 * En mode démo :
 *  - la connexion admin se fait en un clic (aucun e-mail, aucun lien) ;
 *  - toutes les modifications du panneau (espaces, flyers, documents,
 *    config JMSA, coordonnées bancaires, intervenants, compteurs…) sont
 *    enregistrées UNIQUEMENT dans le navigateur de cet appareil
 *    (IndexedDB / localStorage) — les autres visiteurs ne les voient pas ;
 *  - les inscriptions et preuves de paiement envoyées depuis ce même
 *    appareil apparaissent dans les panneaux « Inscriptions » et « Dons »,
 *    avec génération réelle du reçu et du badge PDF.
 */

const hasBackendUrl = Boolean(import.meta.env.VITE_API_BASE_URL);

export const isDemoMode: boolean = !isFirebaseConfigured && !hasBackendUrl;

export const DEMO_ADMIN_EMAIL = "demo@ungestedivin.org";

// --- Tiny typed localStorage helpers -----------------------------------------

export function readDemo<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(`ugd:demo:${key}`);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function writeDemo<T>(key: string, value: T): void {
  try {
    window.localStorage.setItem(`ugd:demo:${key}`, JSON.stringify(value));
  } catch {
    // Quota exceeded or storage blocked — demo data simply isn't persisted.
  }
}

export function removeDemo(key: string): void {
  try {
    window.localStorage.removeItem(`ugd:demo:${key}`);
  } catch {
    /* ignore */
  }
}

/** Erases every demo record (session, team list, registrations, donations). */
export function resetDemoData(): void {
  try {
    Object.keys(window.localStorage)
      .filter((k) => k.startsWith("ugd:demo:"))
      .forEach((k) => window.localStorage.removeItem(k));
  } catch {
    /* ignore */
  }
}

// --- Demo records (stand-ins for the Firestore "registrations"/"donations") ---

export interface DemoRegistration {
  registrationId: string;
  fullName: string;
  email: string | null;
  phone: string | null;
  organization: string | null;
  day: string | null;
  ticketType: string | null;
  lang: "fr" | "en";
  status: string;
  checkedIn: boolean;
  checkedInAt: number | null;
  checkedInBy: string | null;
  createdAt: number | null;
  clientCreatedAt: number | null;
}

export interface DemoDonation {
  receiptId: string;
  donorName: string;
  email: string | null;
  phone: string | null;
  amount: string;
  currency: string;
  method: string | null;
  context: string;
  kind: "sponsoring" | "billet" | "don";
  proofFileName: string | null;
  proofUrl: string | null;
  status: "en_attente" | "verifie";
  createdAt: number | null;
  verifiedAt: number | null;
  verifiedBy: string | null;
  receiptPdfUrl: string | null;
  ticketName: string | null;
  badgePdfUrl: string | null;
  checkedIn: boolean;
  checkedInAt: number | null;
  checkedInBy: string | null;
}

const REG_KEY = "registrations";
const DON_KEY = "donations";

export function demoRegistrations(): DemoRegistration[] {
  return readDemo<DemoRegistration[]>(REG_KEY, []);
}
export function saveDemoRegistrations(list: DemoRegistration[]): void {
  writeDemo(REG_KEY, list);
}
export function demoDonations(): DemoDonation[] {
  return readDemo<DemoDonation[]>(DON_KEY, []);
}
export function saveDemoDonations(list: DemoDonation[]): void {
  writeDemo(DON_KEY, list);
}

function detectKind(context: string, ticketName: string | null): DemoDonation["kind"] {
  if (/sponsor/i.test(context)) return "sponsoring";
  if (ticketName || /(billet|ticket)/i.test(context)) return "billet";
  return "don";
}

/**
 * Called by the sync manager in demo mode instead of POSTing to Netlify
 * Functions: files the queued form into the local demo lists.
 */
export function storeQueuedPayloadForDemo(type: string, payload: Record<string, unknown>): void {
  const str = (v: unknown): string | null => (typeof v === "string" && v.trim() ? v.trim() : null);

  if (type === "pass-request") {
    const id = str(payload.registrationId);
    if (!id) return;
    const list = demoRegistrations();
    if (list.some((r) => r.registrationId === id)) return;
    list.unshift({
      registrationId: id,
      fullName: str(payload.fullName) ?? "—",
      email: str(payload.email),
      phone: str(payload.phone),
      organization: str(payload.organization),
      day: str(payload.day),
      ticketType: str(payload.ticketType),
      lang: payload.lang === "en" ? "en" : "fr",
      status: "en_attente",
      checkedIn: false,
      checkedInAt: null,
      checkedInBy: null,
      createdAt: Date.now(),
      clientCreatedAt: typeof payload.createdAt === "number" ? payload.createdAt : null,
    });
    saveDemoRegistrations(list);
    return;
  }

  if (type === "donation-proof") {
    const id = str(payload.receiptId);
    if (!id) return;
    const list = demoDonations();
    if (list.some((d) => d.receiptId === id)) return;
    const context = str(payload.context) ?? "";
    const ticketName = str(payload.ticketName);
    const kind = detectKind(context, ticketName);
    list.unshift({
      receiptId: id,
      donorName: str(payload.donorName) ?? "—",
      email: str(payload.email),
      phone: str(payload.phone),
      amount: String(payload.amount ?? ""),
      currency: "EUR",
      method: str(payload.method),
      context,
      kind,
      proofFileName: str(payload.proofFileName),
      proofUrl: str(payload.proofDataUrl),
      status: "en_attente",
      createdAt: Date.now(),
      verifiedAt: null,
      verifiedBy: null,
      receiptPdfUrl: null,
      ticketName: kind === "billet" ? ticketName : null,
      badgePdfUrl: null,
      checkedIn: false,
      checkedInAt: null,
      checkedInBy: null,
    });
    saveDemoDonations(list);
  }
}
