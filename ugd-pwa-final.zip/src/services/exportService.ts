import { downloadBlob } from "./pdfService";
import { getPendingMutations, listAuditLog, listCheckins } from "./db";
import { listAdmins } from "./authService";
import { getSpaces, getJmsaConfig, getFlyers, getBankOverrides } from "./cmsService";
import { recordAuditEvent } from "./auditLog";

/**
 * One-click Database Export (JSON/CSV) & audit logs.
 * Section 5: Secret Admin Panel & CMS Management.
 */

function timestampSlug(): string {
  return new Date().toISOString().replace(/[:.]/g, "-");
}

function toCsv(rows: Record<string, unknown>[]): string {
  if (rows.length === 0) return "";
  const headers = Object.keys(rows[0]);
  const escape = (value: unknown) => {
    const str = value === undefined || value === null ? "" : String(value);
    return /[",\n]/.test(str) ? `"${str.replace(/"/g, '""')}"` : str;
  };
  const lines = [headers.join(",")];
  for (const row of rows) lines.push(headers.map((h) => escape(row[h])).join(","));
  return lines.join("\n");
}

/** Exports the whole admin-relevant dataset as a single JSON file. Never includes password hashes. */
export async function exportDatabaseJson(actorEmail: string): Promise<void> {
  const [pending, auditLog, checkins, admins, spaces, jmsaConfig, flyers, bank] = await Promise.all([
    getPendingMutations(),
    listAuditLog(1000),
    listCheckins(),
    listAdmins(),
    getSpaces(),
    getJmsaConfig(),
    getFlyers(),
    getBankOverrides(),
  ]);

  const payload = {
    exportedAt: new Date().toISOString(),
    exportedBy: actorEmail,
    cms: { spaces, jmsaConfig, flyers, bank },
    checkins,
    auditLog,
    pendingSyncQueue: pending,
    admins: admins.map((a) => ({ email: a.email, createdAt: a.createdAt, createdBy: a.createdBy })),
  };

  downloadBlob(
    new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }),
    `ugd-export-${timestampSlug()}.json`,
  );
  await recordAuditEvent(actorEmail, "export.json", `${checkins.length} check-ins, ${auditLog.length} entrées de journal`);
}

/** Exports the attendee check-in list as CSV. */
export async function exportCheckinsCsv(actorEmail: string): Promise<void> {
  const checkins = await listCheckins();
  const csv = toCsv(
    checkins.map((c) => ({
      registrationId: c.registrationId,
      fullName: c.fullName,
      checkedInAt: new Date(c.checkedInAt).toISOString(),
      checkedInBy: c.checkedInBy,
    })),
  );
  downloadBlob(new Blob([csv], { type: "text/csv" }), `ugd-checkins-${timestampSlug()}.csv`);
  await recordAuditEvent(actorEmail, "export.csv-checkins", `${checkins.length} lignes`);
}

/** Exports the audit log as CSV. */
export async function exportAuditLogCsv(actorEmail: string): Promise<void> {
  const log = await listAuditLog(2000);
  const csv = toCsv(
    log.map((entry) => ({
      timestamp: new Date(entry.timestamp).toISOString(),
      actorEmail: entry.actorEmail,
      action: entry.action,
      details: entry.details ?? "",
    })),
  );
  downloadBlob(new Blob([csv], { type: "text/csv" }), `ugd-audit-log-${timestampSlug()}.csv`);
  await recordAuditEvent(actorEmail, "export.csv-audit", `${log.length} lignes`);
}
