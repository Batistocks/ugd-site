import { openDB, type DBSchema, type IDBPDatabase } from "idb";

/**
 * Local persistence for offline data queuing.
 * Section 2: PWA Core & Offline-First Infrastructure.
 * Extended in Section 5 (Secret Admin Panel & CMS Management) with the
 * admin/CMS-facing stores below.
 *
 * Stores:
 *  - `syncQueue`     : pending writes (donation proofs, pass requests, form
 *                      submissions) made while offline, waiting to be pushed
 *                      to the backend once connectivity returns.
 *  - `cachedContent` : read-side cache AND CMS-editable content (bank
 *                      details, mobile money numbers, section titles, tab
 *                      order, flyers metadata) so the public pages render
 *                      fully even with no network, and so admin edits made
 *                      in the CMS (Section 5) apply instantly across the app.
 *  - `adminAccounts` : LEGACY, unused. Admin accounts now live in Firestore
 *                      (see services/authService.ts); the store is only kept
 *                      so existing installs upgrade their local database.
 *  - `auditLog`      : append-only trail of admin actions (login, CMS
 *                      edits, check-ins, exports).
 *  - `checkins`      : JMSA 2026 attendee check-in records, written by the
 *                      admin panel's QR badge scanner.
 */

export interface QueuedMutation {
  id?: number;
  type: "donation-proof" | "pass-request" | "contact-form" | "generic";
  payload: Record<string, unknown>;
  createdAt: number;
  attempts: number;
  lastError?: string;
}

export interface CachedContentEntry {
  key: string; // e.g. "bank-accounts", "cms:site-config", "cms:flyers"
  value: unknown;
  updatedAt: number;
}

export interface AdminAccountRecord {
  email: string; // lowercased, primary key
  passwordHash: string;
  salt: string;
  createdAt: number;
  createdBy: string; // email of the admin who added this account, or "bootstrap"
}

export interface AuditLogRecord {
  id?: number;
  actorEmail: string;
  action: string;
  details?: string;
  timestamp: number;
}

export interface CheckinRecord {
  registrationId: string; // primary key, matches the QR badge payload id
  fullName: string;
  checkedInAt: number;
  checkedInBy: string;
}

interface UGDDatabase extends DBSchema {
  syncQueue: {
    key: number;
    value: QueuedMutation;
    indexes: { "by-createdAt": number };
  };
  cachedContent: {
    key: string;
    value: CachedContentEntry;
  };
  adminAccounts: {
    key: string;
    value: AdminAccountRecord;
  };
  auditLog: {
    key: number;
    value: AuditLogRecord;
    indexes: { "by-timestamp": number };
  };
  checkins: {
    key: string;
    value: CheckinRecord;
  };
}

const DB_NAME = "ugd-offline-db";
const DB_VERSION = 2;

let dbPromise: Promise<IDBPDatabase<UGDDatabase>> | null = null;

export function getDB(): Promise<IDBPDatabase<UGDDatabase>> {
  if (!dbPromise) {
    dbPromise = openDB<UGDDatabase>(DB_NAME, DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains("syncQueue")) {
          const store = db.createObjectStore("syncQueue", {
            keyPath: "id",
            autoIncrement: true,
          });
          store.createIndex("by-createdAt", "createdAt");
        }
        if (!db.objectStoreNames.contains("cachedContent")) {
          db.createObjectStore("cachedContent", { keyPath: "key" });
        }
        if (!db.objectStoreNames.contains("adminAccounts")) {
          db.createObjectStore("adminAccounts", { keyPath: "email" });
        }
        if (!db.objectStoreNames.contains("auditLog")) {
          const store = db.createObjectStore("auditLog", {
            keyPath: "id",
            autoIncrement: true,
          });
          store.createIndex("by-timestamp", "timestamp");
        }
        if (!db.objectStoreNames.contains("checkins")) {
          db.createObjectStore("checkins", { keyPath: "registrationId" });
        }
      },
    });
  }
  return dbPromise;
}

// --- Sync queue -----------------------------------------------------------

export async function enqueueMutation(
  type: QueuedMutation["type"],
  payload: Record<string, unknown>,
): Promise<number> {
  const db = await getDB();
  const id = await db.add("syncQueue", {
    type,
    payload,
    createdAt: Date.now(),
    attempts: 0,
  });
  return id as number;
}

export async function getPendingMutations(): Promise<QueuedMutation[]> {
  const db = await getDB();
  return db.getAllFromIndex("syncQueue", "by-createdAt");
}

export async function removeMutation(id: number): Promise<void> {
  const db = await getDB();
  await db.delete("syncQueue", id);
}

export async function markMutationFailed(id: number, error: string): Promise<void> {
  const db = await getDB();
  const record = await db.get("syncQueue", id);
  if (!record) return;
  record.attempts += 1;
  record.lastError = error;
  await db.put("syncQueue", record);
}

export async function countPendingMutations(): Promise<number> {
  const db = await getDB();
  return db.count("syncQueue");
}

// --- Read-side content cache ------------------------------------------------

export async function setCachedContent(key: string, value: unknown): Promise<void> {
  const db = await getDB();
  await db.put("cachedContent", { key, value, updatedAt: Date.now() });
}

export async function getCachedContent<T = unknown>(key: string): Promise<T | undefined> {
  const db = await getDB();
  const entry = await db.get("cachedContent", key);
  return entry?.value as T | undefined;
}

// NOTE: admin accounts used to live here (local-only whitelist). They now
// live in Firestore instead, shared by the whole team — see
// services/authService.ts. The `adminAccounts` IndexedDB store above is
// kept only so existing installs don't break their local database
// upgrade; it's no longer read or written anywhere in the app.

// --- Audit log ---------------------------------------------------------------

export async function appendAuditLog(record: Omit<AuditLogRecord, "id">): Promise<void> {
  const db = await getDB();
  await db.add("auditLog", record);
}

export async function listAuditLog(limit = 200): Promise<AuditLogRecord[]> {
  const db = await getDB();
  const all = await db.getAllFromIndex("auditLog", "by-timestamp");
  return all.reverse().slice(0, limit);
}

// --- JMSA 2026 check-ins -----------------------------------------------------

export async function getCheckin(registrationId: string): Promise<CheckinRecord | undefined> {
  const db = await getDB();
  return db.get("checkins", registrationId);
}

export async function putCheckin(record: CheckinRecord): Promise<void> {
  const db = await getDB();
  await db.put("checkins", record);
}

export async function listCheckins(): Promise<CheckinRecord[]> {
  const db = await getDB();
  return db.getAll("checkins");
}
