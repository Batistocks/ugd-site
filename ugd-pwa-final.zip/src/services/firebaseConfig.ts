import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

/**
 * Firebase project connection — Admin login & team whitelist ONLY.
 *
 * On purpose, this uses only two Firebase pieces that are entirely free,
 * with no credit card and no "Blaze" plan required:
 *   - Authentication (the passwordless email-link sign-in)
 *   - Firestore, but only the `admins` collection, read/written directly
 *     from the browser under the rules in `firestore.rules`
 *
 * The donations/CMS features described in README-BACKEND.md are a
 * separate concern: they go through Netlify Functions (free, no Blaze
 * plan) and never use this browser-side connection.
 *
 * Fill in the values below from your own free Firebase project:
 * https://console.firebase.google.com → project settings (the gear icon)
 * → "General" tab → scroll to "Your apps" → add a "Web" app → it shows
 * you this exact block of values. Put them in `.env` (see .env.example),
 * never commit the real `.env` file.
 */
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY as string,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN as string,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID as string,
  appId: import.meta.env.VITE_FIREBASE_APP_ID as string,
};

/**
 * True only when all four VITE_FIREBASE_* values were provided at build
 * time. Deployments made without a configured Firebase project (e.g. a
 * quick Netlify trial) can still serve the public site — they just skip
 * Firebase init entirely instead of crashing on an invalid/empty config,
 * which used to blank out the whole app before React ever rendered.
 */
export const isFirebaseConfigured = Boolean(
  firebaseConfig.apiKey &&
    firebaseConfig.authDomain &&
    firebaseConfig.projectId &&
    firebaseConfig.appId,
);

export const firebaseApp = isFirebaseConfigured ? initializeApp(firebaseConfig) : null;
export const auth = firebaseApp ? getAuth(firebaseApp) : null;
export const firestore = firebaseApp ? getFirestore(firebaseApp) : null;
