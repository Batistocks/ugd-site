import {
  getPendingMutations,
  removeMutation,
  markMutationFailed,
  type QueuedMutation,
} from "./db";
import { isDemoMode, storeQueuedPayloadForDemo } from "./demoMode";

/**
 * Offline Sync Manager.
 * Section 2: PWA Core & Offline-First Infrastructure.
 *
 * Every write made while offline (donation proof uploads, JMSA 2026 pass
 * requests, contact form submissions) is queued in IndexedDB via
 * `enqueueMutation` (see db.ts). Once the browser regains connectivity,
 * this module drains that queue against the backend, one mutation at a
 * time, so nothing is lost and nothing is duplicated.
 *
 * The actual backend endpoint is intentionally abstracted behind
 * `sendToBackend` — plug in Firestore, a REST API, or any other target
 * without touching the queueing logic above.
 */

const MAX_ATTEMPTS = 5;

type SyncListener = (status: SyncStatus) => void;

export interface SyncStatus {
  isSyncing: boolean;
  pending: number;
  lastSyncedAt: number | null;
  lastError: string | null;
}

let status: SyncStatus = {
  isSyncing: false,
  pending: 0,
  lastSyncedAt: null,
  lastError: null,
};

const listeners = new Set<SyncListener>();

function emit() {
  listeners.forEach((listener) => listener(status));
}

export function subscribeSyncStatus(listener: SyncListener): () => void {
  listeners.add(listener);
  listener(status);
  return () => listeners.delete(listener);
}

/**
 * Base URL of the Netlify Functions backend (see /netlify/functions and
 * README-BACKEND.md), i.e. "/.netlify/functions".
 * Configured via VITE_API_BASE_URL (.env). Left empty, donation proofs stay
 * queued locally forever (never synced) — the app keeps working offline,
 * it just won't reach the association until the backend is deployed and
 * this variable is set.
 */
const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL as string | undefined)?.replace(/\/$/, "");

/**
 * Pushes one queued mutation to the real backend. "donation-proof" and
 * "pass-request" are both wired to live endpoints (Netlify Functions
 * `submitProof` / `submitPassRequest`, see /netlify/functions) — each
 * writes to its own Firestore collection so the association's admin panel
 * can review it ("Dons à vérifier" / "Inscriptions"). `contact-form` has no
 * endpoint yet and falls back to the generic `/api/sync/*` placeholder —
 * it will keep retrying (harmlessly, up to MAX_ATTEMPTS) until one exists.
 *
 * Previously `pass-request` fell into that same generic placeholder too —
 * that was the actual bug: registrations were queued locally, retried
 * silently against a route that never existed, and dropped after
 * MAX_ATTEMPTS with no server ever seeing them. Fixed by giving it its own
 * branch below, exactly like donation-proof.
 *
 * Throwing here signals a failed attempt and keeps the mutation queued.
 */
async function sendToBackend(mutation: QueuedMutation): Promise<void> {
  // Mode démo (aucun backend) : la demande est rangée dans les listes locales
  // de la démo, visibles ensuite dans les panneaux Inscriptions / Dons.
  if (isDemoMode && (mutation.type === "donation-proof" || mutation.type === "pass-request")) {
    storeQueuedPayloadForDemo(mutation.type, mutation.payload);
    return;
  }
  if (mutation.type === "donation-proof" || mutation.type === "pass-request") {
    if (!API_BASE_URL) {
      throw new Error("Backend non configuré (VITE_API_BASE_URL manquant) — la demande reste en attente.");
    }
    const endpoint = mutation.type === "donation-proof" ? "submitProof" : "submitPassRequest";
    const response = await fetch(`${API_BASE_URL}/${endpoint}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(mutation.payload),
    });
    if (!response.ok) {
      // Permanent refusals — retrying can never succeed, so drop them at once:
      //  403 = registrations closed (jmsa-2026 space disabled),
      //  400 = invalid data (e.g. phone without country code),
      //  413 = proof file too large.
      // 429 (rate limit) and 5xx stay retryable.
      if (response.status === 403 || response.status === 400 || response.status === 413) {
        const data = await response.json().catch(() => ({}));
        const refused = new Error(data.error || `Demande refusée (${response.status}).`) as Error & { permanent?: boolean };
        refused.permanent = true;
        throw refused;
      }
      throw new Error(`Sync failed with status ${response.status}`);
    }
    return;
  }

  const response = await fetch(`/api/sync/${mutation.type}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(mutation.payload),
  });
  if (!response.ok) {
    throw new Error(`Sync failed with status ${response.status}`);
  }
}

export async function syncQueue(): Promise<void> {
  if (status.isSyncing) return;
  if (!navigator.onLine) return;

  const pending = await getPendingMutations();
  status = { ...status, isSyncing: true, pending: pending.length };
  emit();

  for (const mutation of pending) {
    if (!navigator.onLine) break; // connection dropped mid-sync
    try {
      await sendToBackend(mutation);
      if (mutation.id !== undefined) await removeMutation(mutation.id);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Erreur de synchronisation";
      const isPermanent = err instanceof Error && (err as Error & { permanent?: boolean }).permanent === true;
      if (mutation.id !== undefined) {
        await markMutationFailed(mutation.id, message);
        if (isPermanent || mutation.attempts + 1 >= MAX_ATTEMPTS) {
          // Give up on this one so a single bad record can't block the queue
          // forever — immediately for permanent failures (e.g. registrations
          // closed), otherwise after MAX_ATTEMPTS retries.
          await removeMutation(mutation.id);
        }
      }
      status = { ...status, lastError: message };
    }
  }

  const remaining = await getPendingMutations();
  status = {
    isSyncing: false,
    pending: remaining.length,
    lastSyncedAt: Date.now(),
    lastError: status.lastError,
  };
  emit();
}

let initialized = false;

/**
 * Wires up automatic sync: on reconnect, on app start, and periodically
 * as a safety net (in case the `online` event is missed by the platform).
 */
export function initSyncManager(pollIntervalMs = 60_000): () => void {
  if (initialized) return () => undefined;
  initialized = true;

  const onOnline = () => void syncQueue();
  window.addEventListener("online", onOnline);

  void syncQueue();
  const interval = window.setInterval(() => void syncQueue(), pollIntervalMs);

  return () => {
    window.removeEventListener("online", onOnline);
    window.clearInterval(interval);
    initialized = false;
  };
}
