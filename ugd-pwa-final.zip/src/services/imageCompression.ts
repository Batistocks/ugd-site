// UGD (Un Geste Divin) — image compression before upload.
//
// Runs entirely in the browser (Canvas API, no dependency, works
// offline) before a file reaches either Cloudinary (Section 6) or the
// local data-URL fallback (Section 5's `FlyerMediaPanel.tsx`). Goal: get
// every photo under ~200 KB without the soft, blocky look of naive
// "just crank down the JPEG quality" compression.
//
// Strategy, in order:
//   1. Cap the longest edge at MAX_DIMENSION (1920px) — most of the
//      savings come from resolution, not quality, and 1920px is already
//      far more than a phone screen or a flyer thumbnail ever displays.
//   2. Re-encode as JPEG, walking quality down from a high starting
//      point in small steps until the target size is hit.
//   3. Only if quality alone can't reach the target without falling
//      below a "still looks professional" quality floor, step the
//      dimension down further (in stages) and retry — this keeps
//      contrast/detail crisp instead of producing visible artifacting.
//
// A file that's already small and under the target is left untouched
// (compressing further would only lose quality for no size benefit).

export interface CompressImageOptions {
  /** Target size in bytes. Default 200 KB. */
  targetBytes?: number;
  /** Longest-edge cap in pixels before any quality reduction. Default 1920. */
  maxDimension?: number;
  /** Never drop JPEG quality below this, even if still over target (protects visible sharpness). Default 0.6. */
  minQuality?: number;
}

export interface CompressImageResult {
  file: File;
  originalBytes: number;
  compressedBytes: number;
  width: number;
  height: number;
  quality: number;
}

const DEFAULTS: Required<CompressImageOptions> = {
  targetBytes: 200 * 1024,
  maxDimension: 1920,
  minQuality: 0.6,
};

// Dimension fallback ladder used only if the quality floor is reached
// before the target size — each step still comfortably exceeds typical
// display sizes (gallery thumbnail, flyer lightbox, social share).
const DIMENSION_STEPS = [1920, 1600, 1280, 1024, 800];

function loadImage(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Impossible de lire l'image (fichier corrompu ou format non supporté)."));
    };
    img.src = url;
  });
}

function drawScaled(img: HTMLImageElement, maxDimension: number): HTMLCanvasElement {
  const scale = Math.min(1, maxDimension / Math.max(img.naturalWidth, img.naturalHeight));
  const width = Math.round(img.naturalWidth * scale);
  const height = Math.round(img.naturalHeight * scale);

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas 2D non disponible dans ce navigateur.");
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(img, 0, 0, width, height);
  return canvas;
}

function canvasToBlob(canvas: HTMLCanvasElement, quality: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => (blob ? resolve(blob) : reject(new Error("Échec de l'encodage JPEG."))),
      "image/jpeg",
      quality,
    );
  });
}

/**
 * Compresses an image file to (approximately) `targetBytes`, resizing
 * and/or reducing JPEG quality as needed. Returns a new `File` — the
 * original is never mutated.
 *
 * Non-image files are rejected; if the input is already smaller than
 * the target, it's returned unchanged (no re-encoding, no quality loss).
 */
export async function compressImage(
  file: File,
  options: CompressImageOptions = {},
): Promise<CompressImageResult> {
  if (!file.type.startsWith("image/")) {
    throw new Error("compressImage: le fichier fourni n'est pas une image.");
  }

  const { targetBytes, maxDimension, minQuality } = { ...DEFAULTS, ...options };

  if (file.size <= targetBytes) {
    const img = await loadImage(file);
    return {
      file,
      originalBytes: file.size,
      compressedBytes: file.size,
      width: img.naturalWidth,
      height: img.naturalHeight,
      quality: 1,
    };
  }

  const img = await loadImage(file);
  const dimensionCandidates = DIMENSION_STEPS.filter((d) => d <= maxDimension);
  if (dimensionCandidates.length === 0 || dimensionCandidates[0] !== maxDimension) {
    dimensionCandidates.unshift(maxDimension);
  }

  let best: { blob: Blob; quality: number; width: number; height: number } | null = null;

  for (const dimension of dimensionCandidates) {
    const canvas = drawScaled(img, dimension);
    let quality = 0.92;
    let blob = await canvasToBlob(canvas, quality);

    // Walk quality down in steps of 0.08 until under target or floor reached.
    while (blob.size > targetBytes && quality > minQuality) {
      quality = Math.max(minQuality, quality - 0.08);
      blob = await canvasToBlob(canvas, quality);
    }

    best = { blob, quality, width: canvas.width, height: canvas.height };

    if (blob.size <= targetBytes) break; // hit the target without needing a smaller dimension
    // Otherwise: quality floor was reached at this dimension and it's
    // still over target — loop continues to the next, smaller dimension.
  }

  if (!best) {
    throw new Error("compressImage: échec inattendu de la compression.");
  }

  const compressedFile = new File(
    [best.blob],
    file.name.replace(/\.[^.]+$/, "") + ".jpg",
    { type: "image/jpeg", lastModified: Date.now() },
  );

  return {
    file: compressedFile,
    originalBytes: file.size,
    compressedBytes: compressedFile.size,
    width: best.width,
    height: best.height,
    quality: best.quality,
  };
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} o`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} Ko`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} Mo`;
}
