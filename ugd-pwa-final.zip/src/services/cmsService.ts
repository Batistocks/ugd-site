import { getCachedContent, setCachedContent } from "./db";
import { recordAuditEvent } from "./auditLog";
import { adminFetch } from "./adminApiClient";
import { bankAccount as defaultBankAccount } from "../data/donationAccounts";

/**
 * CMS Controls — Espaces (Section/Space) Manager, Flyer & Media Manager,
 * Bank/Mobile Money Account Editor, JMSA event configuration.
 * Section 5: Secret Admin Panel & CMS Management.
 *
 * Everything below is backed by one shared Firestore doc (`settings/site`)
 * via the `getSpaces`/`setSpaces` Netlify Functions (netlify/functions/) —
 * spaces, JMSA config, flyers, and bank/mobile money details all live
 * there now. Every visitor's browser fetches this on load, so a change
 * made by the admin reaches every visitor, not just their own device.
 * IndexedDB (`cachedContent`, under the `cms:site-config` key) is still
 * used as a local cache for instant paint + offline fallback, but the
 * source of truth is Firestore.
 */

const KEY_SITE_CONFIG = "cms:site-config";

const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL as string | undefined)?.replace(/\/$/, "");

type Listener<T> = (value: T) => void;

function createStore<T>(key: string, defaultValue: T) {
  let cache: T = defaultValue;
  let loaded = false;
  const listeners = new Set<Listener<T>>();

  async function ensureLoaded(): Promise<T> {
    if (!loaded) {
      const stored = await getCachedContent<T>(key);
      cache = stored ?? defaultValue;
      loaded = true;
    }
    return cache;
  }

  async function get(): Promise<T> {
    return ensureLoaded();
  }

  async function set(value: T): Promise<void> {
    cache = value;
    loaded = true;
    await setCachedContent(key, value);
    listeners.forEach((l) => l(cache));
  }

  function subscribe(listener: Listener<T>): () => void {
    listeners.add(listener);
    ensureLoaded().then((value) => listener(value));
    return () => listeners.delete(listener);
  }

  return { get, set, subscribe };
}

// --- Espaces (public tabs: system modules + admin-made content tabs) -------
//
// One ordered list, `spaces`, drives the *entire* public nav — there is no
// tab that lives outside it any more. Five kinds share the list:
//  - "home"    : the Accueil/HeroSection tab. Singleton (one id, "accueil").
//  - "founder" : the Fondatrice tab (founder bio PDF reader). Singleton
//                ("fondatrice").
//  - "contact" : the Contact tab. Singleton ("contact").
//  - "module"  : one of the 4 built-in bespoke sections (jmsa-2026, dons,
//                missions, mediatheque) — each backed by real feature code
//                (registration form, donation form…).
//  - "custom"  : an admin-created generic content tab (title + free text +
//                optional image URLs).
//
// Every space — system or custom — is renamable, reorderable (drag or
// arrows), and can be enabled/disabled or fully deleted from the admin
// "Espaces" panel, with one floor: the list can never be emptied out
// completely (EspacesPanel blocks deleting/disabling the very last visible
// tab, the same spirit as the "can't remove the last admin" guard). A
// deleted system tab (home/founder/contact/module) can always be brought
// back from its default via the "Restaurer" picker in that panel — its
// feature code never goes away, only its nav entry does. A deleted
// "custom" tab is gone for good, like any free-form content.
//
// Older data saved before this unification (a `spaces` array with only the
// 4 modules, plus a separate `fixedTabs.accueil/contact`) is migrated
// automatically on read — see `migrateLegacySpaces` below and its mirror in
// netlify/functions/lib/siteConfig.js — so nothing needs to be hand-edited
// in Firestore.

export const MODULE_IDS = ["jmsa-2026", "dons", "missions", "mediatheque"] as const;
export type ModuleId = (typeof MODULE_IDS)[number];
export type SectionId = ModuleId; // kept for back-compat with older call sites

export type SpaceKind = "home" | "founder" | "contact" | "module" | "custom";

/** The three singleton system ids that used to live outside `spaces`. */
export const SYSTEM_SPACE_IDS = ["accueil", "fondatrice", "contact"] as const;

export interface Space {
  id: string;
  kind: SpaceKind;
  enabled: boolean;
  title: string; // French title — always shown when lang is "fr", and the
  // fallback for "en" whenever titleEn hasn't been filled in.
  titleEn?: string; // English title, admin-editable. Optional so spaces
  // saved before this field existed (or never translated) keep working —
  // the UI falls back to `title` (see resolveSpaceLabel in App.tsx).
  body?: string; // custom spaces only — French free text, line breaks preserved
  bodyEn?: string; // custom spaces only — English free text, same fallback rule as titleEn
  images?: string[]; // custom spaces only — image URLs, shared across languages
}

export interface JmsaConfig {
  eventName: string;
  shortTitle: string;
  slogan: string;
  dateRange: string;
  location: string;
  theme: string;
  dayOptions: string[];
  ticketOptions: string[];
  /** English versions of the two lists above, same order/length in
   *  principle. Optional so existing configs saved before this field
   *  existed keep working — the UI falls back to the French list
   *  (getLocalizedOptions) whenever the English one is missing/shorter. */
  dayOptionsEn?: string[];
  ticketOptionsEn?: string[];
  /** ISO date (YYYY-MM-DD) of the event's last day — drives the
   *  automatic hide below. Free-text `dateRange` above is only for
   *  display and isn't reliably parseable, hence this separate field. */
  eventEndDate: string;
  /** Lets an admin keep JMSA visible past its end date (e.g. to leave
   *  the recap/photos up for a while) instead of it disappearing the
   *  moment the date passes. Defaults to true — auto-hide is the safe,
   *  "don't leave stale info in the public nav" default. */
  autoHideAfterEvent: boolean;
}

export interface FixedTabLabel {
  title: string;
  titleEn?: string;
}

/**
 * @deprecated Pre-unification shape (Accueil/Contact lived outside
 * `spaces`). Kept only so `migrateLegacySpaces` can read old
 * `fixedTabs.accueil/contact` titles out of data saved before this file's
 * "one list" refactor — nothing new is ever written in this shape.
 */
export interface FixedTabs {
  accueil: FixedTabLabel;
  contact: FixedTabLabel;
}

export const DEFAULT_FIXED_TABS: FixedTabs = {
  accueil: { title: "Accueil", titleEn: "Home" },
  contact: { title: "Contact", titleEn: "Contact" },
};

export const DEFAULT_SPACES: Space[] = [
  { id: "accueil", kind: "home", enabled: true, title: "Accueil", titleEn: "Home" },
  { id: "fondatrice", kind: "founder", enabled: true, title: "Fondatrice", titleEn: "Founder" },
  { id: "jmsa-2026", kind: "module", enabled: true, title: "SOMMET JMSA 2026" },
  { id: "dons", kind: "module", enabled: true, title: "DONS" },
  { id: "missions", kind: "module", enabled: true, title: "MISSIONS & TRANSPARENCE" },
  { id: "mediatheque", kind: "module", enabled: true, title: "MÉDIATHÈQUE" },
  { id: "contact", kind: "contact", enabled: true, title: "Contact", titleEn: "Contact" },
];

/**
 * Folds a legacy `spaces` array (just the 4 modules, saved before this
 * refactor) into the new unified shape by inserting the three singleton
 * system tabs it used to be missing — using the old separate `fixedTabs`
 * values for Accueil/Contact's titles when available, so a rename an
 * admin made under the old model isn't lost. A no-op once a doc has
 * already been migrated (i.e. already has all three ids). Order: Accueil
 * first, Fondatrice second, everything else unchanged, Contact last —
 * exactly the fixed order the old hardcoded nav used, so migrating
 * doesn't visibly reorder anything on first load.
 */
export function migrateLegacySpaces(spaces: Space[], legacyFixedTabs?: FixedTabs | null): Space[] {
  const has = (id: string) => spaces.some((s) => s.id === id);
  if (has("accueil") && has("fondatrice") && has("contact")) return spaces;

  let next = [...spaces];
  if (!has("fondatrice")) {
    const accueilIndex = next.findIndex((s) => s.id === "accueil");
    next.splice(accueilIndex + 1, 0, {
      id: "fondatrice",
      kind: "founder",
      enabled: true,
      title: "Fondatrice",
      titleEn: "Founder",
    });
  }
  if (!has("accueil")) {
    next = [
      {
        id: "accueil",
        kind: "home",
        enabled: true,
        title: legacyFixedTabs?.accueil.title ?? "Accueil",
        titleEn: legacyFixedTabs?.accueil.titleEn ?? "Home",
      },
      ...next,
    ];
  }
  if (!has("contact")) {
    next = [
      ...next,
      {
        id: "contact",
        kind: "contact",
        enabled: true,
        title: legacyFixedTabs?.contact.title ?? "Contact",
        titleEn: legacyFixedTabs?.contact.titleEn ?? "Contact",
      },
    ];
  }
  return next;
}

export const DEFAULT_JMSA_CONFIG: JmsaConfig = {
  eventName: "La Journée Mondiale du Sommet des Associations",
  shortTitle: "JMSA 2026",
  slogan: "Unis pour un monde plus juste et plus sûr",
  dateRange: "20 – 21 novembre 2026",
  location: "Charleroi, Belgique",
  theme:
    "Renforcer la synergie Europe–Afrique pour un développement durable, inclusif et humain : lutte contre les violences faites aux femmes et aux enfants.",
  dayOptions: ["Vendredi 20/11", "Samedi 21/11", "2 jours (Vendredi + Samedi)"],
  dayOptionsEn: ["Friday 20/11", "Saturday 21/11", "2 days (Friday + Saturday)"],
  eventEndDate: "2026-11-21",
  autoHideAfterEvent: true,
  ticketOptions: [
    "Essentiel",
    "Standard",
    "Privilège",
    "Partenaire",
    "Partenaire +",
    "Sponsor Or",
    "Sponsor Diamant",
    "Sponsor Platinum",
  ],
  ticketOptionsEn: [
    "Essential",
    "Standard",
    "Privilege",
    "Partner",
    "Partner +",
    "Gold Sponsor",
    "Diamond Sponsor",
    "Platinum Sponsor",
  ],
};

/**
 * Picks the French or English list for a given lang, falling back to the
 * French one whenever no English list was saved yet (older config, or an
 * admin who only filled in the French textarea) or it doesn't line up
 * 1-for-1 with the French list.
 */
export function getLocalizedOptions(
  lang: "fr" | "en",
  fr: string[],
  en: string[] | undefined,
): string[] {
  if (lang === "en" && en && en.length === fr.length) return en;
  return fr;
}

/**
 * Keeps the summit's theme reading "Europe–Afrique" even if an older value
 * ("Afrique–Europe") was already saved in the shared config before the
 * wording was corrected. Applied on read, so it self-heals without anyone
 * having to re-save the JMSA config. Mirrored in
 * netlify/functions/lib/siteConfig.js.
 */
export function fixEuropeAfrica(text: string): string {
  return text
    .replace(/Afrique\s*[–-]\s*Europe/g, "Europe–Afrique")
    .replace(/Africa\s*[–-]\s*Europe/g, "Europe–Africa");
}

function normalizeJmsaConfig(config: JmsaConfig): JmsaConfig {
  return {
    ...config,
    eventName: fixEuropeAfrica(config.eventName),
    slogan: fixEuropeAfrica(config.slogan),
    theme: fixEuropeAfrica(config.theme),
  };
}

// --- Impact counters (home page) -------------------------------------------
//
// The three headline numbers on the Accueil tab. Editable from the admin
// "Compteurs" panel and stored in the same shared settings/site doc as
// everything else, so a change reaches every visitor.

export interface ImpactConfig {
  countries: number;
  years: number;
  actions: number;
}

export const DEFAULT_IMPACT: ImpactConfig = { countries: 35, years: 20, actions: 8 };

function normalizeImpact(raw: Partial<ImpactConfig> | undefined | null): ImpactConfig {
  const num = (v: unknown, fallback: number) => {
    const n = Number(v);
    return Number.isFinite(n) && n >= 0 ? Math.round(n) : fallback;
  };
  return {
    countries: num(raw?.countries, DEFAULT_IMPACT.countries),
    years: num(raw?.years, DEFAULT_IMPACT.years),
    actions: num(raw?.actions, DEFAULT_IMPACT.actions),
  };
}

export interface FlyerItem {
  id: string;
  src: string;
  alt: string;
  caption?: string;
}

// Official JMSA 2026 panelist / speaker flyers — mirrored server-side in
// netlify/functions/lib/siteConfig.js's DEFAULT_SITE_CONFIG.flyers, so a brand-new
// settings/site doc (before any admin has saved anything) starts from the
// exact same curated gallery rather than an empty one.
export const DEFAULT_FLYERS: FlyerItem[] = [
  { id: "flyer-main", src: "/flyers/jmsa-flyer-main.jpg", alt: "Affiche officielle JMSA 2026" },
  {
    id: "flyer-obe-mawusse",
    src: "/flyers/jmsa-flyer-obe-mawusse.jpg",
    alt: "Panéliste Diamant — Mme Obé Mawussé, responsable des femmes victimes de violences conjugales au Togo",
  },
  {
    id: "flyer-jacky-biho",
    src: "/flyers/jmsa-flyer-jacky-biho.jpg",
    alt: "Artiste invité — Jacky Biho",
  },
  {
    id: "flyer-erine-scolas",
    src: "/flyers/jmsa-flyer-erine-scolas.jpg",
    alt: "Panéliste Diamant — Mlle Erine Scolas, responsable adjointe animatrice, esthéticienne (Italie)",
  },
  {
    id: "flyer-edith-delhaye",
    src: "/flyers/jmsa-flyer-edith-delhaye.jpg",
    alt: "Mme Édith Delhaye, coordinatrice des victimes de violence et de viol",
  },
  {
    id: "flyer-toure-maristella",
    src: "/flyers/jmsa-flyer-toure-maristella.jpg",
    alt: "Mme Touré Maristella, responsable dans l'administration publique",
  },
  {
    id: "flyer-alexandra",
    src: "/flyers/jmsa-flyer-alexandra.jpg",
    alt: "Panéliste Diamant — Mme Alexandra, photographe professionnelle internationale (Belgique)",
  },
  {
    id: "flyer-damien-vandenbreghe",
    src: "/flyers/jmsa-flyer-damien-vandenbreghe.jpg",
    alt: "M. Damien van d'en Breghe, responsable des bénévoles UGD",
  },
  {
    id: "flyer-nguiemsap-gaelle",
    src: "/flyers/jmsa-flyer-nguiemsap-gaelle.jpg",
    alt: "Mme Nguiemsap Gaelle, responsable générale du secrétariat",
  },
  {
    id: "flyer-kemongne-sorel",
    src: "/flyers/jmsa-flyer-kemongne-sorel.jpg",
    alt: "Mme Kemongne Sorel, chargée de la communication institutionnelle internationale",
  },
];

// --- Documents (PDF library) -----------------------------------------------
//
// One ordered list, like `spaces` above: three standalone PDFs used to be
// hard-coded static assets under public/ — the founder's bio
// (FounderProfile.tsx, kind "founder"), the JMSA sponsoring dossier
// (JMSAHub.tsx, kind "jmsa-sponsoring") and the UGD marketing dossier
// (MissionsTransparency.tsx, kind "ugd-marketing") — editable only by
// shipping a new build. Each of those three is a singleton tied to one
// specific spot in the UI (same restore-from-default pattern as spaces'
// system tabs); anything else the admin adds is kind "custom" and shows up
// as an extra row in Missions & Transparence → Rapports, with no limit on
// how many. Renamable (FR/EN), replaceable (new file/URL), reorderable,
// enable/disable-able, and deletable, all from the "Documents" admin panel
// — a deleted "founder"/"jmsa-sponsoring"/"ugd-marketing" slot is always
// restorable (falls back to the original public/ asset); a deleted
// "custom" document is gone for good.

export type DocumentKind = "founder" | "jmsa-sponsoring" | "ugd-marketing" | "custom";

export interface DocumentItem {
  id: string;
  kind: DocumentKind;
  enabled: boolean;
  label: string; // French — always shown when lang is "fr", and the
  // fallback for "en" whenever labelEn hasn't been filled in.
  labelEn?: string;
  src: string;
}

export const DEFAULT_DOCUMENTS: DocumentItem[] = [
  {
    id: "founder",
    kind: "founder",
    enabled: true,
    label: "Présentation de la Fondatrice",
    labelEn: "Founder's presentation",
    src: "/founder/presentation-fondatrice.pdf",
  },
  {
    id: "jmsa-sponsoring",
    kind: "jmsa-sponsoring",
    enabled: true,
    label: "Dossier de sponsoring JMSA 2026",
    labelEn: "JMSA 2026 sponsoring dossier",
    src: "/reports/jmsa-2026-dossier-sponsoring.pdf",
  },
  {
    id: "ugd-marketing",
    kind: "ugd-marketing",
    enabled: true,
    label: "Dossier marketing & présentation — UGD",
    labelEn: "UGD marketing & presentation kit",
    src: "/reports/ugd-dossier-marketing.pdf",
  },
];

/**
 * Folds the pre-unification `documents` shape (a fixed
 * `{ founderPdf, jmsaSponsoringPdf, ugdMarketingPdf }` object, no list) into
 * the new array — reusing whichever URLs an admin had already swapped in
 * under the old model, so migrating doesn't undo a real replacement.
 * No-op (returns the input as-is) once a doc is already an array.
 * Mirrors netlify/functions/lib/siteConfig.js's `migrateLegacyDocuments` —
 * keep both in sync.
 */
export function migrateLegacyDocuments(raw: unknown): DocumentItem[] {
  if (Array.isArray(raw)) return raw as DocumentItem[];
  const legacy = (raw || {}) as { founderPdf?: string; jmsaSponsoringPdf?: string; ugdMarketingPdf?: string };
  return [
    { ...DEFAULT_DOCUMENTS[0], src: legacy.founderPdf || DEFAULT_DOCUMENTS[0].src },
    { ...DEFAULT_DOCUMENTS[1], src: legacy.jmsaSponsoringPdf || DEFAULT_DOCUMENTS[1].src },
    { ...DEFAULT_DOCUMENTS[2], src: legacy.ugdMarketingPdf || DEFAULT_DOCUMENTS[2].src },
  ];
}

// --- Médiathèque manager (photos + vidéos) --------------------------------
//
// Same shared-doc model as flyers above. Bilingual (FR/EN) like the
// speakers list, since the association keeps both languages on the
// public site — `alt`/`title` is French and always shown for lang "fr"
// and as the fallback for "en" whenever the optional English field
// hasn't been filled in (see resolveSpaceLabel-style fallback pattern
// used across cmsService.ts).

export interface MediaPhotoItem {
  id: string;
  src: string;
  alt: string;
  altEn?: string;
}

export interface MediaVideoItem {
  id: string;
  src: string;
  thumbnail: string;
  title: string;
  titleEn?: string;
  duration?: string;
}

// Mirrors MediaLibrary.tsx's former hardcoded GALLERY_PHOTOS — same
// photos, same order — so a brand-new settings/site doc (before any
// admin has saved anything) starts from the exact same gallery instead
// of an empty one. No English alt existed for these yet.
export const DEFAULT_MEDIA_PHOTOS: MediaPhotoItem[] = [
  { id: "team-founder", src: "/team/marie-makamgue-un.jpg", alt: "Marie Makamgue, fondatrice — Un Geste Divin" },
  {
    id: "commission-europeenne",
    src: "/media/commission-europeenne-intervention.jpg",
    alt: "Intervention de la Présidente à la Commission européenne, European Climate Pact",
  },
  {
    id: "climate-pact-2025",
    src: "/media/european-climate-pact-2025.jpg",
    alt: "UGD au sommet « The European Climate Pact — Together in Action »",
  },
  {
    id: "stand-marche-liege",
    src: "/media/stand-marche-liege.jpg",
    alt: "Stand de sensibilisation de la Ligue des Associations d'Aide Humanitaire, Liège",
  },
  {
    id: "reunion-equipe-benevoles",
    src: "/media/reunion-equipe-benevoles.jpg",
    alt: "Réunion de l'équipe et des bénévoles de l'association",
  },
  {
    id: "reseau-femmes-partenaires",
    src: "/media/reseau-femmes-partenaires.jpg",
    alt: "Rencontre avec le réseau de femmes partenaires de l'association",
  },
  {
    id: "asda-cameroun-enfants",
    src: "/media/asda-cameroun-enfants.jpg",
    alt: "Visite auprès des enfants du Centre ASDA au Cameroun",
  },
  {
    id: "nettoyage-communautaire",
    src: "/media/nettoyage-communautaire.jpg",
    alt: "Journée de nettoyage communautaire menée par les bénévoles de l'association",
  },
  {
    id: "distribution-terrain-rdc",
    src: "/media/distribution-terrain-rdc.jpg",
    alt: "Distribution de matériel aux familles lors d'une action de terrain",
  },
  {
    id: "distribution-village-benin",
    src: "/media/distribution-village-benin.jpg",
    alt: "Action de terrain auprès des enfants et familles d'un village",
  },
];

// Mirrors MediaLibrary.tsx's former hardcoded PLAYLIST_FR/PLAYLIST_EN,
// merged into one bilingual list (same reasoning as DEFAULT_MEDIA_PHOTOS
// above).
export const DEFAULT_MEDIA_VIDEOS: MediaVideoItem[] = [
  {
    id: "certificat-reconnaissance",
    title: "Remise d'un certificat de reconnaissance",
    titleEn: "Certificate of recognition ceremony",
    duration: "0:22",
    thumbnail: "/media/videos/certificat-reconnaissance.jpg",
    src: "/media/videos/certificat-reconnaissance.mp4",
  },
  {
    id: "atelier-creatif-enfants",
    title: "Atelier créatif avec les enfants",
    titleEn: "Creative workshop with children",
    duration: "0:47",
    thumbnail: "/media/videos/atelier-creatif-enfants.jpg",
    src: "/media/videos/atelier-creatif-enfants.mp4",
  },
  {
    id: "rencontre-onu-droits-homme",
    title: "Rencontre au Bureau des Droits de l'Homme de l'ONU",
    titleEn: "Meeting at the UN Human Rights Office",
    duration: "0:56",
    thumbnail: "/media/videos/rencontre-onu-droits-homme.jpg",
    src: "/media/videos/rencontre-onu-droits-homme.mp4",
  },
  {
    id: "action-terrain-enfants",
    title: "Action de terrain auprès des enfants",
    titleEn: "Field action with children",
    duration: "0:18",
    thumbnail: "/media/videos/action-terrain-enfants.jpg",
    src: "/media/videos/action-terrain-enfants.mp4",
  },
  {
    id: "action-humanitaire-rwanda",
    title: "Action humanitaire au Rwanda",
    titleEn: "Humanitarian action in Rwanda",
    duration: "0:27",
    thumbnail: "/media/videos/action-humanitaire-rwanda.jpg",
    src: "/media/videos/action-humanitaire-rwanda.mp4",
  },
  {
    id: "reunion-communautaire",
    title: "Réunion communautaire",
    titleEn: "Community meeting",
    duration: "0:48",
    thumbnail: "/media/videos/reunion-communautaire.jpg",
    src: "/media/videos/reunion-communautaire.mp4",
  },
  {
    id: "distribution-vivres-enfants",
    title: "Distribution de vivres aux enfants",
    titleEn: "Food distribution to children",
    duration: "0:11",
    thumbnail: "/media/videos/distribution-vivres-enfants.jpg",
    src: "/media/videos/distribution-vivres-enfants.mp4",
  },
  {
    id: "action-humanitaire-togo-lome",
    title: "Action humanitaire à Lomé, Togo",
    titleEn: "Humanitarian action in Lomé, Togo",
    duration: "0:14",
    thumbnail: "/media/videos/action-humanitaire-togo-lome.jpg",
    src: "/media/videos/action-humanitaire-togo-lome.mp4",
  },
];

// --- Speakers (Intervenants) manager --------------------------------------
//
// Bilingual: each card has one shared photo + two text sets (fr/en), same
// shared-Firestore-doc model as flyers above. Mirrors the 9 speakers
// already in src/data/jmsaProgramme.ts (which already has both language
// versions) so a brand-new settings/site doc starts from the exact same
// curated list instead of an empty one — no visual regression on first
// deploy, and JMSAHub.tsx falls back to the static file if this list is
// ever empty (e.g. local dev without a configured backend).

export interface SpeakerFields {
  name: string;
  role: string;
  country?: string;
  badge?: string;
}

export interface BilingualSpeaker {
  id: string;
  photo: string;
  fr: SpeakerFields;
  en: SpeakerFields;
}

// Source: src/data/jmsaProgramme.ts's speakersFr/speakersEn (kept in sync
// manually — see comment there). Mirrored server-side in
// netlify/functions/lib/siteConfig.js's DEFAULT_SITE_CONFIG.speakers for the same reason
// DEFAULT_FLYERS is mirrored there.
export const DEFAULT_SPEAKERS: BilingualSpeaker[] = [
  {
    id: "speaker-obe-mawusse",
    photo: "/flyers/jmsa-flyer-obe-mawusse.jpg",
    fr: {
      name: "Mme Obé Mawussé Fantodji",
      role: "Responsable des femmes victimes de violences conjugales au Togo",
      country: "Togo",
      badge: "Panéliste Diamant",
    },
    en: {
      name: "Mrs Obé Mawussé Fantodji",
      role: "Advocate for women victims of domestic violence in Togo",
      country: "Togo",
      badge: "Diamond Panelist",
    },
  },
  {
    id: "speaker-erine-scolas",
    photo: "/flyers/jmsa-flyer-erine-scolas.jpg",
    fr: {
      name: "Mlle Erine Scolas",
      role: "Responsable adjointe animatrice, esthéticienne — engagée pour le bien-être et l'autonomisation des femmes",
      country: "Italie",
      badge: "Panéliste Diamant",
    },
    en: {
      name: "Miss Erine Scolas",
      role: "Assistant host & beautician — committed to women's wellbeing and empowerment",
      country: "Italy",
      badge: "Diamond Panelist",
    },
  },
  {
    id: "speaker-alexandra",
    photo: "/flyers/jmsa-flyer-alexandra.jpg",
    fr: {
      name: "Mme Alexandra",
      role: "Photographe professionnelle internationale",
      country: "Belgique",
      badge: "Panéliste Diamant",
    },
    en: {
      name: "Mrs Alexandra",
      role: "International professional photographer",
      country: "Belgium",
      badge: "Diamond Panelist",
    },
  },
  {
    id: "speaker-edith-delhaye",
    photo: "/flyers/jmsa-flyer-edith-delhaye.jpg",
    fr: { name: "Mme Édith Delhaye", role: "Coordinatrice des victimes de violence et de viol" },
    en: { name: "Mrs Édith Delhaye", role: "Coordinator for victims of violence and rape" },
  },
  {
    id: "speaker-toure-maristella",
    photo: "/flyers/jmsa-flyer-toure-maristella.jpg",
    fr: { name: "Mme Touré Maristella", role: "Responsable dans l'administration publique" },
    en: { name: "Mrs Touré Maristella", role: "Public administration officer" },
  },
  {
    id: "speaker-damien-vandenbreghe",
    photo: "/flyers/jmsa-flyer-damien-vandenbreghe.jpg",
    fr: { name: "M. Damien van d'en Breghe", role: "Responsable des bénévoles (UGD)" },
    en: { name: "Mr Damien van d'en Breghe", role: "Volunteer coordinator (UGD)" },
  },
  {
    id: "speaker-nguiemsap-gaelle",
    photo: "/flyers/jmsa-flyer-nguiemsap-gaelle.jpg",
    fr: { name: "Mme Nguiemsap Gaelle", role: "Responsable générale du secrétariat" },
    en: { name: "Mrs Nguiemsap Gaelle", role: "General secretariat manager" },
  },
  {
    id: "speaker-kemongne-sorel",
    photo: "/flyers/jmsa-flyer-kemongne-sorel.jpg",
    fr: { name: "Mme Kemongne Sorel", role: "Chargée de la communication institutionnelle internationale" },
    en: { name: "Mrs Kemongne Sorel", role: "International institutional communications officer" },
  },
  {
    id: "speaker-jacky-biho",
    photo: "/flyers/jmsa-flyer-jacky-biho.jpg",
    fr: { name: "Jacky Biho", role: "Artiste invité", badge: "Artiste Guest" },
    en: { name: "Jacky Biho", role: "Guest artist", badge: "Guest Artist" },
  },
];

// --- Bank / Mobile Money -----------------------------------------------
//
// `accountHolder`/`iban`/`bic` stay single admin-editable values (there's
// only ever one bank account). `mobileMoneyProviders`, on the other hand,
// used to be a fixed 4-entry list (TMoney/Flooz/Orange Money/MTN) defined
// as static code in data/donationAccounts.ts, with only each provider's
// *number* admin-editable (via a separate `mobileMoney` id->value map
// overlaid on top). It's now a single ordered, fully admin-managed list —
// add a new operator (Wave, Moov Money, …), rename/recolor/delete an
// existing one, reorder them — same "one list, not a value-only overlay"
// upgrade as `spaces` and `documents` above.

export interface MobileMoneyProviderItem {
  id: string;
  name: string; // French display name — always shown when lang is "fr",
  // and the fallback for "en" whenever nameEn hasn't been filled in.
  nameEn?: string;
  color: string; // hex, used for the little dot next to the provider name
  value: string; // the actual number/account, admin-editable — see isConfirmedValue
}

export interface BankOverrides {
  accountHolder: string;
  iban: string;
  bic: string;
  mobileMoneyProviders: MobileMoneyProviderItem[];
}

const PLACEHOLDER = "À COMMUNIQUER PAR L'ASSOCIATION";

export const DEFAULT_MOBILE_MONEY: MobileMoneyProviderItem[] = [
  { id: "tmoney", name: "TMoney", color: "#F59E0B", value: PLACEHOLDER },
  { id: "flooz", name: "Flooz", color: "#EF4444", value: PLACEHOLDER },
  { id: "orange-money", name: "Orange Money", color: "#EA580C", value: PLACEHOLDER },
  { id: "mtn", name: "MTN Mobile Money", color: "#B89B55", value: PLACEHOLDER },
];

function defaultBankOverrides(): BankOverrides {
  return {
    accountHolder: defaultBankAccount.accountHolder,
    iban: defaultBankAccount.iban.value,
    bic: defaultBankAccount.bic.value,
    mobileMoneyProviders: DEFAULT_MOBILE_MONEY,
  };
}

/**
 * Folds the pre-unification bank shape (a fixed `mobileMoney: Record<id,
 * value>` map overlaid on the static 4-provider list in
 * data/donationAccounts.ts) into `mobileMoneyProviders` — reusing whatever
 * numbers an admin had already entered under the old model. No-op once a
 * doc already has `mobileMoneyProviders` as an array. Mirrors
 * netlify/functions/lib/siteConfig.js's `migrateLegacyBank` — keep both
 * in sync.
 */
export function migrateLegacyBank(raw: any): BankOverrides {
  const legacy = raw || {};
  if (Array.isArray(legacy.mobileMoneyProviders)) return legacy as BankOverrides;
  const legacyMap: Record<string, string> = legacy.mobileMoney || {};
  return {
    accountHolder: legacy.accountHolder ?? defaultBankAccount.accountHolder,
    iban: legacy.iban ?? defaultBankAccount.iban.value,
    bic: legacy.bic ?? defaultBankAccount.bic.value,
    mobileMoneyProviders: DEFAULT_MOBILE_MONEY.map((p) => ({ ...p, value: legacyMap[p.id] ?? p.value })),
  };
}

interface SiteConfig {
  spaces: Space[];
  jmsaConfig: JmsaConfig;
  flyers: FlyerItem[];
  speakers: BilingualSpeaker[];
  mediaPhotos: MediaPhotoItem[];
  mediaVideos: MediaVideoItem[];
  fixedTabs: FixedTabs;
  bank: BankOverrides;
  documents: DocumentItem[];
  /** Optional: configs cached before the counters existed don't have it. */
  impact?: ImpactConfig;
}

const DEFAULT_SITE_CONFIG: SiteConfig = {
  spaces: DEFAULT_SPACES,
  jmsaConfig: DEFAULT_JMSA_CONFIG,
  flyers: DEFAULT_FLYERS,
  speakers: DEFAULT_SPEAKERS,
  mediaPhotos: DEFAULT_MEDIA_PHOTOS,
  mediaVideos: DEFAULT_MEDIA_VIDEOS,
  fixedTabs: DEFAULT_FIXED_TABS,
  bank: defaultBankOverrides(),
  documents: DEFAULT_DOCUMENTS,
  impact: DEFAULT_IMPACT,
};

const siteConfigStore = createStore<SiteConfig>(KEY_SITE_CONFIG, DEFAULT_SITE_CONFIG);

let fetchedOnce = false;

/**
 * Pulls the latest { spaces, jmsaConfig, flyers, bank } from the shared
 * backend (if configured and online) and updates the local store + cache.
 * Safe to call repeatedly — every visitor's app calls this on load and
 * again whenever connectivity returns, so an admin's change reaches
 * everyone within one refresh/reconnect, not just their own device.
 */
export async function refreshSiteConfigFromServer(): Promise<void> {
  if (!API_BASE_URL || !navigator.onLine) return;
  try {
    const response = await fetch(`${API_BASE_URL}/getSpaces`);
    const data = await response.json();
    if (!response.ok || data.ok === false) return;
    await siteConfigStore.set({
      spaces: Array.isArray(data.spaces) ? data.spaces : DEFAULT_SPACES,
      jmsaConfig: { ...DEFAULT_JMSA_CONFIG, ...(data.jmsaConfig || {}) },
      flyers: Array.isArray(data.flyers) ? data.flyers : DEFAULT_FLYERS,
      speakers: Array.isArray(data.speakers) ? data.speakers : DEFAULT_SPEAKERS,
      mediaPhotos: Array.isArray(data.mediaPhotos) ? data.mediaPhotos : DEFAULT_MEDIA_PHOTOS,
      mediaVideos: Array.isArray(data.mediaVideos) ? data.mediaVideos : DEFAULT_MEDIA_VIDEOS,
      fixedTabs: data.fixedTabs
        ? {
            accueil: { ...DEFAULT_FIXED_TABS.accueil, ...(data.fixedTabs.accueil || {}) },
            contact: { ...DEFAULT_FIXED_TABS.contact, ...(data.fixedTabs.contact || {}) },
          }
        : DEFAULT_FIXED_TABS,
      bank: data.bank ?? defaultBankOverrides(),
      documents: data.documents ?? DEFAULT_DOCUMENTS,
      impact: normalizeImpact(data.impact),
    });
  } catch {
    // Offline or backend unreachable — keep whatever's cached locally.
  } finally {
    fetchedOnce = true;
  }
}

async function ensureFetched(): Promise<void> {
  if (!fetchedOnce) await refreshSiteConfigFromServer();
}

export async function getSpaces(): Promise<Space[]> {
  await ensureFetched();
  const config = await siteConfigStore.get();
  // Migrated on every read (not just on fetch from the server) so an
  // old IndexedDB cache — saved before Accueil/Fondatrice/Contact joined
  // this list — self-heals even for a first-ever offline load, before any
  // network round-trip has had a chance to run.
  return migrateLegacySpaces(config.spaces, config.fixedTabs);
}

export function subscribeSpaces(listener: Listener<Space[]>): () => void {
  void ensureFetched();
  return siteConfigStore.subscribe((config) => listener(migrateLegacySpaces(config.spaces, config.fixedTabs)));
}

export async function getJmsaConfig(): Promise<JmsaConfig> {
  await ensureFetched();
  return normalizeJmsaConfig((await siteConfigStore.get()).jmsaConfig);
}

export function subscribeJmsaConfig(listener: Listener<JmsaConfig>): () => void {
  void ensureFetched();
  return siteConfigStore.subscribe((config) => listener(normalizeJmsaConfig(config.jmsaConfig)));
}

export function subscribeImpact(listener: Listener<ImpactConfig>): () => void {
  void ensureFetched();
  return siteConfigStore.subscribe((config) => listener(normalizeImpact(config.impact)));
}

/** Admin write: saves the three home-page counters to the shared config. */
export async function setImpactRemote(actorEmail: string, impact: ImpactConfig): Promise<void> {
  const clean = normalizeImpact(impact);
  let data: any;
  try {
    data = await adminFetch("/setSpaces", { method: "POST", body: JSON.stringify({ impact: clean, actorEmail }) });
  } catch (err) {
    throw new SiteConfigApiError(err instanceof Error ? err.message : "Erreur serveur.");
  }
  const current = await siteConfigStore.get();
  await siteConfigStore.set({ ...current, impact: normalizeImpact(data.impact ?? clean) });
  await recordAuditEvent(
    actorEmail,
    "cms.impact",
    `Compteurs : ${clean.countries} pays, ${clean.years} ans, ${clean.actions} actions`,
  );
}

/** True once local module id can't be found — used to gate JMSA registration entry points. */
export function isModuleSpaceEnabled(spaces: Space[], id: ModuleId): boolean {
  const space = spaces.find((s) => s.id === id);
  // A missing space means an admin deliberately deleted it — every system
  // id is always present (seeded by DEFAULT_SPACES / migrateLegacySpaces)
  // until removed via EspacesPanel — so "not found" here means closed,
  // not enabled. This is what makes deleting the JMSA tab also close the
  // ?inscription deep link, not just hide the nav entry. Callers still
  // need to handle "spaces hasn't loaded yet" (an empty array) themselves
  // before calling this — see PassRequestForm.tsx's `spaces.length === 0`.
  return space ? space.enabled !== false : false;
}

/**
 * True once the summit's last day is over AND the admin hasn't opted out
 * of auto-hiding (`autoHideAfterEvent`). Compares against the *end* of
 * `eventEndDate` (23:59:59 local time) so the event's actual last day
 * still shows normally. Used to automatically pull the JMSA nav tab and
 * close registrations once the event has passed — no admin action
 * needed — without touching the underlying `enabled` flag, so nothing
 * is silently overwritten and the admin can always re-show it manually
 * (or push `eventEndDate` out) for a future edition.
 */
export function isJmsaAutoHidden(config: JmsaConfig, now: Date = new Date()): boolean {
  if (!config.autoHideAfterEvent || !config.eventEndDate) return false;
  const end = new Date(`${config.eventEndDate}T23:59:59`);
  if (Number.isNaN(end.getTime())) return false;
  return now.getTime() > end.getTime();
}

class SiteConfigApiError extends Error {}

/** Admin write: pushes to the shared backend first, then mirrors locally. Throws on failure — caller shows the error, nothing is saved silently only-local. */
export async function setSpacesRemote(actorEmail: string, spaces: Space[]): Promise<void> {
  let data: any;
  try {
    data = await adminFetch("/setSpaces", { method: "POST", body: JSON.stringify({ spaces, actorEmail }) });
  } catch (err) {
    throw new SiteConfigApiError(err instanceof Error ? err.message : "Erreur serveur.");
  }
  const current = await siteConfigStore.get();
  await siteConfigStore.set({ ...current, spaces: data.spaces || spaces });
  await recordAuditEvent(actorEmail, "cms.spaces", spaces.map((s) => `${s.id}${s.enabled ? "" : " (désactivé)"}`).join(", "));
}

// getFixedTabs/subscribeFixedTabs/setFixedTabsRemote were removed here:
// Accueil and Contact are now ordinary entries in `spaces` (kind "home"
// and "contact"), managed the same way as every other tab via
// setSpacesRemote below. `fixedTabs` itself is kept only inside
// SiteConfig/DEFAULT_SITE_CONFIG as a read path for `migrateLegacySpaces`
// (old data saved before this unification) — nothing writes to it anymore.

export async function setJmsaConfigRemote(actorEmail: string, jmsaConfig: JmsaConfig): Promise<void> {
  let data: any;
  try {
    data = await adminFetch("/setSpaces", { method: "POST", body: JSON.stringify({ jmsaConfig, actorEmail }) });
  } catch (err) {
    throw new SiteConfigApiError(err instanceof Error ? err.message : "Erreur serveur.");
  }
  const current = await siteConfigStore.get();
  await siteConfigStore.set({ ...current, jmsaConfig: data.jmsaConfig || jmsaConfig });
  await recordAuditEvent(actorEmail, "cms.jmsa-config", "Configuration JMSA 2026 mise à jour");
}

// --- Flyer & media manager -----------------------------------------------------
//
// Now backed by the shared settings/site doc (like spaces/jmsaConfig above)
// instead of local-only IndexedDB — a flyer added by the admin appears for
// every visitor, not just on the admin's own device.


export async function getFlyers(): Promise<FlyerItem[]> {
  await ensureFetched();
  return (await siteConfigStore.get()).flyers;
}

export function subscribeFlyers(listener: Listener<FlyerItem[]>): () => void {
  void ensureFetched();
  return siteConfigStore.subscribe((config) => listener(config.flyers));
}

async function persistFlyers(actorEmail: string, next: FlyerItem[], auditAction: string, auditDetail: string): Promise<void> {
  let data: any;
  try {
    data = await adminFetch("/setSpaces", { method: "POST", body: JSON.stringify({ flyers: next, actorEmail }) });
  } catch (err) {
    throw new SiteConfigApiError(err instanceof Error ? err.message : "Erreur serveur.");
  }
  const current = await siteConfigStore.get();
  await siteConfigStore.set({ ...current, flyers: data.flyers || next });
  await recordAuditEvent(actorEmail, auditAction, auditDetail);
}

export async function addFlyer(actorEmail: string, flyer: Omit<FlyerItem, "id">): Promise<void> {
  const current = await getFlyers();
  const id = `flyer-${Date.now().toString(36)}`;
  await persistFlyers(actorEmail, [...current, { ...flyer, id }], "cms.flyer-add", flyer.alt);
}

export async function updateFlyer(actorEmail: string, id: string, patch: Partial<FlyerItem>): Promise<void> {
  const current = await getFlyers();
  await persistFlyers(actorEmail, current.map((f) => (f.id === id ? { ...f, ...patch } : f)), "cms.flyer-update", id);
}

export async function removeFlyer(actorEmail: string, id: string): Promise<void> {
  const current = await getFlyers();
  await persistFlyers(actorEmail, current.filter((f) => f.id !== id), "cms.flyer-remove", id);
}

export async function reorderFlyers(actorEmail: string, orderedIds: string[]): Promise<void> {
  const current = await getFlyers();
  const byId = new Map(current.map((f) => [f.id, f]));
  const next = orderedIds.map((id) => byId.get(id)).filter((f): f is FlyerItem => Boolean(f));
  await persistFlyers(actorEmail, next, "cms.flyer-reorder", orderedIds.join(", "));
}

// --- Médiathèque manager (photos + vidéos) ---------------------------------
//
// Same shared-doc model as flyers above — a photo/video added or removed
// by the admin appears for every visitor, not just on the admin's own
// device. Read publicly via subscribeMediaPhotos/subscribeMediaVideos
// (MediaLibrary.tsx), managed via the Médiathèque admin panel.

export async function getMediaPhotos(): Promise<MediaPhotoItem[]> {
  await ensureFetched();
  return (await siteConfigStore.get()).mediaPhotos;
}

export function subscribeMediaPhotos(listener: Listener<MediaPhotoItem[]>): () => void {
  void ensureFetched();
  return siteConfigStore.subscribe((config) => listener(config.mediaPhotos));
}

async function persistMediaPhotos(actorEmail: string, next: MediaPhotoItem[], auditAction: string, auditDetail: string): Promise<void> {
  let data: any;
  try {
    data = await adminFetch("/setSpaces", { method: "POST", body: JSON.stringify({ mediaPhotos: next, actorEmail }) });
  } catch (err) {
    throw new SiteConfigApiError(err instanceof Error ? err.message : "Erreur serveur.");
  }
  const current = await siteConfigStore.get();
  await siteConfigStore.set({ ...current, mediaPhotos: data.mediaPhotos || next });
  await recordAuditEvent(actorEmail, auditAction, auditDetail);
}

export async function addMediaPhoto(actorEmail: string, photo: Omit<MediaPhotoItem, "id">): Promise<void> {
  const current = await getMediaPhotos();
  const id = `photo-${Date.now().toString(36)}`;
  await persistMediaPhotos(actorEmail, [...current, { ...photo, id }], "cms.media-photo-add", photo.alt);
}

export async function updateMediaPhoto(actorEmail: string, id: string, patch: Partial<MediaPhotoItem>): Promise<void> {
  const current = await getMediaPhotos();
  await persistMediaPhotos(actorEmail, current.map((p) => (p.id === id ? { ...p, ...patch } : p)), "cms.media-photo-update", id);
}

export async function removeMediaPhoto(actorEmail: string, id: string): Promise<void> {
  const current = await getMediaPhotos();
  await persistMediaPhotos(actorEmail, current.filter((p) => p.id !== id), "cms.media-photo-remove", id);
}

export async function reorderMediaPhotos(actorEmail: string, orderedIds: string[]): Promise<void> {
  const current = await getMediaPhotos();
  const byId = new Map(current.map((p) => [p.id, p]));
  const next = orderedIds.map((id) => byId.get(id)).filter((p): p is MediaPhotoItem => Boolean(p));
  await persistMediaPhotos(actorEmail, next, "cms.media-photo-reorder", orderedIds.join(", "));
}

export async function getMediaVideos(): Promise<MediaVideoItem[]> {
  await ensureFetched();
  return (await siteConfigStore.get()).mediaVideos;
}

export function subscribeMediaVideos(listener: Listener<MediaVideoItem[]>): () => void {
  void ensureFetched();
  return siteConfigStore.subscribe((config) => listener(config.mediaVideos));
}

async function persistMediaVideos(actorEmail: string, next: MediaVideoItem[], auditAction: string, auditDetail: string): Promise<void> {
  let data: any;
  try {
    data = await adminFetch("/setSpaces", { method: "POST", body: JSON.stringify({ mediaVideos: next, actorEmail }) });
  } catch (err) {
    throw new SiteConfigApiError(err instanceof Error ? err.message : "Erreur serveur.");
  }
  const current = await siteConfigStore.get();
  await siteConfigStore.set({ ...current, mediaVideos: data.mediaVideos || next });
  await recordAuditEvent(actorEmail, auditAction, auditDetail);
}

export async function addMediaVideo(actorEmail: string, video: Omit<MediaVideoItem, "id">): Promise<void> {
  const current = await getMediaVideos();
  const id = `video-${Date.now().toString(36)}`;
  await persistMediaVideos(actorEmail, [...current, { ...video, id }], "cms.media-video-add", video.title);
}

export async function updateMediaVideo(actorEmail: string, id: string, patch: Partial<MediaVideoItem>): Promise<void> {
  const current = await getMediaVideos();
  await persistMediaVideos(actorEmail, current.map((v) => (v.id === id ? { ...v, ...patch } : v)), "cms.media-video-update", id);
}

export async function removeMediaVideo(actorEmail: string, id: string): Promise<void> {
  const current = await getMediaVideos();
  await persistMediaVideos(actorEmail, current.filter((v) => v.id !== id), "cms.media-video-remove", id);
}

export async function reorderMediaVideos(actorEmail: string, orderedIds: string[]): Promise<void> {
  const current = await getMediaVideos();
  const byId = new Map(current.map((v) => [v.id, v]));
  const next = orderedIds.map((id) => byId.get(id)).filter((v): v is MediaVideoItem => Boolean(v));
  await persistMediaVideos(actorEmail, next, "cms.media-video-reorder", orderedIds.join(", "));
}

// --- Speakers manager (Intervenants) ---------------------------------------
//
// Same shared-doc model as flyers above — a speaker added/edited by the
// admin appears for every visitor. JMSAHub.tsx reads this via
// subscribeSpeakers and falls back to the static jmsaProgramme.ts list if
// it's ever empty.

export async function getSpeakers(): Promise<BilingualSpeaker[]> {
  await ensureFetched();
  return (await siteConfigStore.get()).speakers;
}

export function subscribeSpeakers(listener: Listener<BilingualSpeaker[]>): () => void {
  void ensureFetched();
  return siteConfigStore.subscribe((config) => listener(config.speakers));
}

async function persistSpeakers(actorEmail: string, next: BilingualSpeaker[], auditAction: string, auditDetail: string): Promise<void> {
  let data: any;
  try {
    data = await adminFetch("/setSpaces", { method: "POST", body: JSON.stringify({ speakers: next, actorEmail }) });
  } catch (err) {
    throw new SiteConfigApiError(err instanceof Error ? err.message : "Erreur serveur.");
  }
  const current = await siteConfigStore.get();
  await siteConfigStore.set({ ...current, speakers: data.speakers || next });
  await recordAuditEvent(actorEmail, auditAction, auditDetail);
}

export async function addSpeaker(actorEmail: string, speaker: Omit<BilingualSpeaker, "id">): Promise<void> {
  const current = await getSpeakers();
  const id = `speaker-${Date.now().toString(36)}`;
  await persistSpeakers(actorEmail, [...current, { ...speaker, id }], "cms.speaker-add", speaker.fr.name);
}

export async function updateSpeaker(actorEmail: string, id: string, patch: Partial<Omit<BilingualSpeaker, "id">>): Promise<void> {
  const current = await getSpeakers();
  await persistSpeakers(
    actorEmail,
    current.map((s) => (s.id === id ? { ...s, ...patch } : s)),
    "cms.speaker-update",
    id,
  );
}

export async function removeSpeaker(actorEmail: string, id: string): Promise<void> {
  const current = await getSpeakers();
  await persistSpeakers(actorEmail, current.filter((s) => s.id !== id), "cms.speaker-remove", id);
}

export async function reorderSpeakers(actorEmail: string, orderedIds: string[]): Promise<void> {
  const current = await getSpeakers();
  const byId = new Map(current.map((s) => [s.id, s]));
  const next = orderedIds.map((id) => byId.get(id)).filter((s): s is BilingualSpeaker => Boolean(s));
  await persistSpeakers(actorEmail, next, "cms.speaker-reorder", orderedIds.join(", "));
}

// --- Bank / Mobile Money editor -------------------------------------------------
//
// Also now backed by the shared settings/site doc — see the flyers note
// above, same reasoning applies (donation details need to be correct for
// every visitor, not just show correctly on the admin's own phone).


export async function getBankOverrides(): Promise<BankOverrides> {
  await ensureFetched();
  return migrateLegacyBank((await siteConfigStore.get()).bank);
}

export function subscribeBankOverrides(listener: Listener<BankOverrides>): () => void {
  void ensureFetched();
  return siteConfigStore.subscribe((config) => listener(migrateLegacyBank(config.bank)));
}

export function isConfirmedValue(value: string): boolean {
  return value.trim().length > 0 && value.trim() !== PLACEHOLDER;
}

export async function setBankOverrides(actorEmail: string, next: BankOverrides): Promise<void> {
  let data: any;
  try {
    data = await adminFetch("/setSpaces", { method: "POST", body: JSON.stringify({ bank: next, actorEmail }) });
  } catch (err) {
    throw new SiteConfigApiError(err instanceof Error ? err.message : "Erreur serveur.");
  }
  const current = await siteConfigStore.get();
  await siteConfigStore.set({ ...current, bank: data.bank || next });
  await recordAuditEvent(actorEmail, "cms.bank-accounts", "Coordonnées de dons mises à jour");
}

// --- Documents (PDF library) -----------------------------------------------

export async function getDocuments(): Promise<DocumentItem[]> {
  await ensureFetched();
  return migrateLegacyDocuments((await siteConfigStore.get()).documents);
}

export function subscribeDocuments(listener: Listener<DocumentItem[]>): () => void {
  void ensureFetched();
  return siteConfigStore.subscribe((config) => listener(migrateLegacyDocuments(config.documents)));
}

/**
 * Admin write: replaces the whole documents list (reorder, rename,
 * replace a file, enable/disable, delete, restore, or add a new "custom"
 * document) — same whole-list-replace pattern as setSpacesRemote.
 */
export async function setDocumentsRemote(actorEmail: string, next: DocumentItem[]): Promise<void> {
  let data: any;
  try {
    data = await adminFetch("/setSpaces", { method: "POST", body: JSON.stringify({ documents: next, actorEmail }) });
  } catch (err) {
    throw new SiteConfigApiError(err instanceof Error ? err.message : "Erreur serveur.");
  }
  const currentConfig = await siteConfigStore.get();
  await siteConfigStore.set({ ...currentConfig, documents: data.documents || next });
  await recordAuditEvent(actorEmail, "cms.documents", next.map((d) => d.id).join(", "));
}
