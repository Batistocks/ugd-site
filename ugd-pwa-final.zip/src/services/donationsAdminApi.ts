/**
 * Client for the two admin-protected donation endpoints (Netlify
 * Functions: listDonations, verifyDonation). See adminApiClient.ts for
 * the shared per-admin auth model.
 */

import { adminFetch, isBackendConfigured, AdminApiError } from "./adminApiClient";

export { isBackendConfigured, AdminApiError };

export interface DonationRecord {
  receiptId: string;
  donorName: string;
  email: string | null;
  /** WhatsApp number (with country code) — only collected for gala tickets. */
  phone: string | null;
  amount: string;
  currency: string;
  method: string | null;
  context: string;
  kind: "sponsoring" | "billet" | "don";
  proofFileName: string | null;
  proofUrl: string | null;
  status: "en_attente" | "verifie";
  createdAt: number | null;
  verifiedAt: number | null;
  verifiedBy: string | null;
  receiptPdfUrl: string | null;
  /** Ticket category (e.g. "VIP Or") — gala tickets only. */
  ticketName: string | null;
  /** Access badge PDF with QR code — exists only for a verified gala ticket. */
  badgePdfUrl: string | null;
  checkedIn: boolean;
  checkedInAt: number | null;
  checkedInBy: string | null;
}

export async function fetchDonations(status?: "en_attente" | "verifie"): Promise<DonationRecord[]> {
  const query = status ? `?status=${status}` : "";
  const data = await adminFetch(`/listDonations${query}`);
  return data.items as DonationRecord[];
}

export async function verifyDonation(id: string): Promise<{ receiptPdfUrl: string; badgePdfUrl: string | null }> {
  const data = await adminFetch("/verifyDonation", {
    method: "POST",
    body: JSON.stringify({ id }),
  });
  return data;
}
