import { appendAuditLog, listAuditLog, type AuditLogRecord } from "./db";

/**
 * Audit trail for the secret admin panel.
 * Section 5: Secret Admin Panel & CMS Management.
 *
 * Every meaningful admin action (login, whitelist changes, CMS edits,
 * check-ins, exports) is appended here so the association can review who
 * changed what and when — see also services/exportService.ts for the
 * one-click JSON/CSV export of this log.
 */

type Listener = () => void;
const listeners = new Set<Listener>();

export function subscribeAuditLog(listener: Listener): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export async function recordAuditEvent(
  actorEmail: string,
  action: string,
  details?: string,
): Promise<void> {
  await appendAuditLog({ actorEmail, action, details, timestamp: Date.now() });
  listeners.forEach((l) => l());
}

export async function getAuditLog(limit = 200): Promise<AuditLogRecord[]> {
  return listAuditLog(limit);
}
