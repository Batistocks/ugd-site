/**
 * Shared HTTP client for every admin-protected Netlify Function
 * (donations, inscriptions, CMS/setSpaces...). Sends the signed-in
 * admin's own Firebase ID token (see authService.ts:getIdToken) as
 * "Authorization: Bearer <token>" — the server checks that identity
 * against the shared `admins` Firestore list (the same list the
 * "Équipe" panel manages), instead of the old shared ADMIN_API_TOKEN
 * that every admin used to type in by hand.
 */

import { getIdToken } from "./authService";
import {
  DEMO_ADMIN_EMAIL,
  demoDonations,
  demoRegistrations,
  isDemoMode,
  saveDemoDonations,
  saveDemoRegistrations,
} from "./demoMode";

export const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL as string | undefined)?.replace(/\/$/, "");

export function isBackendConfigured(): boolean {
  // En mode démo, les « endpoints » sont simulés localement (voir demoFetch).
  return Boolean(API_BASE_URL) || isDemoMode;
}

export class AdminApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

/**
 * Simulated Netlify Functions for the demo mode (no backend, no Firebase).
 * Everything is read from / written to this device only (see demoMode.ts).
 */
async function demoFetch(path: string, init: RequestInit): Promise<any> {
  const [route, queryString = ""] = path.split("?");
  const query = new URLSearchParams(queryString);
  const body = init.body ? (JSON.parse(String(init.body)) as Record<string, any>) : {};

  switch (route) {
    case "/setSpaces": {
      // CMS saves: echo the submitted blocks back, exactly like the real function.
      const { actorEmail: _actor, ...saved } = body;
      void _actor;
      return { ok: true, ...saved };
    }

    case "/listRegistrations": {
      const filter = query.get("checkedIn");
      const items = demoRegistrations().filter((r) =>
        filter === null ? true : r.checkedIn === (filter === "true"),
      );
      return { ok: true, items };
    }

    case "/listDonations": {
      const status = query.get("status");
      const items = demoDonations().filter((d) => (status ? d.status === status : true));
      return { ok: true, items };
    }

    case "/verifyDonation": {
      const list = demoDonations();
      const item = list.find((d) => d.receiptId === body.id);
      if (!item) throw new AdminApiError("Don introuvable.", 404);

      const { generateReceiptPdf, generateBadgePdf } = await import("./pdfService");
      const lang = "fr" as const;
      const now = Date.now();
      if (item.status !== "verifie") {
        item.status = "verifie";
        item.verifiedAt = now;
        item.verifiedBy = DEMO_ADMIN_EMAIL;
      }
      if (!item.receiptPdfUrl) {
        const receipt = await generateReceiptPdf(
          {
            receiptId: item.receiptId,
            donorName: item.donorName,
            donorEmail: item.email ?? undefined,
            amount: item.amount,
            method: item.method ?? "",
            purpose: item.context,
            dateLabel: new Date(now).toLocaleDateString("fr-BE"),
          },
          lang,
        );
        item.receiptPdfUrl = await blobToDataUrl(receipt);
      }
      if (item.kind === "billet" && !item.badgePdfUrl) {
        const badge = await generateBadgePdf(
          {
            registrationId: item.receiptId,
            fullName: item.donorName,
            ticketType: item.ticketName ?? "Billet gala",
            day: "Samedi 21/11",
          },
          lang,
        );
        item.badgePdfUrl = await blobToDataUrl(badge);
      }
      saveDemoDonations(list);
      return { ok: true, receiptPdfUrl: item.receiptPdfUrl, badgePdfUrl: item.badgePdfUrl };
    }

    case "/checkInRegistration": {
      const id = String(body.id || "").trim();
      const now = Date.now();

      // 1) Verified gala ticket (what the QR badge carries).
      const donations = demoDonations();
      const ticket = donations.find((d) => d.receiptId === id);
      if (ticket) {
        if (ticket.kind !== "billet") {
          throw new AdminApiError("Ce numéro n'est pas un billet de gala.", 404);
        }
        if (ticket.status !== "verifie") {
          throw new AdminApiError("Paiement non vérifié : ce billet n'a pas encore été validé.", 402);
        }
        if (ticket.checkedIn) return { ok: true, id, alreadyCheckedIn: true, fullName: ticket.donorName };
        ticket.checkedIn = true;
        ticket.checkedInAt = now;
        ticket.checkedInBy = DEMO_ADMIN_EMAIL;
        saveDemoDonations(donations);
        return { ok: true, id, fullName: ticket.donorName };
      }

      // 2) Plain summit registration (manual pointage).
      const registrations = demoRegistrations();
      const reg = registrations.find((r) => r.registrationId === id);
      if (!reg) throw new AdminApiError("Inscription introuvable.", 404);
      if (reg.checkedIn) return { ok: true, id, alreadyCheckedIn: true, fullName: reg.fullName };
      reg.checkedIn = true;
      reg.checkedInAt = now;
      reg.checkedInBy = DEMO_ADMIN_EMAIL;
      saveDemoRegistrations(registrations);
      return { ok: true, id, fullName: reg.fullName };
    }

    default:
      throw new AdminApiError(`Route inconnue en mode démo : ${route}`, 404);
  }
}

export async function adminFetch(path: string, init: RequestInit = {}): Promise<any> {
  if (isDemoMode) return demoFetch(path, init);
  if (!API_BASE_URL) {
    throw new AdminApiError("Backend non configuré (VITE_API_BASE_URL manquant).", 0);
  }
  const idToken = await getIdToken();
  if (!idToken) {
    throw new AdminApiError("Session administrateur expirée, reconnectez-vous.", 401);
  }
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...init,
    headers: {
      ...(init.headers || {}),
      Authorization: `Bearer ${idToken}`,
      ...(init.body ? { "Content-Type": "application/json" } : {}),
    },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || data.ok === false) {
    throw new AdminApiError(data.error || `Erreur serveur (${response.status})`, response.status);
  }
  return data;
}
