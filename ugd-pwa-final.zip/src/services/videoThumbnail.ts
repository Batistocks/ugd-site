// UGD (Un Geste Divin) — video thumbnail capture before upload.
//
// Runs entirely in the browser (HTMLVideoElement + Canvas, no
// dependency, no server round-trip) so that adding a video from the
// Médiathèque admin panel never requires a separate "upload a thumbnail
// too" step — the poster frame and the duration are both derived
// straight from the video file itself, the same way imageCompression.ts
// derives a smaller JPEG from a photo file.

export interface VideoThumbnailResult {
  /** JPEG poster frame, ready to upload/store the same way a photo is. */
  thumbnail: File;
  /** Formatted as m:ss (e.g. "0:47"), matching the existing playlist data. */
  duration: string;
  durationSeconds: number;
}

const THUMBNAIL_MAX_DIMENSION = 640;

function loadVideo(file: File): Promise<HTMLVideoElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const video = document.createElement("video");
    video.preload = "metadata";
    video.muted = true;
    video.playsInline = true;
    video.src = url;
    video.onloadedmetadata = () => resolve(video);
    video.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Impossible de lire la vidéo (fichier corrompu ou format non supporté)."));
    };
  });
}

function seekTo(video: HTMLVideoElement, time: number): Promise<void> {
  return new Promise((resolve, reject) => {
    const onSeeked = () => {
      video.removeEventListener("seeked", onSeeked);
      video.removeEventListener("error", onError);
      resolve();
    };
    const onError = () => {
      video.removeEventListener("seeked", onSeeked);
      video.removeEventListener("error", onError);
      reject(new Error("Échec de la capture de la vignette vidéo."));
    };
    video.addEventListener("seeked", onSeeked);
    video.addEventListener("error", onError);
    video.currentTime = time;
  });
}

function captureFrame(video: HTMLVideoElement): Promise<Blob> {
  const scale = Math.min(1, THUMBNAIL_MAX_DIMENSION / Math.max(video.videoWidth, video.videoHeight));
  const width = Math.round(video.videoWidth * scale);
  const height = Math.round(video.videoHeight * scale);

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas 2D non disponible dans ce navigateur.");
  ctx.drawImage(video, 0, 0, width, height);

  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => (blob ? resolve(blob) : reject(new Error("Échec de l'encodage de la vignette."))),
      "image/jpeg",
      0.85,
    );
  });
}

export function formatDuration(totalSeconds: number): string {
  const seconds = Math.max(0, Math.round(totalSeconds));
  const minutes = Math.floor(seconds / 60);
  const remainder = seconds % 60;
  return `${minutes}:${String(remainder).padStart(2, "0")}`;
}

/**
 * Captures a poster-frame JPEG (at ~1s in, or the midpoint for very
 * short clips) plus the formatted duration from a video file — both
 * derived client-side, no upload round-trip needed just to get a
 * thumbnail. Throws if the browser can't decode the file locally (still
 * fine to upload — MediaLibraryPanel.tsx falls back to asking the admin
 * for a thumbnail URL when this fails).
 */
export async function captureVideoThumbnail(file: File): Promise<VideoThumbnailResult> {
  if (!file.type.startsWith("video/")) {
    throw new Error("captureVideoThumbnail: le fichier fourni n'est pas une vidéo.");
  }

  const video = await loadVideo(file);
  try {
    const durationSeconds = video.duration;
    const seekTime = Number.isFinite(durationSeconds) ? Math.min(1, durationSeconds / 2) : 0;
    await seekTo(video, seekTime);
    const blob = await captureFrame(video);
    const thumbnail = new File(
      [blob],
      file.name.replace(/\.[^.]+$/, "") + ".jpg",
      { type: "image/jpeg", lastModified: Date.now() },
    );
    return {
      thumbnail,
      duration: formatDuration(durationSeconds),
      durationSeconds,
    };
  } finally {
    URL.revokeObjectURL(video.src);
  }
}
