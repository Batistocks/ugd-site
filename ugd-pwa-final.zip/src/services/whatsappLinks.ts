import { WHATSAPP_NUMBER } from "../components/WhatsAppButton";

/**
 * Pre-filled WhatsApp messages for the three JMSA flows that finish on
 * WhatsApp — Sponsoring, Billetterie and Inscription. They all use the
 * same pattern: the visitor fills the form on the site, gets their
 * provisional receipt / confirmation on screen, and only THEN taps the
 * WhatsApp button (never before) to send these details to the association.
 *
 * Only the Billetterie message talks about the ticket/badge: the badge is
 * delivered with a gala ticket and nowhere else — the association sends it
 * back (WhatsApp or e-mail) once the payment has been verified.
 */

type Lang = "fr" | "en";

function waLink(message: string): string {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

export interface TransferInfo {
  /** Tier name (sponsoring) or ticket category (billetterie). */
  itemName: string;
  donorName: string;
  amount: string;
  method: string;
  receiptId: string;
}

/** Sponsoring: reports the transfer + provisional receipt. */
export function buildSponsoringWhatsappLink(lang: Lang, event: string, info: TransferInfo): string {
  const message =
    lang === "en"
      ? `Hello UGD, I have just made my sponsorship transfer for ${event}.\nLevel: ${info.itemName}\nName: ${info.donorName}\nAmount: ${info.amount} € (${info.method})\nProvisional receipt No.: ${info.receiptId}\nI am attaching my transfer proof. Could you please confirm receipt of my payment?`
      : `Bonjour UGD, je viens d'effectuer mon virement de sponsoring pour ${event}.\nPalier : ${info.itemName}\nNom : ${info.donorName}\nMontant : ${info.amount} € (${info.method})\nReçu provisoire n° : ${info.receiptId}\nJe joins ma preuve de virement. Pouvez-vous me confirmer la bonne réception de mon paiement ?`;
  return waLink(message);
}

/** Billetterie: reports the transfer AND asks for the ticket (badge) once validated. */
export function buildTicketWhatsappLink(lang: Lang, event: string, info: TransferInfo): string {
  const message =
    lang === "en"
      ? `Hello UGD, I have just paid for my gala ticket for ${event}.\nTicket: ${info.itemName}\nName: ${info.donorName}\nAmount: ${info.amount} € (${info.method})\nProvisional receipt No.: ${info.receiptId}\nI am attaching my transfer proof. Could you please validate my payment and send me my ticket (access badge)?`
      : `Bonjour UGD, je viens de régler mon billet de gala pour ${event}.\nBillet : ${info.itemName}\nNom : ${info.donorName}\nMontant : ${info.amount} € (${info.method})\nReçu provisoire n° : ${info.receiptId}\nJe joins ma preuve de virement. Pouvez-vous valider mon paiement et m'envoyer mon ticket (badge d'accès) ?`;
  return waLink(message);
}

/** Inscription: asks the association to confirm the registration (no badge). */
export function buildRegistrationWhatsappLink(
  lang: Lang,
  info: { fullName: string; registrationId: string; eventShortTitle: string; day: string; ticketType: string },
): string {
  const message =
    lang === "en"
      ? `Hello UGD, I just registered for ${info.eventShortTitle}.\nName: ${info.fullName}\nRef: ${info.registrationId}\nDay: ${info.day}\nType: ${info.ticketType}\nCould you please confirm my registration?`
      : `Bonjour UGD, je viens de m'inscrire à ${info.eventShortTitle}.\nNom : ${info.fullName}\nRéf : ${info.registrationId}\nJour : ${info.day}\nFormule : ${info.ticketType}\nMerci de bien vouloir confirmer mon inscription.`;
  return waLink(message);
}

/**
 * Turns a number typed by a visitor into the digits wa.me needs
 * ("+32 472 28 50 39" → "32472285039"). Only numbers that carry their
 * country code ("+…" or "00…") are accepted: a local number such as
 * "0472…" can't be guessed, so it returns null and the caller falls back
 * to WhatsApp's own contact picker.
 */
export function normalizeWhatsappNumber(raw: string | null | undefined): string | null {
  const cleaned = String(raw ?? "").replace(/[\s().-]/g, "");
  let digits: string;
  if (cleaned.startsWith("+")) digits = cleaned.slice(1);
  else if (cleaned.startsWith("00")) digits = cleaned.slice(2);
  else return null;
  return /^[1-9]\d{7,14}$/.test(digits) ? digits : null;
}

/**
 * Live formatter for WhatsApp number inputs: forces the country-code
 * prefix. Whatever the visitor types, the field always starts with "+"
 * ("0032…" and "00…" become "+32…"); only digits, spaces and a few
 * separators are kept. A local number typed with its trunk zero
 * ("0472…") becomes "+0472…", which stays visibly invalid
 * (isValidWhatsappNumber → false) instead of being silently rewritten
 * into a wrong international number.
 */
export function formatWhatsappInput(raw: string): string {
  let v = String(raw ?? "").replace(/[^\d+\s().-]/g, "");
  if (!v.trim()) return "";
  v = v.replace(/^\s+/, "");
  // Only one "+", and only in first position.
  v = v.replace(/\+/g, (_m, offset: number) => (offset === 0 ? "+" : ""));
  if (!v.startsWith("+")) v = "+" + v;
  // "+00…" (international prefix typed as 00) → "+…"
  v = v.replace(/^\+00+/, "+");
  return v;
}

/** True when the value is a full international number (+ country code + number). */
export function isValidWhatsappNumber(raw: string | null | undefined): boolean {
  return normalizeWhatsappNumber(raw) !== null;
}

/** Canonical stored form: "+" followed by digits only ("+32 472 28 50 39" → "+32472285039"). */
export function toInternationalNumber(raw: string | null | undefined): string | null {
  const digits = normalizeWhatsappNumber(raw);
  return digits ? `+${digits}` : null;
}
