// UGD (Un Geste Divin) — Section 6: Cloudinary, Metadata & Deployment
//
// Client-side unsigned upload integration. No SDK dependency is added —
// this talks directly to Cloudinary's public REST endpoint with `fetch`,
// the same way the rest of the app avoids extra packages where a native
// API is enough (see authService.ts / QRScannerModal.tsx).
//
// SETUP (not committed): create a `.env` file at the project root (see
// `.env.example`) with:
//   VITE_CLOUDINARY_CLOUD_NAME=your-cloud-name
//   VITE_CLOUDINARY_UPLOAD_PRESET=your-unsigned-preset
// The preset must be configured in the Cloudinary console as
// "Unsigned" (Settings → Upload → Upload presets). No API key or API
// secret ever belongs in front-end code — the unsigned preset is the
// correct and only credential exposed to the browser.
//
// Until those two variables are set, `isCloudinaryConfigured()` returns
// false and every caller in this app falls back to its existing
// offline-friendly behaviour (data-URL storage via IndexedDB), so the
// PWA keeps working out of the box without a Cloudinary account.

export type CloudinaryResourceType = "image" | "video" | "raw";

export interface CloudinaryUploadResult {
  publicId: string;
  secureUrl: string;
  resourceType: CloudinaryResourceType;
  format: string;
  bytes: number;
  width?: number;
  height?: number;
  duration?: number;
  originalFilename?: string;
}

interface CloudinaryConfig {
  cloudName: string;
  uploadPreset: string;
}

function readConfig(): CloudinaryConfig | null {
  const cloudName = import.meta.env.VITE_CLOUDINARY_CLOUD_NAME as string | undefined;
  const uploadPreset = import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET as string | undefined;
  if (!cloudName || !uploadPreset) return null;
  return { cloudName, uploadPreset };
}

export function isCloudinaryConfigured(): boolean {
  return readConfig() !== null;
}

/**
 * Picks the right Cloudinary resource type bucket for an upload.
 * Cloudinary treats PDFs (and any other non-image/video file) as "raw".
 */
export function resourceTypeForFile(file: File): CloudinaryResourceType {
  if (file.type.startsWith("image/")) return "image";
  if (file.type.startsWith("video/")) return "video";
  return "raw";
}

export interface UploadOptions {
  /** Cloudinary folder, e.g. "flyers", "videos", "reports". Keeps the media library organised. */
  folder?: string;
  /** Called with 0–100 as the upload progresses (uses XHR under the hood so this works, unlike plain fetch). */
  onProgress?: (percent: number) => void;
  /** Force a resource type instead of inferring it from the file's MIME type. */
  resourceType?: CloudinaryResourceType;
}

/**
 * Uploads a single file (MP4 video, HD flyer/photo, or PDF document) to
 * Cloudinary via the unsigned upload API and returns the resulting
 * secure delivery URL plus metadata.
 *
 * Throws if Cloudinary isn't configured — callers should check
 * `isCloudinaryConfigured()` first and offer the existing data-URL /
 * offline path otherwise (see `FlyerMediaPanel.tsx`).
 */
export function uploadToCloudinary(file: File, options: UploadOptions = {}): Promise<CloudinaryUploadResult> {
  const config = readConfig();
  if (!config) {
    return Promise.reject(
      new Error(
        "Cloudinary n'est pas configuré (VITE_CLOUDINARY_CLOUD_NAME / VITE_CLOUDINARY_UPLOAD_PRESET manquants).",
      ),
    );
  }

  const resourceType = options.resourceType ?? resourceTypeForFile(file);
  const endpoint = `https://api.cloudinary.com/v1_1/${config.cloudName}/${resourceType}/upload`;

  const formData = new FormData();
  formData.append("file", file);
  formData.append("upload_preset", config.uploadPreset);
  if (options.folder) formData.append("folder", options.folder);

  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", endpoint, true);

    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable && options.onProgress) {
        options.onProgress(Math.round((event.loaded / event.total) * 100));
      }
    };

    xhr.onload = () => {
      let body: Record<string, unknown> | null = null;
      try {
        body = JSON.parse(xhr.responseText);
      } catch {
        // fall through to the generic error below
      }

      if (xhr.status >= 200 && xhr.status < 300 && body) {
        resolve({
          publicId: String(body.public_id),
          secureUrl: String(body.secure_url),
          resourceType,
          format: String(body.format ?? ""),
          bytes: Number(body.bytes ?? file.size),
          width: typeof body.width === "number" ? body.width : undefined,
          height: typeof body.height === "number" ? body.height : undefined,
          duration: typeof body.duration === "number" ? body.duration : undefined,
          originalFilename: typeof body.original_filename === "string" ? body.original_filename : file.name,
        });
      } else {
        const message =
          (body && typeof body.error === "object" && body.error !== null && "message" in body.error
            ? String((body.error as { message?: unknown }).message)
            : null) ?? `Échec de l'envoi vers Cloudinary (HTTP ${xhr.status}).`;
        reject(new Error(message));
      }
    };

    xhr.onerror = () => reject(new Error("Échec réseau lors de l'envoi vers Cloudinary."));
    xhr.send(formData);
  });
}

/**
 * Builds an optimised delivery URL from a stored public ID, applying
 * `f_auto,q_auto` (automatic format/quality — the Cloudinary-recommended
 * default for both images and videos) plus any extra transformation
 * string, e.g. `buildDeliveryUrl(id, "video", "w_800")`.
 */
export function buildDeliveryUrl(
  publicId: string,
  resourceType: CloudinaryResourceType,
  extraTransformation?: string,
): string {
  const config = readConfig();
  if (!config) return "";
  const transformation = ["f_auto", "q_auto", extraTransformation].filter(Boolean).join(",");
  const deliveryType = resourceType === "raw" ? "raw" : resourceType;
  return `https://res.cloudinary.com/${config.cloudName}/${deliveryType}/upload/${transformation}/${publicId}`;
}
