import type { Lang } from "../i18n/translations";

export interface LegalSection {
  heading: string;
  paragraphs: string[];
}

/**
 * Content for the "Mentions légales" and "Politique de confidentialité"
 * tabs of LegalModal.tsx, linked from the footer.
 *
 * ⚠️ Drafted from the association's own public contact/registration
 * details (see src/constants/theme.ts, src/data/donationAccounts.ts) and
 * from what this codebase actually collects (see src/services/db.ts,
 * netlify/functions/) — but this is boilerplate, not legal advice. Have
 * it reviewed by a lawyer familiar with Belgian/EU law (AISBL + RGPD)
 * before publishing, especially the data-retention durations, which are
 * reasonable defaults rather than figures confirmed by the association.
 */

const LEGAL_NOTICE_FR: LegalSection[] = [
  {
    heading: "Éditeur du site",
    paragraphs: [
      "Ce site et cette application sont édités par l'AISBL UN GESTE DIVIN, association internationale sans but lucratif de droit belge.",
      "Siège social : Rue du Collège 25 bte 21, 6000 Charleroi, Belgique.",
      "Numéro d'entreprise : 1014.435.995 — TVA : BE1014.435.995.",
      "Contact : internationaleungestedivin@gmail.com — +32 472 28 50 39 — www.ungestedivin.org.",
    ],
  },
  {
    heading: "Hébergement",
    paragraphs: [
      "Le site, l'application et les fonctions serveur sont hébergés par Netlify, Inc. (États-Unis).",
      "La base de données et l'authentification des administrateurs sont fournies par Firebase (Google Ireland Limited, Irlande), dans la région europe-west1.",
      "Les fichiers (preuves de paiement, reçus, badges, images et flyers) sont stockés sur Cloudinary (États-Unis).",
    ],
  },
  {
    heading: "Propriété intellectuelle",
    paragraphs: [
      "L'ensemble des textes, images, logos et documents présents sur ce site est la propriété de l'AISBL UN GESTE DIVIN, sauf mention contraire, et ne peut être reproduit sans autorisation préalable.",
    ],
  },
  {
    heading: "Responsabilité",
    paragraphs: [
      "L'association s'efforce d'assurer l'exactitude des informations diffusées sur ce site, sans pouvoir garantir qu'elles soient exemptes d'erreur. L'AISBL UN GESTE DIVIN ne saurait être tenue responsable d'éventuelles interruptions du service ou d'un usage impropre de l'application, notamment en cas de perte de connexion (l'application fonctionne toutefois hors ligne pour ses fonctions principales).",
    ],
  },
];

const LEGAL_NOTICE_EN: LegalSection[] = [
  {
    heading: "Site publisher",
    paragraphs: [
      "This site and application are published by AISBL UN GESTE DIVIN, an international non-profit association under Belgian law.",
      "Registered office: Rue du Collège 25 bte 21, 6000 Charleroi, Belgium.",
      "Company number: 1014.435.995 — VAT: BE1014.435.995.",
      "Contact: internationaleungestedivin@gmail.com — +32 472 28 50 39 — www.ungestedivin.org.",
    ],
  },
  {
    heading: "Hosting",
    paragraphs: [
      "The site, the application and the server functions are hosted by Netlify, Inc. (United States).",
      "The database and administrator authentication are provided by Firebase (Google Ireland Limited, Ireland), region europe-west1.",
      "Files (payment proofs, receipts, badges, images and flyers) are stored on Cloudinary (United States).",
    ],
  },
  {
    heading: "Intellectual property",
    paragraphs: [
      "All text, images, logos and documents on this site are the property of AISBL UN GESTE DIVIN, unless stated otherwise, and may not be reproduced without prior authorization.",
    ],
  },
  {
    heading: "Liability",
    paragraphs: [
      "The association strives to ensure the accuracy of the information published on this site, without being able to guarantee it is free of error. AISBL UN GESTE DIVIN cannot be held liable for service interruptions or improper use of the application, including loss of connectivity (the application's core functions nonetheless work offline).",
    ],
  },
];

const PRIVACY_POLICY_FR: LegalSection[] = [
  {
    heading: "Responsable du traitement",
    paragraphs: [
      "L'AISBL UN GESTE DIVIN (coordonnées ci-dessus, onglet Mentions légales) est responsable du traitement des données personnelles collectées via ce site et cette application, conformément au Règlement Général sur la Protection des Données (RGPD).",
    ],
  },
  {
    heading: "Données collectées",
    paragraphs: [
      "Demande de pass JMSA 2026 : nom complet, email, numéro WhatsApp (avec indicatif du pays), organisation (facultatif).",
      "Preuve de don, de sponsoring ou de billetterie : nom, email (facultatif), numéro WhatsApp (obligatoire pour un billet de gala), montant, mode de paiement, et le fichier de preuve de virement transmis (capture d'écran ou PDF, 2 Mo maximum).",
      "Mesure anti-abus : une empreinte irréversible (hachage) de votre adresse IP est conservée temporairement afin de limiter le nombre d'envois de formulaires. L'adresse IP elle-même n'est pas enregistrée.",
      "Aucune donnée de paiement (numéro de carte, identifiants bancaires) n'est collectée par l'application elle-même : les paiements se font par virement ou Mobile Money directement entre le donateur et l'association.",
      "Aucun cookie publicitaire ou traceur tiers n'est utilisé. L'application stocke uniquement, sur l'appareil du visiteur, la langue choisie et les données nécessaires au fonctionnement hors ligne (file d'attente de vos propres formulaires en attente d'envoi).",
    ],
  },
  {
    heading: "Finalités et base légale",
    paragraphs: [
      "Ces données sont utilisées pour : générer votre badge d'entrée et vérifier votre accès à l'événement JMSA 2026, vérifier votre don/sponsoring et vous délivrer un reçu, et vous recontacter si nécessaire au sujet de votre demande.",
      "Base légale : l'exécution d'une demande à votre initiative (inscription, don) et, pour les reçus de don, le respect d'obligations comptables et fiscales de l'association.",
    ],
  },
  {
    heading: "Durée de conservation",
    paragraphs: [
      "Les demandes de pass sont conservées jusqu'à la fin de l'événement JMSA 2026 puis archivées ou supprimées.",
      "Les reçus de don et pièces justificatives sont conservés pendant la durée légale de conservation des pièces comptables en Belgique (en principe 7 ans), conformément aux obligations fiscales de l'association.",
    ],
  },
  {
    heading: "Destinataires",
    paragraphs: [
      "Vos données sont accessibles aux administrateurs habilités de l'AISBL UN GESTE DIVIN, ainsi qu'aux prestataires techniques cités dans l'onglet Mentions légales (Firebase/Google, Cloudinary, Netlify), dans la stricte mesure nécessaire au fonctionnement du site et à l'envoi de vos documents.",
    ],
  },
  {
    heading: "Vos droits",
    paragraphs: [
      "Conformément au RGPD, vous disposez d'un droit d'accès, de rectification, d'effacement, de limitation et d'opposition concernant vos données, ainsi que d'un droit à la portabilité. Pour exercer ces droits, contactez l'association à internationaleungestedivin@gmail.com.",
      "Vous disposez également du droit d'introduire une réclamation auprès de l'Autorité de protection des données (APD) belge — www.autoriteprotectiondonnees.be.",
    ],
  },
];

const PRIVACY_POLICY_EN: LegalSection[] = [
  {
    heading: "Data controller",
    paragraphs: [
      "AISBL UN GESTE DIVIN (contact details in the Legal Notice tab) is the controller responsible for personal data collected through this site and application, in accordance with the General Data Protection Regulation (GDPR).",
    ],
  },
  {
    heading: "Data collected",
    paragraphs: [
      "JMSA 2026 pass request: full name, email, WhatsApp number (with country code), organization (optional).",
      "Donation, sponsorship or ticket proof: name, email (optional), WhatsApp number (required for a gala ticket), amount, payment method, and the transfer proof file submitted (screenshot or PDF, 2 MB maximum).",
      "Abuse prevention: an irreversible hash of your IP address is kept temporarily to limit the number of form submissions. The IP address itself is not stored.",
      "No payment data (card number, bank credentials) is collected by the application itself: payments are made by bank transfer or Mobile Money directly between the donor and the association.",
      "No advertising cookies or third-party trackers are used. The application only stores, on the visitor's device, the chosen language and the data needed for offline operation (a queue of your own forms awaiting submission).",
    ],
  },
  {
    heading: "Purposes and legal basis",
    paragraphs: [
      "This data is used to: generate your entrance badge and verify your access to the JMSA 2026 event, verify your donation/sponsorship and issue a receipt, and contact you if needed about your request.",
      "Legal basis: fulfilling a request you initiated (registration, donation) and, for donation receipts, the association's accounting and tax obligations.",
    ],
  },
  {
    heading: "Retention period",
    paragraphs: [
      "Pass requests are kept until the end of the JMSA 2026 event, then archived or deleted.",
      "Donation receipts and supporting documents are kept for the legal retention period for accounting records in Belgium (generally 7 years), in line with the association's tax obligations.",
    ],
  },
  {
    heading: "Recipients",
    paragraphs: [
      "Your data is accessible to authorized administrators of AISBL UN GESTE DIVIN, as well as the technical providers listed in the Legal Notice tab (Firebase/Google, Cloudinary, Netlify), strictly as needed to operate the site and deliver your documents.",
    ],
  },
  {
    heading: "Your rights",
    paragraphs: [
      "Under the GDPR, you have the right to access, rectify, erase, restrict and object regarding your data, as well as a right to data portability. To exercise these rights, contact the association at internationaleungestedivin@gmail.com.",
      "You also have the right to lodge a complaint with the Belgian Data Protection Authority (APD) — www.autoriteprotectiondonnees.be.",
    ],
  },
];

export function getLegalNotice(lang: Lang): LegalSection[] {
  return lang === "en" ? LEGAL_NOTICE_EN : LEGAL_NOTICE_FR;
}

export function getPrivacyPolicy(lang: Lang): LegalSection[] {
  return lang === "en" ? PRIVACY_POLICY_EN : PRIVACY_POLICY_FR;
}
