export interface HomeGalleryImage {
  id: string;
  src: string;
  alt: string;
}

/**
 * Photos of the association itself — team, field actions, official
 * presence — shown as a tappable thumbnail strip on the home page
 * (Espace 1 : Accueil), in the exact same visual style as the JMSA
 * flyer gallery (see JMSAHub.tsx).
 *
 * On purpose this list never includes JMSA 2026 summit photos/flyers —
 * those stay confined to their own "Espace" (JMSAHub.tsx), per the
 * client's request that the home page only ever show the association's
 * own imagery.
 *
 * To add a new photo: drop the file in /public/media/, then add a line
 * below. Keep portrait-ish photos (roughly 3:4) for the cleanest crop —
 * the thumbnail is fixed at 96×128px (w-24 h-32) and uses object-cover.
 */
export const HOME_GALLERY: HomeGalleryImage[] = [
  {
    id: "founder",
    src: "/team/marie-makamgue-un.jpg",
    alt: "Marie Nicaise Makamgue Djembong, Fondatrice et Présidente",
  },
  {
    id: "commission-europeenne",
    src: "/media/commission-europeenne-intervention.jpg",
    alt: "Intervention de la Présidente à la Commission européenne, European Climate Pact",
  },
  {
    id: "climate-pact-2025",
    src: "/media/european-climate-pact-2025.jpg",
    alt: "UGD au sommet « The European Climate Pact — Together in Action »",
  },
  {
    id: "stand-marche-liege",
    src: "/media/stand-marche-liege.jpg",
    alt: "Stand de sensibilisation de la Ligue des Associations d'Aide Humanitaire, Liège",
  },
  {
    id: "reunion-equipe-benevoles",
    src: "/media/reunion-equipe-benevoles.jpg",
    alt: "Réunion de l'équipe et des bénévoles de l'association",
  },
  {
    id: "reseau-femmes-partenaires",
    src: "/media/reseau-femmes-partenaires.jpg",
    alt: "Rencontre avec le réseau de femmes partenaires de l'association",
  },
  {
    id: "asda-cameroun-enfants",
    src: "/media/asda-cameroun-enfants.jpg",
    alt: "Visite auprès des enfants du Centre ASDA au Cameroun",
  },
  {
    id: "nettoyage-communautaire",
    src: "/media/nettoyage-communautaire.jpg",
    alt: "Journée de nettoyage communautaire menée par les bénévoles de l'association",
  },
  {
    id: "distribution-terrain-rdc",
    src: "/media/distribution-terrain-rdc.jpg",
    alt: "Distribution de matériel aux familles lors d'une action de terrain",
  },
  {
    id: "distribution-village-benin",
    src: "/media/distribution-village-benin.jpg",
    alt: "Action de terrain auprès des enfants et familles d'un village",
  },
  {
    id: "distribution-foule-porte",
    src: "/media/distribution-foule-porte.jpg",
    alt: "Distribution de l'association auprès d'une foule à l'entrée d'un site",
  },
  {
    id: "maison-repos-fauteuil-1",
    src: "/media/maison-repos-fauteuil-1.jpg",
    alt: "Bénévole accompagnant une résidente en fauteuil roulant dans une maison de repos",
  },
  {
    id: "rdc-goma-enfants",
    src: "/media/rdc-goma-enfants.jpg",
    alt: "Action auprès des enfants à Goma, RDC",
  },
  {
    id: "remise-attestation-cadre",
    src: "/media/remise-attestation-cadre.jpg",
    alt: "Remise d'une attestation de participation",
  },
  {
    id: "togo-lome-enfants",
    src: "/media/togo-lome-enfants.jpg",
    alt: "Action auprès des enfants à Lomé, Togo",
  },
  {
    id: "cameroun-douala-eleves",
    src: "/media/cameroun-douala-eleves.jpg",
    alt: "Sensibilisation auprès d'élèves à Douala, Cameroun",
  },
  {
    id: "visite-centre-tri-valtris",
    src: "/media/visite-centre-tri-valtris.jpg",
    alt: "Visite d'un centre de tri et de recyclage avec des partenaires",
  },
  {
    id: "maternite-nouveau-ne",
    src: "/media/maternite-nouveau-ne.jpg",
    alt: "Visite auprès d'une mère et de son nouveau-né en maternité",
  },
  {
    id: "special-olympics-cameroun",
    src: "/media/special-olympics-cameroun.jpg",
    alt: "Participation à un événement Special Olympics Cameroun",
  },
  {
    id: "maison-repos-equipe-1",
    src: "/media/maison-repos-equipe-1.jpg",
    alt: "Équipe de bénévoles auprès des résidents d'une maison de repos",
  },
  {
    id: "remise-certificats-salle",
    src: "/media/remise-certificats-salle.jpg",
    alt: "Cérémonie de remise de certificats",
  },
  {
    id: "sommet-turquie-akparti",
    src: "/media/sommet-turquie-akparti.jpg",
    alt: "Participation à un sommet international en Turquie",
  },
  {
    id: "turquie-drapeaux-sarayli",
    src: "/media/turquie-drapeaux-sarayli.jpg",
    alt: "Présence institutionnelle en Turquie",
  },
  {
    id: "reunion-rdc-cameroun",
    src: "/media/reunion-rdc-cameroun.jpg",
    alt: "Réunion de travail avec des partenaires de RDC et du Cameroun",
  },
  {
    id: "maison-repos-groupe-2",
    src: "/media/maison-repos-groupe-2.jpg",
    alt: "Moment partagé avec les résidents d'une maison de repos",
  },
  {
    id: "portrait-duo-partenaire",
    src: "/media/portrait-duo-partenaire.jpg",
    alt: "La Présidente de l'association avec une partenaire",
  },
  {
    id: "drapeaux-cameroun-burkina",
    src: "/media/drapeaux-cameroun-burkina.jpg",
    alt: "Rencontre institutionnelle avec les délégations du Cameroun et du Burkina Faso",
  },
  {
    id: "conference-podium-drapeaux",
    src: "/media/conference-podium-drapeaux.jpg",
    alt: "Intervention de la Présidente lors d'une conférence",
  },
  {
    id: "table-ronde-rdc-cameroun-maroc",
    src: "/media/table-ronde-rdc-cameroun-maroc.jpg",
    alt: "Table ronde avec des délégations de RDC, du Cameroun et du Maroc",
  },
  {
    id: "action-terrain-fauteuil",
    src: "/media/action-terrain-fauteuil.jpg",
    alt: "Action de terrain auprès d'une personne en situation de handicap",
  },
  {
    id: "assemblee-ligue-humanitaire",
    src: "/media/assemblee-ligue-humanitaire.jpg",
    alt: "Assemblée de la Ligue des Associations d'Aide Humanitaire, avec responsables associatifs et élus",
  },
  {
    id: "maison-repos-mains-unies",
    src: "/media/maison-repos-mains-unies.jpg",
    alt: "Moment de solidarité, mains unies, auprès des résidents d'une maison de repos",
  },
  {
    id: "representation-abidjan-cote-ivoire",
    src: "/media/representation-abidjan-cote-ivoire.jpg",
    alt: "Représentation de l'association Un Geste Divin à Abidjan, Côte d'Ivoire",
  },
  // Ajoute ici chaque nouvelle photo de terrain / d'équipe de l'association :
  // { id: "action-terrain-1", src: "/media/action-terrain-1.jpg", alt: "Distribution de vivres, Charleroi 2025" },
];
