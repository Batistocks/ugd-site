import type { Lang } from "../i18n/translations";

export interface AgendaItem {
  time: string;
  label: string;
}

export interface AgendaDay {
  key: "vendredi" | "samedi";
  dateLabel: string;
  hoursLabel: string;
  items: AgendaItem[];
}

// Source: JMSA 2026 — Dossier de Sponsoring, section IV "Programme détaillé".
const agendaFr: AgendaDay[] = [
  {
    key: "vendredi",
    dateLabel: "Vendredi 20 novembre 2026",
    hoursLabel: "10h00 – 22h00",
    items: [
      { time: "09h – 10h", label: "Accueil et enregistrement" },
      { time: "10h – 11h", label: "Cérémonie d'ouverture · Hymnes · Bienvenue · Discours" },
      { time: "11h – 12h30", label: "Conférence inaugurale : Coopération Europe–Afrique" },
      { time: "12h30 – 13h30", label: "Déjeuner – Networking" },
      {
        time: "13h30 – 15h",
        label: "Tables rondes : Droits des femmes · Violences · Inclusion · Développement",
      },
      { time: "15h – 16h", label: "Conférences parallèles" },
      { time: "16h – 17h30", label: "Rencontres B2B et partenariats" },
      { time: "17h30 – 19h", label: "Visite des stands et expositions" },
      { time: "19h – 20h", label: "Résumé et annonces" },
      { time: "20h – 22h", label: "Cocktail de bienvenue & Networking" },
    ],
  },
  {
    key: "samedi",
    dateLabel: "Samedi 21 novembre 2026",
    hoursLabel: "10h00 – 23h00",
    items: [
      { time: "10h – 11h", label: "Accueil des participants" },
      { time: "11h – 12h30", label: "Conférences internationales" },
      { time: "12h30 – 13h30", label: "Déjeuner – Networking" },
      {
        time: "13h30 – 15h30",
        label: "Ateliers : Entrepreneuriat · Éducation · Santé · Financement",
      },
      { time: "15h30 – 17h", label: "Présentations de projets et initiatives" },
      { time: "17h – 18h30", label: "Signature de partenariats et protocoles d'accord" },
      { time: "18h30 – 19h30", label: "Visite des stands et expositions" },
      { time: "19h30 – 20h", label: "Clôture des travaux" },
      {
        time: "16h00 – 00h00",
        label:
          "Soirée de Gala : Cocktail · Dîner de gala · Discours officiels · Remise de distinctions · Networking · Danse · Spectacles · Signature du Livre d'Or de l'Espoir contre les violences",
      },
    ],
  },
];

const agendaEn: AgendaDay[] = [
  {
    key: "vendredi",
    dateLabel: "Friday 20 November 2026",
    hoursLabel: "10:00 AM – 10:00 PM",
    items: [
      { time: "9 – 10 AM", label: "Welcome and registration" },
      { time: "10 – 11 AM", label: "Opening ceremony · Anthems · Welcome · Speeches" },
      { time: "11 AM – 12:30 PM", label: "Keynote conference: Europe–Africa cooperation" },
      { time: "12:30 – 1:30 PM", label: "Lunch – Networking" },
      {
        time: "1:30 – 3 PM",
        label: "Panel discussions: Women's rights · Violence · Inclusion · Development",
      },
      { time: "3 – 4 PM", label: "Parallel conferences" },
      { time: "4 – 5:30 PM", label: "B2B meetings and partnerships" },
      { time: "5:30 – 7 PM", label: "Booth and exhibition visits" },
      { time: "7 – 8 PM", label: "Summary and announcements" },
      { time: "8 – 10 PM", label: "Welcome cocktail & Networking" },
    ],
  },
  {
    key: "samedi",
    dateLabel: "Saturday 21 November 2026",
    hoursLabel: "10:00 AM – 11:00 PM",
    items: [
      { time: "10 – 11 AM", label: "Welcoming of participants" },
      { time: "11 AM – 12:30 PM", label: "International conferences" },
      { time: "12:30 – 1:30 PM", label: "Lunch – Networking" },
      {
        time: "1:30 – 3:30 PM",
        label: "Workshops: Entrepreneurship · Education · Health · Financing",
      },
      { time: "3:30 – 5 PM", label: "Project and initiative presentations" },
      { time: "5 – 6:30 PM", label: "Signing of partnerships and memoranda of understanding" },
      { time: "6:30 – 7:30 PM", label: "Booth and exhibition visits" },
      { time: "7:30 – 8 PM", label: "Closing of proceedings" },
      {
        time: "4 PM – Midnight",
        label:
          "Gala Evening: Cocktail · Gala dinner · Official speeches · Awards ceremony · Networking · Dancing · Performances · Signing of the Golden Book of Hope against violence",
      },
    ],
  },
];

export function getAgenda(lang: Lang): AgendaDay[] {
  return lang === "en" ? agendaEn : agendaFr;
}

export interface EventInfo {
  title: string;
  shortTitle: string;
  slogan: string;
  dateRange: string;
  location: string;
  theme: string;
}

const eventInfoFr: EventInfo = {
  title: "La Journée Mondiale du Sommet des Associations",
  shortTitle: "JMSA 2026",
  slogan: "Unis pour un monde plus juste et plus sûr",
  dateRange: "20 – 21 novembre 2026",
  location: "Charleroi, Belgique",
  theme:
    "Renforcer la synergie Europe–Afrique pour un développement durable, inclusif et humain : lutte contre les violences faites aux femmes et aux enfants.",
};

const eventInfoEn: EventInfo = {
  title: "World Day of the Associations Summit",
  shortTitle: "JMSA 2026",
  slogan: "United for a fairer, safer world",
  dateRange: "20 – 21 November 2026",
  location: "Charleroi, Belgium",
  theme:
    "Strengthening Europe–Africa synergy for sustainable, inclusive and human development: fighting violence against women and children.",
};

export function getEventInfo(lang: Lang): EventInfo {
  return lang === "en" ? eventInfoEn : eventInfoFr;
}

export interface Speaker {
  name: string;
  role: string;
  country?: string;
  badge?: string;
  photo: string;
}

// Source: flyers officiels JMSA 2026 — liste complète des intervenants
// confirmés. Ce tableau est la seule source affichée : remplacer
// entièrement (plutôt que compléter) dès qu'un nouveau lot de flyers est
// fourni par l'association.
const speakersFr: Speaker[] = [
  {
    name: "Mme Obé Mawussé Fantodji",
    role: "Responsable des femmes victimes de violences conjugales au Togo",
    country: "Togo",
    badge: "Panéliste Diamant",
    photo: "/flyers/jmsa-flyer-obe-mawusse.jpg",
  },
  {
    name: "Mlle Erine Scolas",
    role: "Responsable adjointe animatrice, esthéticienne — engagée pour le bien-être et l'autonomisation des femmes",
    country: "Italie",
    badge: "Panéliste Diamant",
    photo: "/flyers/jmsa-flyer-erine-scolas.jpg",
  },
  {
    name: "Mme Alexandra",
    role: "Photographe professionnelle internationale",
    country: "Belgique",
    badge: "Panéliste Diamant",
    photo: "/flyers/jmsa-flyer-alexandra.jpg",
  },
  {
    name: "Mme Édith Delhaye",
    role: "Coordinatrice des victimes de violence et de viol",
    photo: "/flyers/jmsa-flyer-edith-delhaye.jpg",
  },
  {
    name: "Mme Touré Maristella",
    role: "Responsable dans l'administration publique",
    photo: "/flyers/jmsa-flyer-toure-maristella.jpg",
  },
  {
    name: "M. Damien van d'en Breghe",
    role: "Responsable des bénévoles (UGD)",
    photo: "/flyers/jmsa-flyer-damien-vandenbreghe.jpg",
  },
  {
    name: "Mme Nguiemsap Gaelle",
    role: "Responsable générale du secrétariat",
    photo: "/flyers/jmsa-flyer-nguiemsap-gaelle.jpg",
  },
  {
    name: "Mme Kemongne Sorel",
    role: "Chargée de la communication institutionnelle internationale",
    photo: "/flyers/jmsa-flyer-kemongne-sorel.jpg",
  },
  {
    name: "Jacky Biho",
    role: "Artiste invité",
    badge: "Artiste Guest",
    photo: "/flyers/jmsa-flyer-jacky-biho.jpg",
  },
];

const speakersEn: Speaker[] = [
  {
    name: "Mrs Obé Mawussé Fantodji",
    role: "Advocate for women victims of domestic violence in Togo",
    country: "Togo",
    badge: "Diamond Panelist",
    photo: "/flyers/jmsa-flyer-obe-mawusse.jpg",
  },
  {
    name: "Miss Erine Scolas",
    role: "Assistant host & beautician — committed to women's wellbeing and empowerment",
    country: "Italy",
    badge: "Diamond Panelist",
    photo: "/flyers/jmsa-flyer-erine-scolas.jpg",
  },
  {
    name: "Mrs Alexandra",
    role: "International professional photographer",
    country: "Belgium",
    badge: "Diamond Panelist",
    photo: "/flyers/jmsa-flyer-alexandra.jpg",
  },
  {
    name: "Mrs Édith Delhaye",
    role: "Coordinator for victims of violence and rape",
    photo: "/flyers/jmsa-flyer-edith-delhaye.jpg",
  },
  {
    name: "Mrs Touré Maristella",
    role: "Public administration officer",
    photo: "/flyers/jmsa-flyer-toure-maristella.jpg",
  },
  {
    name: "Mr Damien van d'en Breghe",
    role: "Volunteer coordinator (UGD)",
    photo: "/flyers/jmsa-flyer-damien-vandenbreghe.jpg",
  },
  {
    name: "Mrs Nguiemsap Gaelle",
    role: "General secretariat manager",
    photo: "/flyers/jmsa-flyer-nguiemsap-gaelle.jpg",
  },
  {
    name: "Mrs Kemongne Sorel",
    role: "International institutional communications officer",
    photo: "/flyers/jmsa-flyer-kemongne-sorel.jpg",
  },
  {
    name: "Jacky Biho",
    role: "Guest artist",
    badge: "Guest Artist",
    photo: "/flyers/jmsa-flyer-jacky-biho.jpg",
  },
];

export function getSpeakers(lang: Lang): Speaker[] {
  return lang === "en" ? speakersEn : speakersFr;
}
