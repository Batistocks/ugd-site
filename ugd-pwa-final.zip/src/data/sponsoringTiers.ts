import type { Lang } from "../i18n/translations";

export interface SponsoringTier {
  id: string;
  name: string;
  price: string;
  group: "principal" | "partenaire" | "association";
  benefits: string[];
}

// Source: JMSA 2026 — Dossier de Sponsoring, section V "Offres de sponsoring".
const sponsoringTiersFr: SponsoringTier[] = [
  {
    id: "or",
    name: "Sponsor Or",
    price: "1 500 €",
    group: "principal",
    benefits: [
      "1 stand pendant les 2 jours",
      "Logo sur le flyer officiel",
      "1 entrée valable 2 jours",
      "1 invitation soirée de gala",
      "1 accès VIP Or",
    ],
  },
  {
    id: "diamant",
    name: "Sponsor Diamant",
    price: "2 000 €",
    group: "principal",
    benefits: [
      "1 stand pendant les 2 jours",
      "Logo sur le flyer officiel",
      "Prise de parole pendant l'événement",
      "2 entrées valables 2 jours",
      "Interview avec les médias",
      "1 repas de gala",
      "1 accès VIP Diamant",
    ],
  },
  {
    id: "platinum",
    name: "Sponsor Platinum",
    price: "2 500 €",
    group: "principal",
    benefits: [
      "1 stand Premium",
      "Logo sur le flyer officiel",
      "Prise de parole pendant l'événement",
      "3 entrées valables 2 jours",
      "Interview avec les médias",
      "Distribution affiches / flyers",
      "2 repas de gala",
      "2 accès VIP Diamant",
    ],
  },
  {
    id: "partenaire",
    name: "Partenaire",
    price: "500 €",
    group: "partenaire",
    benefits: [
      "1 stand",
      "Logo sur le flyer officiel",
      "1 entrée valable 2 jours",
      "1 entrée simple soirée de gala",
    ],
  },
  {
    id: "partenaire-plus",
    name: "Partenaire +",
    price: "1 000 €",
    group: "partenaire",
    benefits: [
      "1 stand",
      "Logo sur le flyer officiel",
      "1 entrée valable 2 jours",
      "1 invitation soirée de gala",
      "1 accès VIP Or",
    ],
  },
  {
    id: "essentiel",
    name: "Essentiel",
    price: "200 €",
    group: "association",
    benefits: ["1 stand 2 jours", "Toutes les conférences", "Foire des stands", "Sans entrée soirée de gala"],
  },
  {
    id: "standard",
    name: "Standard",
    price: "300 €",
    group: "association",
    benefits: [
      "1 stand 2 jours",
      "Toutes les conférences",
      "Foire des stands",
      "1 entrée simple soirée de gala",
    ],
  },
  {
    id: "privilege",
    name: "Privilège",
    price: "350 €",
    group: "association",
    benefits: [
      "1 stand 2 jours",
      "Toutes les conférences",
      "Foire des stands",
      "Prise de parole (limitée)",
      "1 entrée VIP Or soirée de gala",
    ],
  },
];

const sponsoringTiersEn: SponsoringTier[] = [
  {
    id: "or",
    name: "Gold Sponsor",
    price: "1 500 €",
    group: "principal",
    benefits: [
      "1 booth for both days",
      "Logo on the official flyer",
      "1 pass valid for 2 days",
      "1 gala evening invitation",
      "1 Gold VIP access",
    ],
  },
  {
    id: "diamant",
    name: "Diamond Sponsor",
    price: "2 000 €",
    group: "principal",
    benefits: [
      "1 booth for both days",
      "Logo on the official flyer",
      "Speaking slot during the event",
      "2 passes valid for 2 days",
      "Media interview",
      "1 gala meal",
      "1 Diamond VIP access",
    ],
  },
  {
    id: "platinum",
    name: "Platinum Sponsor",
    price: "2 500 €",
    group: "principal",
    benefits: [
      "1 Premium booth",
      "Logo on the official flyer",
      "Speaking slot during the event",
      "3 passes valid for 2 days",
      "Media interview",
      "Poster / flyer distribution",
      "2 gala meals",
      "2 Diamond VIP accesses",
    ],
  },
  {
    id: "partenaire",
    name: "Partner",
    price: "500 €",
    group: "partenaire",
    benefits: [
      "1 booth",
      "Logo on the official flyer",
      "1 pass valid for 2 days",
      "1 standard gala evening entry",
    ],
  },
  {
    id: "partenaire-plus",
    name: "Partner +",
    price: "1 000 €",
    group: "partenaire",
    benefits: [
      "1 booth",
      "Logo on the official flyer",
      "1 pass valid for 2 days",
      "1 gala evening invitation",
      "1 Gold VIP access",
    ],
  },
  {
    id: "essentiel",
    name: "Essential",
    price: "200 €",
    group: "association",
    benefits: ["1 booth for 2 days", "All conferences", "Exhibitor fair", "No gala evening entry"],
  },
  {
    id: "standard",
    name: "Standard",
    price: "300 €",
    group: "association",
    benefits: [
      "1 booth for 2 days",
      "All conferences",
      "Exhibitor fair",
      "1 standard gala evening entry",
    ],
  },
  {
    id: "privilege",
    name: "Privilege",
    price: "350 €",
    group: "association",
    benefits: [
      "1 booth for 2 days",
      "All conferences",
      "Exhibitor fair",
      "Speaking slot (limited)",
      "1 Gold VIP gala evening entry",
    ],
  },
];

export function getSponsoringTiers(lang: Lang): SponsoringTier[] {
  return lang === "en" ? sponsoringTiersEn : sponsoringTiersFr;
}

export interface GalaTicket {
  id: string;
  name: string;
  price: string;
  benefits: string[];
}

// Source: JMSA 2026 — Dossier de Sponsoring, section VI "Billetterie — Soirée de Gala".
const galaTicketsFr: GalaTicket[] = [
  {
    id: "vip-diamant",
    name: "VIP Diamant",
    price: "250 €",
    benefits: ["Repas gastronomique", "Whisky · Vin · Vin mousseux · Eau", "Table VIP"],
  },
  {
    id: "vip-or",
    name: "VIP Or",
    price: "150 €",
    benefits: ["Repas", "Vin · Jus · Eau"],
  },
  {
    id: "entree-simple",
    name: "Entrée simple",
    price: "100 €",
    benefits: ["Repas", "Eau · Jus"],
  },
];

const galaTicketsEn: GalaTicket[] = [
  {
    id: "vip-diamant",
    name: "VIP Diamond",
    price: "250 €",
    benefits: ["Gourmet meal", "Whisky · Wine · Sparkling wine · Water", "VIP table"],
  },
  {
    id: "vip-or",
    name: "VIP Gold",
    price: "150 €",
    benefits: ["Meal", "Wine · Juice · Water"],
  },
  {
    id: "entree-simple",
    name: "Standard entry",
    price: "100 €",
    benefits: ["Meal", "Water · Juice"],
  },
];

export function getGalaTickets(lang: Lang): GalaTicket[] {
  return lang === "en" ? galaTicketsEn : galaTicketsFr;
}

const groupLabelsFr: Record<SponsoringTier["group"], string> = {
  principal: "Niveaux de partenariat principaux",
  partenaire: "Partenaires & entreprises",
  association: "ONG · ASBL · AISBL · Associations",
};

const groupLabelsEn: Record<SponsoringTier["group"], string> = {
  principal: "Main partnership levels",
  partenaire: "Partners & businesses",
  association: "NGOs · Non-profits · Associations",
};

export function getGroupLabels(lang: Lang): Record<SponsoringTier["group"], string> {
  return lang === "en" ? groupLabelsEn : groupLabelsFr;
}
