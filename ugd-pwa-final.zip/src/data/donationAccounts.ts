import type { Lang } from "../i18n/translations";

export interface PaymentAccount {
  id: string;
  label: string;
  value: string;
  /** true once the association has confirmed the real number/IBAN to publish */
  isPlaceholder: boolean;
}

// Real contact details confirmed across the association's official documents.
export const paypalAccount: PaymentAccount = {
  id: "paypal",
  label: "PayPal",
  value: "liguedesassociationsmondiale@gmail.com",
  isPlaceholder: false,
};

const PLACEHOLDER_FR = "À COMMUNIQUER PAR L'ASSOCIATION";
const PLACEHOLDER_EN = "TO BE PROVIDED BY THE ASSOCIATION";

function placeholder(lang: Lang): string {
  return lang === "en" ? PLACEHOLDER_EN : PLACEHOLDER_FR;
}

export interface BankAccountInfo {
  bankName: string;
  iban: PaymentAccount;
  bic: PaymentAccount;
  accountHolder: string;
}

// IBAN/BIC were not provided in the source dossiers reviewed for this build.
// Do NOT publish a real-looking account number here — keep the placeholder
// flag until the association supplies the actual bank details, so the
// admin panel (Section 5) can flag anything still unconfirmed.
export function getBankAccount(lang: Lang): BankAccountInfo {
  return {
    bankName: lang === "en" ? "Bank to be confirmed" : "Banque à confirmer",
    iban: {
      id: "iban",
      label: "IBAN",
      value: placeholder(lang),
      isPlaceholder: true,
    },
    bic: {
      id: "bic",
      label: "BIC / SWIFT",
      value: placeholder(lang),
      isPlaceholder: true,
    },
    accountHolder: "AISBL UN GESTE DIVIN",
  };
}

// Kept as the original seed data only — the *live* Mobile Money provider
// list is now admin-managed (see cmsService.ts's DEFAULT_MOBILE_MONEY /
// BankOverrides.mobileMoneyProviders, edited via BankAccountsPanel.tsx).
// Nothing else in the app reads getMobileMoneyProviders() any more.
export interface MobileMoneyProvider {
  id: string;
  name: string;
  color: string;
  account: PaymentAccount;
}

// Providers listed in the specification (TMoney, Flooz, Orange Money, MTN).
// Numbers are placeholders pending confirmation from the association —
// swap `value` and set `isPlaceholder: false` once confirmed.
export function getMobileMoneyProviders(lang: Lang): MobileMoneyProvider[] {
  const labelPrefix = lang === "en" ? "Number" : "Numéro";
  const value = placeholder(lang);
  return [
    {
      id: "tmoney",
      name: "TMoney",
      color: "#F59E0B",
      account: { id: "tmoney-number", label: `${labelPrefix} TMoney`, value, isPlaceholder: true },
    },
    {
      id: "flooz",
      name: "Flooz",
      color: "#EF4444",
      account: { id: "flooz-number", label: `${labelPrefix} Flooz`, value, isPlaceholder: true },
    },
    {
      id: "orange-money",
      name: "Orange Money",
      color: "#EA580C",
      account: { id: "orange-number", label: `${labelPrefix} Orange Money`, value, isPlaceholder: true },
    },
    {
      id: "mtn",
      name: "MTN Mobile Money",
      color: "#B89B55",
      account: { id: "mtn-number", label: `${labelPrefix} MTN MoMo`, value, isPlaceholder: true },
    },
  ];
}

// Kept for any code still importing the static (French) defaults directly.
export const bankAccount = getBankAccount("fr");
export const mobileMoneyProviders = getMobileMoneyProviders("fr");

export const contact = {
  phone: "+32 472 28 50 39",
  email: "internationaleungestedivin@gmail.com",
  site: "www.ungestedivin.org",
};
