import { useEffect, useLayoutEffect, useMemo, useRef, useState, type TouchEvent } from "react";
import { LanguageProvider, useLanguage } from "./i18n/LanguageContext";
import Navbar, { type NavTab } from "./components/Navbar";
import TopTabBar from "./components/TopTabBar";
import SectionCard from "./components/SectionCard";
import CustomSpacePanel from "./components/CustomSpacePanel";
import WhatsAppButton from "./components/WhatsAppButton";
import PWAInstallBanner from "./components/PWAInstallBanner";
import HeroSection from "./components/HeroSection";
import FounderProfile from "./components/FounderProfile";
import JMSAHub from "./components/JMSAHub";
import DonationsSection from "./components/DonationsSection";
import MissionsTransparency from "./components/MissionsTransparency";
import MediaLibrary from "./components/MediaLibrary";
import RegistrationLanding from "./components/RegistrationLanding";
import Footer from "./components/Footer";
import { initSyncManager, subscribeSyncStatus, type SyncStatus } from "./services/syncService";
import { requestBilletterie } from "./services/navIntent";
import {
  DEFAULT_SPACES,
  DEFAULT_JMSA_CONFIG,
  isJmsaAutoHidden,
  refreshSiteConfigFromServer,
  subscribeJmsaConfig,
  subscribeSpaces,
  type JmsaConfig,
  type Space,
} from "./services/cmsService";

// Translation key for each of the 7 system spaces (the 3 singleton tabs —
// Accueil/Fondatrice/Contact — plus the 4 built-in modules), used only
// while the admin hasn't renamed the tab away from its shipped default
// (see resolveSpaceLabel below) — an untouched title follows the language
// switcher automatically. Once renamed (or for a free-form "custom"
// space), the tab instead uses the admin-entered title/titleEn pair.
const SYSTEM_TAB_KEYS: Record<string, string> = {
  accueil: "nav.home",
  fondatrice: "nav.founder",
  contact: "nav.contact",
  "jmsa-2026": "nav.jmsa",
  dons: "nav.donate",
  missions: "nav.missions",
  mediatheque: "nav.media",
};

function resolveSpaceLabel(space: Space, t: (key: string) => string, lang: "fr" | "en"): string {
  const defaultTitle = DEFAULT_SPACES.find((d) => d.id === space.id)?.title;
  const key = SYSTEM_TAB_KEYS[space.id];
  if (key && space.title === defaultTitle) {
    return t(key);
  }
  // Admin has renamed this tab (or it's a free-form "custom" space): use
  // the English title if the admin filled one in, otherwise fall back to
  // the French one so nothing goes blank for an untranslated tab.
  if (lang === "en" && space.titleEn && space.titleEn.trim()) return space.titleEn;
  return space.title;
}

// Module registry keyed by id — the 4 built-in bespoke "espaces". Only
// renders for spaces the admin has enabled (see `visibleSpaces` below).
interface ModuleRenderProps {
  onOpenRegistration: () => void;
}
const MODULES: Record<
  string,
  { accent: "ocean" | "emerald" | "gold"; render: (props: ModuleRenderProps) => JSX.Element }
> = {
  "jmsa-2026": { accent: "ocean", render: ({ onOpenRegistration }) => (
    <JMSAHub onOpenRegistration={onOpenRegistration} />
  ) },
  dons: { accent: "emerald", render: () => <DonationsSection /> },
  missions: { accent: "ocean", render: () => <MissionsTransparency /> },
  mediatheque: { accent: "gold", render: () => <MediaLibrary /> },
};

const REGISTRATION_PARAM = "inscription";

function AppShell() {
  const { t, lang } = useLanguage();
  const [syncStatus, setSyncStatus] = useState<SyncStatus | null>(null);
  const [spaces, setSpaces] = useState<Space[]>(DEFAULT_SPACES);
  const [jmsaConfig, setJmsaConfig] = useState<JmsaConfig>(DEFAULT_JMSA_CONFIG);
  const [activeTab, setActiveTab] = useState<string>("accueil");
  const [slideDir, setSlideDir] = useState<"left" | "right" | null>(null);
  const touchState = useRef<{ x: number; y: number; time: number; ignore: boolean } | null>(null);

  // Registration deep-link (Section 4 extension): a URL like
  // `https://<domaine>/?inscription=jmsa2026`, shared as-is on any
  // platform, opens this overlay straight away on load — no navigation
  // through the rest of the app required. Closing it clears the param so a
  // refresh doesn't reopen it, and drops the visitor into the normal shell
  // to browse. If the jmsa-2026 space has since been disabled (event over),
  // RegistrationLanding itself shows a "closed" state instead of the form —
  // the deep link and the nav tab share the exact same gate.
  const [showRegistration, setShowRegistration] = useState(
    () => new URLSearchParams(window.location.search).has(REGISTRATION_PARAM),
  );

  // The deep-link param is removed from the address bar as soon as the
  // overlay has opened (layout effects run before RegistrationLanding
  // pushes its own history entry), so pressing Back to close it lands on a
  // clean URL and a refresh doesn't reopen it. The state is preserved.
  useLayoutEffect(() => {
    const url = new URL(window.location.href);
    if (url.searchParams.has(REGISTRATION_PARAM)) {
      url.searchParams.delete(REGISTRATION_PARAM);
      window.history.replaceState(window.history.state, "", url);
    }
  }, []);

  function closeRegistration() {
    setShowRegistration(false);
  }

  // From the registration landing: the visitor picked the paid day, so take
  // them to the Billetterie in the JMSA space. The short wait lets the
  // overlay remove its own history entry first (hooks/useBackClose.ts) —
  // switching tab before that would make the browser read that "Back" as
  // leaving the new tab.
  function goToTicketsFromLanding() {
    closeRegistration();
    window.setTimeout(() => {
      requestBilletterie();
      selectTab("jmsa-2026");
    }, 120);
  }

  useEffect(() => {
    const teardown = initSyncManager();
    const unsubscribe = subscribeSyncStatus(setSyncStatus);
    return () => {
      teardown();
      unsubscribe();
    };
  }, []);

  // Espaces (Section 5 CMS): every visitor's browser pulls the shared
  // config on load and again on reconnect, so an admin's toggle/rename
  // reaches everyone, not just their own device (see cmsService.ts).
  useEffect(() => {
    const unsubscribe = subscribeSpaces(setSpaces);
    const onOnline = () => void refreshSiteConfigFromServer();
    window.addEventListener("online", onOnline);
    return () => {
      unsubscribe();
      window.removeEventListener("online", onOnline);
    };
  }, []);

  useEffect(() => subscribeJmsaConfig(setJmsaConfig), []);

  // `spaces` now drives the entire nav, in the admin's chosen order —
  // Accueil/Fondatrice/Contact included, see cmsService.ts. Nothing here
  // pins any id to a fixed position any more.
  const visibleSpaces = useMemo(
    () => spaces.filter((s) => s.enabled && !(s.id === "jmsa-2026" && isJmsaAutoHidden(jmsaConfig))),
    [spaces, jmsaConfig],
  );

  // If a space the active tab points to disappears (disabled/deleted), fall
  // back to the first remaining visible tab rather than showing a blank
  // panel — there's no more hardcoded "accueil" to fall back to, since an
  // admin can now delete that tab too.
  useEffect(() => {
    if (!visibleSpaces.some((s) => s.id === activeTab)) {
      const fallback = visibleSpaces[0]?.id;
      if (fallback && fallback !== activeTab) setActiveTab(fallback);
    }
  }, [visibleSpaces, activeTab]);

  const navTabs: NavTab[] = useMemo(
    () => visibleSpaces.map((s) => ({ id: s.id, label: resolveSpaceLabel(s, t, lang) })),
    [visibleSpaces, t, lang],
  );

  // Logo tap (Navbar) jumps to the Accueil tab if it's still there and
  // visible; otherwise the first tab in the admin's current order, so the
  // logo never dead-ends on a tab an admin has hidden or deleted.
  const homeTabId = useMemo(
    () => visibleSpaces.find((s) => s.kind === "home")?.id ?? visibleSpaces[0]?.id,
    [visibleSpaces],
  );

  // Central tab switcher: figures out whether the new tab sits to the
  // right or left of the current one in navTabs, so every way of
  // switching (tap on a nav button, or a swipe) gets the same directional
  // slide animation — not just the swipe gesture itself.
  function selectTab(id: string) {
    if (id === activeTab) return;
    const fromIndex = navTabs.findIndex((tb) => tb.id === activeTab);
    const toIndex = navTabs.findIndex((tb) => tb.id === id);
    setSlideDir(toIndex > fromIndex ? "right" : "left");
    setActiveTab(id);
    // Every tab change is a real browser-history entry, so the phone's Back
    // button (or a computer's) returns to the previous tab instead of
    // leaving the site in one go. Leaving only happens when the visitor
    // presses Back on the very first tab they landed on — their choice.
    window.history.pushState({ ugdTab: id }, "");
  }

  // Latest values for the popstate listener below, which is registered once.
  const activeTabRef = useRef(activeTab);
  activeTabRef.current = activeTab;
  const navTabsRef = useRef(navTabs);
  navTabsRef.current = navTabs;
  const homeTabRef = useRef(homeTabId);
  homeTabRef.current = homeTabId;

  useEffect(() => {
    // Tag the entry the visitor landed on, so Back can return to it.
    if (!window.history.state?.ugdTab) {
      window.history.replaceState({ ...(window.history.state ?? {}), ugdTab: activeTabRef.current }, "");
    }

    function onPopState(e: PopStateEvent) {
      const state = e.state as { ugdTab?: string; __overlay?: number } | null;
      // An overlay (photo viewer, registration…) owns this entry — it closes
      // itself, see hooks/useBackClose.ts. The tab doesn't change.
      if (state?.__overlay) return;
      const targetId = state?.ugdTab ?? homeTabRef.current;
      if (!targetId || targetId === activeTabRef.current) return;
      const tabsNow = navTabsRef.current;
      const fromIndex = tabsNow.findIndex((tb) => tb.id === activeTabRef.current);
      const toIndex = tabsNow.findIndex((tb) => tb.id === targetId);
      setSlideDir(toIndex > fromIndex ? "right" : "left");
      setActiveTab(targetId);
    }
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);

  // Swipe-to-switch on the content area: a plain threshold-based gesture
  // (not a drag-follow), so it works with the existing "one panel mounted
  // at a time" structure without any extra complexity or risk. Elements
  // that need their own horizontal scrolling (e.g. the JMSA flyer strip)
  // opt out via `data-swipe-ignore` so a photo swipe never accidentally
  // changes the active tab.
  function onTouchStart(e: TouchEvent) {
    if (e.touches.length !== 1) {
      touchState.current = null;
      return;
    }
    const target = e.target as HTMLElement;
    const ignore = Boolean(target.closest("[data-swipe-ignore]"));
    const touch = e.touches[0];
    touchState.current = { x: touch.clientX, y: touch.clientY, time: Date.now(), ignore };
  }

  function onTouchEnd(e: TouchEvent) {
    const start = touchState.current;
    touchState.current = null;
    if (!start || start.ignore) return;

    const touch = e.changedTouches[0];
    if (!touch) return;
    const deltaX = touch.clientX - start.x;
    const deltaY = touch.clientY - start.y;
    const elapsed = Date.now() - start.time;

    const HORIZONTAL_THRESHOLD = 60; // px
    const MAX_DURATION = 600; // ms — ignore slow drags
    const isClearlyHorizontal = Math.abs(deltaX) > Math.abs(deltaY) * 1.5;

    if (
      Math.abs(deltaX) < HORIZONTAL_THRESHOLD ||
      !isClearlyHorizontal ||
      elapsed > MAX_DURATION
    ) {
      return;
    }

    const currentIndex = navTabs.findIndex((tb) => tb.id === activeTab);
    const nextIndex = deltaX < 0 ? currentIndex + 1 : currentIndex - 1;
    if (nextIndex < 0 || nextIndex >= navTabs.length) return; // clamp at edges, no wrap
    selectTab(navTabs[nextIndex].id);
  }

  const activeSpace = visibleSpaces.find((s) => s.id === activeTab) ?? null;

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-slate-light">
      <Navbar tabs={navTabs} activeTab={activeTab} onSelectTab={selectTab} homeTabId={homeTabId} />

      {/*
        Mobile/tablet tab bar, moved to the top of the page under the
        header (institutional-site style, e.g. un.org, who.int) — the
        client does not want tabs pinned at the bottom of the screen.
        Hidden on large screens, where Navbar already shows the tabs
        inline in the header row itself.
      */}
      <div className="lg:hidden flex-none">
        <TopTabBar tabs={navTabs} activeTab={activeTab} onSelectTab={selectTab} />
      </div>

      {/*
        True tab system: only the active "espace" is mounted here. Switching
        tabs (via the sliding top tab bar, or the header on large screens)
        swaps this single panel instantly — it never stacks all sections
        one after another, so there is no long page to scroll through.
        This region is the only part of the shell that can scroll
        internally, and only if that one panel's own content is taller
        than the available space (e.g. a long media gallery) — header and
        tab bar stay put; the footer scrolls along with each panel's
        content.
      */}
      <main
        className="mx-auto flex w-full max-w-2xl lg:max-w-5xl flex-1 flex-col overflow-y-auto px-3 py-5 lg:px-8 lg:py-10"
        onTouchStart={onTouchStart}
        onTouchEnd={onTouchEnd}
      >
        <div
          key={activeTab}
          className={`flex flex-col gap-4 lg:gap-8 ${
            slideDir === "right" ? "tab-panel-slide-right" : slideDir === "left" ? "tab-panel-slide-left" : ""
          }`}
        >
          {activeSpace && activeSpace.kind === "home" && <HeroSection />}

          {activeSpace && activeSpace.kind === "founder" && (
            <SectionCard title={resolveSpaceLabel(activeSpace, t, lang)} id={activeSpace.id} accent="gold">
              <FounderProfile />
            </SectionCard>
          )}

          {activeSpace && activeSpace.kind === "module" && MODULES[activeSpace.id] && (
            <SectionCard title={resolveSpaceLabel(activeSpace, t, lang)} id={activeSpace.id} accent={MODULES[activeSpace.id].accent}>
              {MODULES[activeSpace.id].render({ onOpenRegistration: () => setShowRegistration(true) })}
            </SectionCard>
          )}

          {activeSpace && activeSpace.kind === "custom" && (
            <SectionCard title={resolveSpaceLabel(activeSpace, t, lang)} id={activeSpace.id} accent="gold">
              <CustomSpacePanel space={activeSpace} />
            </SectionCard>
          )}

          {activeSpace && activeSpace.kind === "contact" && (
            <SectionCard title={resolveSpaceLabel(activeSpace, t, lang)} id={activeSpace.id} accent="gold">
              <p className="text-sm text-charcoal/80 leading-relaxed">
                +32 472 28 50 39 · internationaleungestedivin@gmail.com
                <br />
                www.ungestedivin.org · {t("app.contactAddress")}
              </p>
            </SectionCard>
          )}

          {syncStatus && syncStatus.pending > 0 && (
            <div className="rounded-card border border-gold-warm/40 bg-gold-warm/10 px-4 py-3 text-sm text-charcoal">
              {syncStatus.pending} {t("app.syncPending")}{" "}
              {syncStatus.isSyncing ? t("app.syncing") : t("app.syncWaiting")}
            </div>
          )}

          <Footer />
        </div>
      </main>

      <PWAInstallBanner />
      <WhatsAppButton />

      {showRegistration && <RegistrationLanding onClose={closeRegistration} onGoToTickets={goToTicketsFromLanding} />}
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppShell />
    </LanguageProvider>
  );
}
