import { useState } from "react";
import { useLanguage } from "../i18n/LanguageContext";
import FlyerZoomModal from "./FlyerZoomModal";
import { HOME_GALLERY } from "../data/homeGallery";

/**
 * Association photo strip — home page only.
 *
 * Same tap-to-zoom, horizontally-scrollable thumbnail pattern as the JMSA
 * flyer gallery (see JMSAHub.tsx: same markup, same FlyerZoomModal
 * lightbox with pinch-to-zoom and swipe-through-carousel) — but showing
 * photos of UGD itself rather than the JMSA 2026 summit, so the home
 * page stays free of any JMSA imagery per the client's request.
 */
export default function HomeGallery() {
  const { t } = useLanguage();
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  if (HOME_GALLERY.length === 0) return null;

  return (
    <div className="px-5 lg:px-8 pb-5 lg:pb-6">
      <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-gold-warm">
        {t("hero.galleryTitle")}
      </p>

      {/* Mobile: horizontal swipe strip (unchanged) — better for touch,
          and doesn't need the photo count to fill the row exactly.
          Desktop (lg:): switches to a wrapping grid that fills the full
          width instead of a narrow scrollable strip with empty space
          trailing off to the right. */}
      <div
        className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1 lg:grid lg:grid-cols-[repeat(auto-fill,minmax(110px,1fr))] lg:overflow-visible lg:gap-3 lg:mx-0 lg:px-0"
        data-swipe-ignore
      >
        {HOME_GALLERY.map((image, index) => (
          <button
            key={image.id}
            type="button"
            onClick={() => setOpenIndex(index)}
            className="relative flex-none w-24 lg:w-full overflow-hidden rounded-lg border border-slate-light"
            aria-label={`${t("jmsa.enlarge")} : ${image.alt}`}
          >
            <img src={image.src} alt={image.alt} className="h-32 w-24 lg:h-28 lg:w-full object-cover" />
            <span className="absolute bottom-1 right-1 rounded-full bg-charcoal/70 p-1">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path
                  d="M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14ZM21 21l-4.35-4.35"
                  stroke="white"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              </svg>
            </span>
          </button>
        ))}
      </div>

      {openIndex !== null && (
        <FlyerZoomModal items={HOME_GALLERY} startIndex={openIndex} onClose={() => setOpenIndex(null)} />
      )}
    </div>
  );
}
