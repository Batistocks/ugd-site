import { useEffect, useRef } from "react";
import type { NavTab } from "./Navbar";

/**
 * Premium sliding top tab bar (mobile/tablet).
 *
 * Sits directly under the header, institutional-site style (UN.org,
 * WHO.int) — the client explicitly does not want the tab bar at the
 * bottom of the screen. Exactly one "espace" stays mounted in <main> at
 * a time (see App.tsx) — tapping a tab here swaps it instantly. Stays a
 * horizontally-scrollable ("coulissant") bar so it still works with
 * however many tabs the CMS tab order produces, it just now lives at
 * the top instead of pinned above the mobile safe area at the bottom.
 * Desktop/large screens instead show tabs inline in the header itself
 * (see Navbar.tsx) — this component only renders below `lg`.
 */

const ICONS: Record<string, JSX.Element> = {
  accueil: (
    <path
      d="M4 11.5 12 5l8 6.5M6 10v9h5v-5h2v5h5v-9"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
  ),
  fondatrice: (
    <>
      <circle cx="12" cy="8" r="3.2" stroke="currentColor" strokeWidth="1.5" fill="none" />
      <path
        d="M5.5 19.5c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        fill="none"
      />
    </>
  ),
  "jmsa-2026": (
    <>
      <rect x="4" y="5.5" width="16" height="15" rx="1.5" stroke="currentColor" strokeWidth="1.5" fill="none" />
      <path d="M4 10h16M8 3.5v3M16 3.5v3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </>
  ),
  dons: (
    <>
      <rect x="4" y="10" width="16" height="9" rx="1" stroke="currentColor" strokeWidth="1.5" fill="none" />
      <rect x="3" y="7" width="18" height="4" rx="1" stroke="currentColor" strokeWidth="1.5" fill="none" />
      <path
        d="M12 7v12M8 7c-1.5 0-2.5-1-2.5-2.25S6.5 2.5 8 2.5c1.8 0 3 1.5 4 4.5m0 0c1-3 2.2-4.5 4-4.5 1.5 0 2.5 1 2.5 2.25S17.8 7 16 7"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        fill="none"
      />
    </>
  ),
  missions: (
    <path
      d="M12 3.5 5 6v5.5c0 4.6 3 7.6 7 9 4-1.4 7-4.4 7-9V6l-7-2.5Z M9.5 12l1.8 1.8L15 10"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
  ),
  mediatheque: (
    <>
      <rect x="3.5" y="5" width="17" height="14" rx="1.5" stroke="currentColor" strokeWidth="1.5" fill="none" />
      <circle cx="8.5" cy="10" r="1.25" stroke="currentColor" strokeWidth="1.5" fill="none" />
      <path d="m4 17 4.5-4.5 3 3L16 11l4 4.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
    </>
  ),
  contact: (
    <path
      d="M4 5.5h16v10H8.5L5 19v-3.5H4v-10Z"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
  ),
};

const DEFAULT_ICON = (
  <circle cx="12" cy="12" r="5" stroke="currentColor" strokeWidth="1.5" fill="none" />
);

export default function TopTabBar({
  tabs,
  activeTab,
  onSelectTab,
}: {
  tabs: NavTab[];
  activeTab: string;
  onSelectTab: (id: string) => void;
}) {
  // Keeps the highlighted tab in view inside the horizontally-scrollable
  // strip whenever it changes — including via a content swipe (App.tsx's
  // onTouchEnd), which updates `activeTab` without the user ever tapping
  // a tab button directly. Without this, the underline/highlight does
  // move instantly (it's a plain prop-driven style), but if that tab
  // happens to sit outside the currently visible scroll area, nothing
  // appears to happen until the visitor scrolls the bar themselves.
  const tabRefs = useRef<Record<string, HTMLButtonElement | null>>({});

  useEffect(() => {
    tabRefs.current[activeTab]?.scrollIntoView({
      behavior: "smooth",
      inline: "center",
      block: "nearest",
    });
  }, [activeTab]);

  return (
    <nav
      aria-label="Navigation principale"
      className="relative z-30 flex-none bg-ocean-deep shadow-[0_2px_10px_rgba(18,59,93,0.15)]"
    >
      <ul
        role="tablist"
        aria-label="Onglets"
        className="scrollbar-hide flex items-stretch gap-1 overflow-x-auto px-2 py-1.5"
        style={{
          height: "var(--tabbar-height)",
          scrollBehavior: "smooth",
          // Pure-CSS "more content" affordance: a thin gold sliver shows
          // at whichever edge still has hidden tabs, and disappears on
          // its own once you've scrolled all the way there — no JS
          // scroll-position tracking needed (two backgrounds scroll
          // with the content and cover the edge shadow near the ends).
          backgroundImage:
            "linear-gradient(to right, var(--color-primary) 24px, rgba(18,59,93,0)), " +
            "linear-gradient(to left, var(--color-primary) 24px, rgba(18,59,93,0)), " +
            "linear-gradient(to right, rgba(184,155,85,.85), rgba(184,155,85,0)), " +
            "linear-gradient(to left, rgba(184,155,85,.85), rgba(184,155,85,0))",
          backgroundRepeat: "no-repeat",
          backgroundColor: "var(--color-primary)",
          backgroundSize: "32px 100%, 32px 100%, 8px 100%, 8px 100%",
          backgroundPosition: "0 0, 100% 0, 0 0, 100% 0",
          backgroundAttachment: "local, local, scroll, scroll",
        }}
      >
        {tabs.map((tab) => {
          const isActive = tab.id === activeTab;
          return (
            <li key={tab.id} className="flex-none snap-center">
              <button
                type="button"
                ref={(el) => {
                  tabRefs.current[tab.id] = el;
                }}
                role="tab"
                aria-selected={isActive}
                onClick={() => onSelectTab(tab.id)}
                className={`flex h-full min-w-[72px] flex-col items-center justify-center gap-1 overflow-hidden rounded px-3.5 border-b-2 transition-colors ${
                  isActive
                    ? "border-emerald text-white"
                    : "border-transparent text-white/60 hover:text-white/85"
                }`}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true">
                  {ICONS[tab.id] ?? DEFAULT_ICON}
                </svg>
                <span
                  className={`whitespace-nowrap text-[10.5px] leading-none ${
                    isActive ? "font-semibold" : "font-normal"
                  }`}
                >
                  {tab.label}
                </span>
              </button>
            </li>
          );
        })}
      </ul>

      {/* thin hairline under the bar, separating it from the scrollable
          content below — emerald, matching the header's own bottom line
          (Navbar.tsx) now that both follow the same "after the royal blue
          bar comes an emerald line" rule instead of gold. */}
      <div className="h-px w-full bg-emerald/60" />
    </nav>
  );
}
