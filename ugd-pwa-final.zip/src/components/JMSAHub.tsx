import { useEffect, useRef, useState } from "react";
import { getAgenda, getEventInfo, getSpeakers as getStaticSpeakers, type Speaker } from "../data/jmsaProgramme";
import { getSponsoringTiers, getGalaTickets, getGroupLabels } from "../data/sponsoringTiers";
import FlyerZoomModal from "./FlyerZoomModal";
import PdfLinkRow from "./PdfLinkRow";
import PassRequestForm from "./PassRequestForm";
import PaymentFlowBlock from "./PaymentFlowBlock";
import {
  DEFAULT_FLYERS,
  subscribeFlyers,
  subscribeJmsaConfig,
  subscribeSpeakers,
  subscribeDocuments,
  DEFAULT_JMSA_CONFIG,
  type FlyerItem,
  type JmsaConfig,
  type BilingualSpeaker,
} from "../services/cmsService";
import { useLanguage } from "../i18n/LanguageContext";
import { consumeBilletterieRequest, onBilletterieRequest } from "../services/navIntent";

/** "2 000 €" -> "2000", for pre-filling the proof form's numeric amount field. */
function priceToAmount(price: string): string {
  return price.replace(/[^\d]/g, "");
}

/** Official JMSA 2026 flyer shown at the top of the Inscription tab. */
const INSCRIPTION_FLYER = "/flyers/jmsa-flyer-inscription.jpg";

type SubTab = "programme" | "sponsoring" | "inscription";

/**
 * Espace 2 : Hub Sommet JMSA 2026.
 *
 * Tout ce qui concerne JMSA vit ici, et seulement ici, réparti en 3
 * sous-onglets :
 *  - Programme : galerie de flyers, agenda (vendredi/samedi), intervenants.
 *  - Offres de Sponsoring : tiers VIP + preuve de paiement + dossier PDF.
 *  - Inscription : flyer officiel + présentation de l'événement,
 *    billetterie gala, demande de pass — tout ce qui était auparavant
 *    dans le sous-onglet "Événements" de Missions & Transparence.
 */
export default function JMSAHub(_props: { onOpenRegistration?: () => void } = {}) {
  const { lang, t } = useLanguage();
  const agenda = getAgenda(lang);
  const staticEventInfo = getEventInfo(lang);
  const staticSpeakers = getStaticSpeakers(lang);
  const sponsoringTiers = getSponsoringTiers(lang);
  const galaTickets = getGalaTickets(lang);
  const groupLabels = getGroupLabels(lang);

  const [subTab, setSubTab] = useState<SubTab>("programme");
  const [activeDay, setActiveDay] = useState<(typeof agenda)[number]["key"]>("vendredi");
  // Speaker photo lightbox — single image, no carousel (see FlyerZoomModal.tsx).
  const [openPhoto, setOpenPhoto] = useState<{ src: string; alt: string } | null>(null);
  // Flyer gallery lightbox — carousel: index into `flyers` so opening any
  // one flyer lets the admin/visitor swipe through all of them.
  const [openFlyerIndex, setOpenFlyerIndex] = useState<number | null>(null);
  const [flyers, setFlyers] = useState<FlyerItem[]>(DEFAULT_FLYERS);
  const [jmsaConfig, setJmsaConfig] = useState<JmsaConfig>(DEFAULT_JMSA_CONFIG);
  const [cmsSpeakers, setCmsSpeakers] = useState<BilingualSpeaker[]>([]);
  const [sponsoringPdf, setSponsoringPdf] = useState("");
  const [selectedTierId, setSelectedTierId] = useState<string | null>(null);
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  const ticketsRef = useRef<HTMLDivElement>(null);
  const currentDay = agenda.find((d) => d.key === activeDay)!;
  const selectedTicket = galaTickets.find((tk) => tk.id === selectedTicketId) ?? null;

  // Header particulars (title/dates/location/theme) come from the shared,
  // admin-editable JMSA config (Section 5 — JmsaConfigPanel.tsx) rather than
  // the static data file, so renaming/re-dating the event for a future
  // edition doesn't need a code change. The agenda and sponsoring/gala-ticket
  // data below still stay on the static file for now (Section 5 follow-up,
  // out of scope of this pass — see README-BACKEND.md); speakers moved to
  // the CMS below.
  const eventInfo = { ...staticEventInfo, ...jmsaConfig, title: jmsaConfig.eventName };

  // Speakers (Intervenants) — Section 5 SpeakersPanel.tsx. Falls back to
  // the static bilingual list (jmsaProgramme.ts) whenever nothing has been
  // configured yet in the admin panel, so a brand-new deploy shows the
  // exact same speakers as before (no visual regression).
  const speakers: Speaker[] =
    cmsSpeakers.length > 0
      ? cmsSpeakers.map((s) => ({ ...s[lang], photo: s.photo }))
      : staticSpeakers;

  // Flyer & Media Manager (Section 5) — the gallery below reflects
  // whatever the admin panel currently has configured, live.
  // "Take me to the Billetterie": used by the registration form when the paid
  // day is picked (here, or from the deep-link landing via navIntent.ts).
  // Opens the Inscription sub-tab, then scrolls to the gala tickets once
  // they are on screen.
  function goToBilletterie() {
    setSubTab("inscription");
    requestAnimationFrame(() =>
      requestAnimationFrame(() => {
        const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        ticketsRef.current?.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
      }),
    );
  }
  useEffect(() => {
    if (consumeBilletterieRequest()) goToBilletterie();
    return onBilletterieRequest(() => {
      consumeBilletterieRequest();
      goToBilletterie();
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => subscribeFlyers(setFlyers), []);
  useEffect(() => subscribeJmsaConfig(setJmsaConfig), []);
  useEffect(() => subscribeSpeakers(setCmsSpeakers), []);
  useEffect(
    () =>
      subscribeDocuments((docs) => {
        const doc = docs.find((d) => d.id === "jmsa-sponsoring" && d.enabled);
        setSponsoringPdf(doc?.src ?? "");
      }),
    [],
  );

  const groups: (keyof typeof groupLabels)[] = ["principal", "partenaire", "association"];

  const tabs: { id: SubTab; label: string }[] = [
    { id: "programme", label: t("jmsa.tabProgramme") },
    { id: "sponsoring", label: t("jmsa.tabSponsoring") },
    { id: "inscription", label: t("jmsa.tabInscription") },
  ];

  return (
    <div className="flex flex-col gap-4">
      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-gold-warm">
          {eventInfo.dateRange} · {eventInfo.location}
        </p>
        <p className="mt-1 text-sm text-charcoal/80 leading-relaxed">{eventInfo.theme}</p>
      </div>

      <div role="tablist" className="flex border-b border-slate-light">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            role="tab"
            aria-selected={subTab === tab.id}
            onClick={() => setSubTab(tab.id)}
            className={`flex-1 border-b-2 py-2 text-[11px] font-semibold uppercase tracking-wide transition-colors ${
              subTab === tab.id
                ? "border-gold text-ocean-deep"
                : "border-transparent text-charcoal/45 hover:text-charcoal/70"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {subTab === "programme" && (
        <div className="flex flex-col gap-4">
          {/* Flyer gallery */}
          <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1" data-swipe-ignore>
            {flyers.map((flyer, flyerIndex) => (
              <button
                key={flyer.id}
                type="button"
                onClick={() => setOpenFlyerIndex(flyerIndex)}
                className="relative flex-none w-24 overflow-hidden rounded-lg border border-slate-light"
                aria-label={`${t("jmsa.enlarge")} : ${flyer.alt}`}
              >
                <img src={flyer.src} alt={flyer.alt} className="h-32 w-24 object-cover" />
                <span className="absolute bottom-1 right-1 rounded-full bg-charcoal/70 p-1">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path
                      d="M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14ZM21 21l-4.35-4.35"
                      stroke="white"
                      strokeWidth="2"
                      strokeLinecap="round"
                    />
                  </svg>
                </span>
              </button>
            ))}
          </div>

          {/* Agenda tabs */}
          <div>
            <div role="tablist" className="flex border-b border-slate-light">
              {agenda.map((day) => (
                <button
                  key={day.key}
                  role="tab"
                  aria-selected={activeDay === day.key}
                  onClick={() => setActiveDay(day.key)}
                  className={`flex-1 border-b-2 py-2 text-[11px] font-semibold uppercase tracking-wide transition-colors ${
                    activeDay === day.key
                      ? "border-gold text-ocean-deep"
                      : "border-transparent text-charcoal/45 hover:text-charcoal/70"
                  }`}
                >
                  {day.key === "vendredi" ? t("jmsa.friday") : t("jmsa.saturday")}
                </button>
              ))}
            </div>

            <p className="mt-2 text-xs text-charcoal/50">{currentDay.hoursLabel}</p>
            <ol className="mt-2 flex flex-col gap-2">
              {currentDay.items.map((item) => (
                <li key={item.time} className="flex gap-3 text-sm">
                  <span className="flex-none w-24 font-semibold text-ocean-deep">{item.time}</span>
                  <span className="text-charcoal/80">{item.label}</span>
                </li>
              ))}
            </ol>
          </div>

          {/* Speakers */}
          <div>
            <h3 className="font-display text-sm text-charcoal mb-2">{t("jmsa.speakersTitle")}</h3>
            <div className="flex flex-col gap-2">
              {speakers.map((speaker) => (
                <button
                  key={speaker.name}
                  type="button"
                  onClick={() => setOpenPhoto({ src: speaker.photo, alt: speaker.name })}
                  className="flex items-center gap-3 rounded-lg border border-slate-light p-2 text-left"
                >
                  <img
                    src={speaker.photo}
                    alt=""
                    aria-hidden="true"
                    className="h-12 w-12 flex-none rounded-full object-cover object-top"
                  />
                  <span className="min-w-0">
                    <span className="block text-sm font-semibold text-charcoal truncate">{speaker.name}</span>
                    <span className="block text-xs text-charcoal/60 leading-snug">{speaker.role}</span>
                    {speaker.badge && (
                      <span className="mt-1 inline-block rounded bg-gold-warm/15 px-2 py-0.5 text-[11px] font-semibold text-gold-warm">
                        {speaker.badge}
                      </span>
                    )}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {subTab === "sponsoring" && (
        <div className="flex flex-col gap-4">
          <div>
            <h3 className="font-display text-sm text-charcoal mb-2">{t("jmsa.sponsoringTitle")}</h3>
            <div className="flex flex-col gap-4">
              {groups.map((group) => (
                <div key={group}>
                  <p className="text-xs font-semibold uppercase tracking-wide text-charcoal/50 mb-1.5">
                    {groupLabels[group]}
                  </p>
                  <div className="flex flex-col gap-2">
                    {sponsoringTiers
                      .filter((tier) => tier.group === group)
                      .map((tier) => {
                        const isSelected = tier.id === selectedTierId;
                        return (
                          <div
                            key={tier.id}
                            className={`rounded-lg border p-3 transition-colors ${
                              isSelected ? "border-ocean-deep bg-ocean-deep/5" : "border-slate-light"
                            }`}
                          >
                            <div className="flex items-baseline justify-between">
                              <span className="text-sm font-semibold text-charcoal">{tier.name}</span>
                              <span className="text-sm font-semibold text-ocean-deep">{tier.price}</span>
                            </div>
                            <ul className="mt-1.5 flex flex-col gap-0.5">
                              {tier.benefits.map((benefit) => (
                                <li key={benefit} className="text-xs text-charcoal/70 leading-snug">
                                  ✓ {benefit}
                                </li>
                              ))}
                            </ul>
                            <button
                              type="button"
                              onClick={() => setSelectedTierId(isSelected ? null : tier.id)}
                              className={`btn-sheen mt-2.5 w-full rounded px-3 py-2 text-xs font-semibold transition-colors ${
                                isSelected
                                  ? "bg-slate-light text-charcoal/60"
                                  : "bg-emerald text-white shadow-emeraldGlow"
                              }`}
                            >
                              {isSelected ? t("jmsa.cancelSelection") : `${t("jmsa.sponsorThisTier")} ${tier.price}`}
                            </button>

                            {/* Opens right here, under the tier just chosen:
                                the sheet to fill in is on screen at once —
                                no scrolling down past the other tiers. */}
                            {isSelected && (
                              <PaymentFlowBlock
                                key={tier.id}
                                summary={
                                  <>
                                    {t("jmsa.youAreSponsoring")} <span className="text-ocean-deep">{tier.name}</span> —{" "}
                                    {tier.price}
                                  </>
                                }
                                intro={t("jmsa.fillSheetSponsor")}
                                presetAmount={priceToAmount(tier.price)}
                                presetContext={`${t("jmsa.sponsoringContext")} ${tier.name}`}
                                referencePrefix="SPO26"
                                whatsapp={{ kind: "sponsoring", itemName: tier.name }}
                              />
                            )}
                          </div>
                        );
                      })}
                  </div>
                </div>
              ))}
            </div>

          </div>

          {sponsoringPdf && <PdfLinkRow href={sponsoringPdf} label={t("jmsa.sponsoringDossier")} />}
        </div>
      )}

      {subTab === "inscription" && (
        <div className="flex flex-col gap-4">
          {/* Présentation de l'événement + appel à inscription — anciennement
              le sous-onglet "Événements" de Missions & Transparence. */}
          <div className="overflow-hidden rounded-card border border-slate-light bg-white">
            <button
              type="button"
              onClick={() => setOpenPhoto({ src: INSCRIPTION_FLYER, alt: eventInfo.title })}
              className="relative block w-full"
              aria-label={`${t("jmsa.enlarge")} : ${eventInfo.title}`}
            >
              <img
                src={INSCRIPTION_FLYER}
                alt={eventInfo.title}
                className="block h-auto w-full"
              />
              <span className="absolute bottom-2 right-2 rounded-full bg-charcoal/70 p-1.5">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <path
                    d="M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14ZM21 21l-4.35-4.35"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </svg>
              </span>
            </button>
            <div className="p-3.5">
              <p className="text-xs font-semibold uppercase tracking-wide text-gold-warm">
                {eventInfo.dateRange} · {eventInfo.location}
              </p>
              <p className="mt-1 text-sm font-semibold text-charcoal">{eventInfo.title}</p>
              <p className="mt-1 text-xs text-charcoal/70 leading-snug">{eventInfo.theme}</p>
            </div>
          </div>

          {/* Gala tickets */}
          <div ref={ticketsRef} className="scroll-mt-2">
            <h3 className="font-display text-sm text-charcoal mb-2">{t("jmsa.galaTitle")}</h3>
            <div className="grid grid-cols-3 gap-2">
              {galaTickets.map((ticket) => {
                const isSelected = ticket.id === selectedTicketId;
                return (
                  <button
                    key={ticket.id}
                    type="button"
                    onClick={() => setSelectedTicketId(isSelected ? null : ticket.id)}
                    // Light saffron tint on the unselected tiles; text colours unchanged.
                    className={`rounded-lg border p-2.5 text-center transition-colors ${
                      isSelected
                        ? "border-ocean-deep bg-ocean-deep text-white"
                        : "border-gold/50 bg-gold/20 text-charcoal hover:bg-gold/30"
                    }`}
                  >
                    <p className="text-xs font-semibold">{ticket.name}</p>
                    <p
                      className={`text-sm font-semibold mt-0.5 ${
                        isSelected ? "text-white" : "text-ocean-deep"
                      }`}
                    >
                      {ticket.price}
                    </p>
                    <p className={`mt-1 text-[10px] leading-tight ${isSelected ? "text-white/80" : "text-charcoal/50"}`}>
                      {isSelected ? t("jmsa.selected") : t("jmsa.choose")}
                    </p>
                  </button>
                );
              })}
            </div>

            {/* Même parcours que le sponsoring : fiche à remplir tout de suite
                (email ou numéro WhatsApp obligatoire), puis — seulement après
                l'envoi du virement — bouton WhatsApp pour signaler le paiement.
                Le ticket (badge + QR) est envoyé une fois le paiement vérifié. */}
            {selectedTicket && (
              <PaymentFlowBlock
                key={selectedTicket.id}
                summary={
                  <>
                    {t("jmsa.youAreBooking")} <span className="text-ocean-deep">{selectedTicket.name}</span> —{" "}
                    {selectedTicket.price}
                  </>
                }
                intro={t("jmsa.fillSheetTicket")}
                presetAmount={priceToAmount(selectedTicket.price)}
                presetContext={`${t("jmsa.ticketContext")} ${selectedTicket.name}`}
                referencePrefix="GAL26"
                whatsapp={{ kind: "billetterie", itemName: selectedTicket.name }}
              />
            )}
          </div>

          {/* Inscription au sommet — confirmée sur WhatsApp. Pas de badge ici : il ne
              s'obtient que via la Billetterie ci-dessus. */}
          <div className="rounded-card bg-slate-light/60 p-3.5">
            <PassRequestForm onGoToTickets={goToBilletterie} />
          </div>
        </div>
      )}

      {openPhoto && (
        <FlyerZoomModal src={openPhoto.src} alt={openPhoto.alt} onClose={() => setOpenPhoto(null)} />
      )}

      {openFlyerIndex !== null && (
        <FlyerZoomModal
          items={flyers}
          startIndex={openFlyerIndex}
          onClose={() => setOpenFlyerIndex(null)}
        />
      )}
    </div>
  );
}
