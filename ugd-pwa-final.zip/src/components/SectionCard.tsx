import type { ReactNode } from "react";
import { useLanguage } from "../i18n/LanguageContext";

interface SectionCardProps {
  /** e.g. "SOMMET JMSA 2026", "MÉDIATHÈQUE & VIDÉO", "DONS" */
  title: string;
  id?: string;
  accent?: "ocean" | "emerald" | "gold";
  children: ReactNode;
  className?: string;
}

const accentMap: Record<NonNullable<SectionCardProps["accent"]>, string> = {
  ocean: "border-t-ocean-deep",
  emerald: "border-t-emerald",
  gold: "border-t-gold",
};

/**
 * Modular boxed section used throughout the app so every screen reads as
 * a set of distinct, scannable "espaces" rather than one long page.
 * Title style follows the brief's institutional convention:
 * [ ESPACE : SOMMET JMSA 2026 ].
 */
export default function SectionCard({
  title,
  id,
  accent = "ocean",
  children,
  className = "",
}: SectionCardProps) {
  const { t } = useLanguage();
  return (
    <section
      id={id}
      className={`rounded-card bg-white border border-slate-light border-t-[3px] ${accentMap[accent]} ${className}`}
    >
      <header className="px-5 lg:px-8 pt-4 lg:pt-6 pb-3 border-b border-slate-light">
        <h2 className="font-display text-lg lg:text-2xl text-charcoal tracking-tight">
          <span className="text-[11px] font-sans font-semibold uppercase tracking-wide text-gold mr-2 align-middle">
            {t("sectionCard.espace")}
          </span>
          {title}
        </h2>
      </header>
      <div className="px-5 lg:px-8 py-4 lg:py-6">{children}</div>
    </section>
  );
}
