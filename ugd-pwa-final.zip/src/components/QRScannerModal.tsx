import { useEffect, useRef, useState } from "react";
import { getCheckin, putCheckin } from "../services/db";
import { recordAuditEvent } from "../services/auditLog";
import { useLanguage } from "../i18n/LanguageContext";
import {
  checkInRegistrationRemote,
  isBackendConfigured,
  AdminApiError,
} from "../services/registrationsAdminApi";

interface BadgePayload {
  event: string;
  id: string;
  name: string;
}

type Status = "idle" | "scanning" | "unsupported" | "camera-error" | "result";
type ResultKind = "checked-in" | "already-checked-in" | "invalid" | "not-registered" | "not-paid" | "offline-unverified";

/**
 * QR Badge Scanner (`QRScannerModal.tsx`).
 * Section 5: Secret Admin Panel & CMS Management.
 *
 * Reads the QR payload embedded in the badge of a gala ticket —
 * `{ event: "JMSA2026", id, name }`, where `id` is the ticket reference
 * ("GAL26-…"); the badge is created server-side when the admin verifies the
 * payment (netlify/functions/lib/badgePdf.js). Only ticket buyers get a
 * badge. Reading uses the native `BarcodeDetector` API where available, with a manual
 * registration-number fallback for browsers that don't support it yet
 * (notably desktop Safari/Firefox at the time of writing).
 *
 * Check-in verifies against the real, shared list of VERIFIED tickets
 * (function `checkInRegistration`) rather than only guarding against a
 * duplicate scan on this one device — a badge whose reference is unknown
 * shows "not-registered", and a ticket whose payment is not yet validated
 * shows "not-paid", instead of silently succeeding. When offline or the
 * admin's session can't be verified, it falls back to the previous
 * local-only IndexedDB duplicate-scan guard, flagged as unverified.
 */
export default function QRScannerModal({
  actorEmail,
  onClose,
}: {
  actorEmail: string;
  onClose: () => void;
}) {
  const { lang, t } = useLanguage();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [status, setStatus] = useState<Status>("idle");
  const [result, setResult] = useState<{ kind: ResultKind; name?: string; detail?: string } | null>(null);
  const [manualId, setManualId] = useState("");

  useEffect(() => {
    let cancelled = false;
    let intervalId: number | undefined;

    async function start() {
      if (!("BarcodeDetector" in window)) {
        setStatus("unsupported");
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
        setStatus("scanning");

        const detector = new BarcodeDetector({ formats: ["qr_code"] });
        intervalId = window.setInterval(async () => {
          if (!videoRef.current) return;
          try {
            const barcodes = await detector.detect(videoRef.current);
            if (barcodes.length > 0) {
              window.clearInterval(intervalId);
              await handlePayload(barcodes[0].rawValue);
            }
          } catch {
            // transient decode errors are expected between frames — ignore
          }
        }, 400);
      } catch {
        setStatus("camera-error");
      }
    }

    start();

    return () => {
      cancelled = true;
      if (intervalId) window.clearInterval(intervalId);
      streamRef.current?.getTracks().forEach((t) => t.stop());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handlePayload(raw: string) {
    let payload: BadgePayload;
    try {
      payload = JSON.parse(raw);
      if (payload.event !== "JMSA2026" || !payload.id) throw new Error("invalid");
    } catch {
      setResult({ kind: "invalid", detail: raw.slice(0, 80) });
      setStatus("result");
      return;
    }
    await checkIn(payload.id, payload.name);
  }

  async function checkIn(registrationId: string, fullName?: string) {
    // Preferred path: verify against the real shared registration list.
    if (isBackendConfigured() && navigator.onLine) {
      try {
        const data = await checkInRegistrationRemote(registrationId);
        if (data.alreadyCheckedIn) {
          setResult({
            kind: "already-checked-in",
            name: data.fullName ?? fullName,
            detail: t("qrScanner.alreadyCheckedInDetail"),
          });
        } else {
          await recordAuditEvent(actorEmail, "checkin", `${registrationId} — ${data.fullName ?? fullName ?? ""}`);
          setResult({ kind: "checked-in", name: data.fullName ?? fullName });
        }
        setStatus("result");
        return;
      } catch (err) {
        if (err instanceof AdminApiError && err.status === 404) {
          setResult({ kind: "not-registered", detail: registrationId });
          setStatus("result");
          return;
        }
        if (err instanceof AdminApiError && err.status === 402) {
          setResult({ kind: "not-paid", name: fullName, detail: registrationId });
          setStatus("result");
          return;
        }
        // Any other backend error (network blip, 401…) — fall through to
        // the offline-safe local guard below rather than blocking check-in.
      }
    }

    // Fallback: offline or backend unreachable — local duplicate-scan
    // guard only, explicitly flagged as unverified against the real list.
    const existing = await getCheckin(registrationId);
    if (existing) {
      setResult({
        kind: "already-checked-in",
        name: existing.fullName,
        detail: `${t("qrScanner.alreadyCheckedInDetail")} ${new Date(existing.checkedInAt).toLocaleString(lang === "en" ? "en-GB" : "fr-BE")}`,
      });
      setStatus("result");
      return;
    }
    await putCheckin({
      registrationId,
      fullName: fullName ?? registrationId,
      checkedInAt: Date.now(),
      checkedInBy: actorEmail,
    });
    await recordAuditEvent(actorEmail, "checkin-offline", `${registrationId} — ${fullName ?? ""}`);
    setResult({ kind: "offline-unverified", name: fullName ?? registrationId });
    setStatus("result");
  }

  function scanAgain() {
    setResult(null);
    setManualId("");
    setStatus(status === "unsupported" ? "unsupported" : "scanning");
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={t("qrScanner.title")}
      className="fixed inset-0 z-[70] flex flex-col bg-charcoal"
    >
      <div className="flex items-center justify-between px-4 py-3">
        <h2 className="font-display text-sm text-white">{t("qrScanner.title")}</h2>
        <button
          type="button"
          onClick={onClose}
          aria-label={t("qrScanner.close")}
          className="flex h-8 w-8 items-center justify-center rounded-full text-white hover:bg-white/10"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="M5 5l14 14M19 5 5 19" stroke="white" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>
      </div>

      <div className="relative flex flex-1 items-center justify-center overflow-hidden">
        {status === "scanning" && (
          <video ref={videoRef} muted playsInline className="h-full w-full object-cover" />
        )}
        {(status === "scanning" || status === "idle") && (
          <div className="pointer-events-none absolute h-56 w-56 rounded-2xl border-2 border-gold-warm/80" />
        )}

        {status === "unsupported" && (
          <div className="mx-6 rounded-xl bg-white p-4 text-center">
            <p className="text-sm text-charcoal">{t("qrScanner.unsupported")}</p>
          </div>
        )}

        {status === "camera-error" && (
          <div className="mx-6 rounded-xl bg-white p-4 text-center">
            <p className="text-sm text-charcoal">{t("qrScanner.cameraError")}</p>
          </div>
        )}

        {status === "result" && result && (
          <div className="mx-6 rounded-xl bg-white p-5 text-center">
            {result.kind === "checked-in" && (
              <>
                <p className="text-2xl">✅</p>
                <p className="mt-2 font-display text-base text-emerald">{t("qrScanner.checkedIn")}</p>
                <p className="mt-1 text-sm text-charcoal">{result.name}</p>
              </>
            )}
            {result.kind === "already-checked-in" && (
              <>
                <p className="text-2xl">⚠️</p>
                <p className="mt-2 font-display text-base text-gold-warm">{t("qrScanner.alreadyCheckedIn")}</p>
                <p className="mt-1 text-sm text-charcoal">{result.name}</p>
                <p className="mt-1 text-xs text-charcoal/50">{result.detail}</p>
              </>
            )}
            {result.kind === "not-registered" && (
              <>
                <p className="text-2xl">🚫</p>
                <p className="mt-2 font-display text-base text-red-600">{t("qrScanner.notFoundTitle")}</p>
                <p className="mt-1 text-xs text-charcoal/50 break-all">
                  {t("qrScanner.notFoundBody")} {result.detail}
                </p>
              </>
            )}
            {result.kind === "not-paid" && (
              <>
                <p className="text-2xl">⛔</p>
                <p className="mt-2 font-display text-base text-red-600">{t("qrScanner.notPaidTitle")}</p>
                {result.name && <p className="mt-1 text-sm text-charcoal">{result.name}</p>}
                <p className="mt-1 text-xs text-charcoal/50">{t("qrScanner.notPaidBody")}</p>
                <p className="mt-1 text-xs text-charcoal/40 break-all">{result.detail}</p>
              </>
            )}
            {result.kind === "offline-unverified" && (
              <>
                <p className="text-2xl">📶</p>
                <p className="mt-2 font-display text-base text-gold-warm">Pointé (hors ligne, non vérifié)</p>
                <p className="mt-1 text-sm text-charcoal">{result.name}</p>
                <p className="mt-1 text-xs text-charcoal/50">
                  Pas de connexion admin — vérifiez ce billet dans « Dons à vérifier » une fois en ligne.
                </p>
              </>
            )}
            {result.kind === "invalid" && (
              <>
                <p className="text-2xl">❌</p>
                <p className="mt-2 font-display text-base text-red-600">{t("qrScanner.invalidBadge")}</p>
                <p className="mt-1 text-xs text-charcoal/50 break-all">{result.detail}</p>
              </>
            )}
            <button
              type="button"
              onClick={scanAgain}
              className="mt-4 rounded-full bg-ocean-deep px-4 py-2 text-sm font-semibold text-white"
            >
              {t("qrScanner.scanAnother")}
            </button>
          </div>
        )}
      </div>

      {(status === "unsupported" || status === "camera-error") && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (manualId.trim()) void checkIn(manualId.trim());
          }}
          className="flex gap-2 p-4"
        >
          <input
            placeholder={t("qrScanner.manualPlaceholder")}
            value={manualId}
            onChange={(e) => setManualId(e.target.value)}
            className="flex-1 rounded-lg border border-white/20 bg-white/10 px-3 py-2.5 text-sm text-white placeholder:text-white/40 focus:border-gold-warm focus:outline-none"
          />
          <button type="submit" className="flex-none rounded-full bg-gold-warm px-4 py-2.5 text-sm font-semibold text-white">
            {t("qrScanner.validate")}
          </button>
        </form>
      )}
    </div>
  );
}
