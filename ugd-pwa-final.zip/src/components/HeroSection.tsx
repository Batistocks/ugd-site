import { useEffect, useState } from "react";
import { useLanguage } from "../i18n/LanguageContext";
import {
  DEFAULT_DOCUMENTS,
  DEFAULT_IMPACT,
  subscribeDocuments,
  subscribeImpact,
  type DocumentItem,
  type ImpactConfig,
} from "../services/cmsService";
import ImpactCounter from "./ImpactCounter";
import HomeGallery from "./HomeGallery";

// Swap for the real Cloudinary-hosted delivery URL once Section 6
// (Cloudinary integration) is wired up, e.g.:
// https://res.cloudinary.com/<cloud-name>/video/upload/f_auto,q_auto/ugd-presentation.mp4
const VIDEO_SRC = "";
// On purpose an association photo, never a JMSA 2026 flyer/photo/video —
// the home page must stay free of JMSA imagery (see HOME_GALLERY below
// for the full association photo strip).
// Both files below are pre-cropped (no UGD logo watermark) and are used
// only here — on purpose not added to HOME_GALLERY, to avoid showing the
// banner/avatar photos a second time in the scrolling gallery strip.
const VIDEO_POSTER = "/media/presidente-ceremonie-officielle.jpg";
const FOUNDER_PHOTO = "/team/marie-makamgue-parlement-europeen.jpg";
const LOGO_OFFICIAL = "/icons/logo-official.jpg";

/**
 * Espace 1 : Accueil — the first thing visible above the fold.
 *
 * By design this tab never opens on financial content: no campaign goal,
 * no donation figures. It opens on "who UGD is" — the association's
 * identity/mission (Sections 1-2 of the marketing dossier + sponsoring
 * dossier) folded together with the founder's own story, since the two
 * are really one narrative — then the video/presentation and the
 * headline impact numbers. Donations live exclusively in the Dons tab.
 */
export default function HeroSection() {
  const { t } = useLanguage();
  const [impact, setImpact] = useState<ImpactConfig>(DEFAULT_IMPACT);
  const [documents, setDocuments] = useState<DocumentItem[]>(DEFAULT_DOCUMENTS);

  useEffect(() => subscribeImpact(setImpact), []);
  useEffect(() => subscribeDocuments(setDocuments), []);

  // "Découvrez-nous Plus" opens the UGD marketing & presentation PDF (the
  // "ugd-marketing" slot of the Documents admin panel). Hidden if an admin
  // has disabled/deleted that slot, so it never links to nothing.
  const marketingDoc = documents.find((d) => d.kind === "ugd-marketing" && d.enabled && d.src);

  return (
    <div className="flex flex-col gap-4 lg:gap-8">
      {/* Identity banner. Honest note on why this is now the SAME
          single-column layout at every screen size instead of a
          side-by-side desktop split: every attempt to balance a text
          column against a photo column here (centering, fixed aspect
          ratios...) kept leaving empty space somewhere, and there's no
          real browser in this environment to verify a fix visually
          before shipping it. A single stacked column, capped at a
          comfortable reading width on large screens, cannot produce that
          kind of cross-column gap — reliable over clever. Mobile's own
          markup/classes are untouched. */}
      <section className="rounded-card overflow-hidden bg-white border border-slate-light lg:max-w-2xl lg:mx-auto">
        <div className="bg-white text-charcoal border-b border-slate-light">
          <div className="flex items-center gap-4 px-5 lg:px-8 pt-6 pb-5 lg:pb-6">
            <img
              src={LOGO_OFFICIAL}
              alt="UGD — Un Geste Divin"
              className="h-16 w-16 flex-none rounded-lg ring-1 ring-gold/50 object-contain bg-white"
            />
            <div className="min-w-0">
              <p className="font-display font-bold text-xl lg:text-2xl leading-snug text-ocean-deep">{t("hero.tagline")}</p>
              <p className="mt-1 text-[11px] uppercase tracking-wide text-gold-warm font-semibold">
                AISBL · Charleroi, Belgique
              </p>
            </div>
          </div>
          <p className="px-5 lg:px-8 pb-6 text-sm text-charcoal/70 leading-relaxed max-w-content">
            {t("hero.subtitle")}
          </p>
        </div>

        <div className="relative aspect-video bg-charcoal">
          {VIDEO_SRC ? (
            <video
              className="h-full w-full object-cover"
              src={VIDEO_SRC}
              poster={VIDEO_POSTER}
              controls
              playsInline
              preload="metadata"
            />
          ) : (
            // Placeholder until the official presentation video is uploaded
            // via the admin panel's Cloudinary integration (Section 5/6).
            <img
              src={VIDEO_POSTER}
              alt="AISBL Un Geste Divin"
              className="h-full w-full object-cover opacity-95"
            />
          )}
          <div className="absolute bottom-0 left-0 h-1 w-full bg-gold/70" />
        </div>

        <div className="px-5 lg:px-8 pt-4 pb-5 lg:pt-6 lg:pb-6 border-t border-slate-light">
          <div className="grid grid-cols-3 gap-2 lg:gap-6 rounded-card bg-slate-light px-3 py-4">
            <ImpactCounter value={impact.countries} label={t("impact.countries")} />
            <ImpactCounter value={impact.years} label={t("impact.years")} />
            <ImpactCounter value={impact.actions} label={t("impact.actions2024")} />
          </div>
        </div>

        <div className="border-t border-slate-light">
          <HomeGallery />
        </div>
      </section>

      {/* Qui sommes-nous — merged with the founder's story */}
      <section className="rounded-card overflow-hidden bg-white border border-slate-light border-t-[3px] border-t-emerald lg:grid lg:grid-cols-3 lg:items-start">
        <div className="lg:col-span-2">
          <header className="px-5 lg:px-8 pt-4 lg:pt-6 pb-2">
            <p className="text-[11px] font-semibold uppercase tracking-wide text-gold">
              {t("hero.aboutEyebrow")}
            </p>
            <p className="mt-1 font-display text-base lg:text-xl text-charcoal leading-snug">
              {t("hero.aboutLead")}
            </p>
          </header>

          <div className="px-5 lg:px-8 pb-2 flex flex-col gap-3">
            <p className="text-sm text-charcoal/80 leading-relaxed">{t("hero.aboutBody")}</p>
            <p className="text-sm text-charcoal/80 leading-relaxed">{t("hero.aboutBody2")}</p>
          </div>

          {/* Nos valeurs — quiet editorial marks, not colorful chips.
              Symmetric 2x2 grid on mobile (2 per row) rather than a
              flex-wrap, so the last value never sits alone on its own
              ragged line; lg screens keep a single tidy row. */}
          <div className="mx-5 lg:mx-8 mt-2 mb-4 grid grid-cols-2 lg:flex lg:flex-wrap gap-x-5 gap-y-2">
            {[
              { label: t("hero.values.security"), color: "text-ocean-deep" },
              { label: t("hero.values.kindness"), color: "text-emerald-deep" },
              { label: t("hero.values.respect"), color: "text-ocean-deep" },
              { label: t("hero.values.fraternity"), color: "text-emerald-deep" },
            ].map((v) => (
              <span
                key={v.label}
                className={`text-[11px] font-semibold uppercase tracking-wide ${v.color} before:content-['—'] before:mr-1.5 before:text-gold`}
              >
                {v.label}
              </span>
            ))}
          </div>

          {marketingDoc && (
            <a
              href={marketingDoc.src}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-sheen mx-5 lg:mx-8 mb-5 lg:mb-6 flex w-fit items-center gap-2 rounded-full border border-gold bg-gold/25 px-4 py-2 text-sm font-semibold text-ocean-deep"
            >
              {t("hero.discoverMore")}
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </a>
          )}
        </div>

        <div className="mx-5 lg:mx-0 lg:mr-8 mb-5 lg:mb-0 mt-4 lg:mt-6 flex flex-col items-center gap-3 rounded-card bg-slate-light p-4 lg:p-6 text-center">
          <img
            src={FOUNDER_PHOTO}
            alt={t("hero.founderName")}
            className="h-28 w-28 lg:h-32 lg:w-32 flex-none rounded-full object-cover ring-2 ring-gold/60"
          />
          <div className="min-w-0">
            <p className="font-display text-base text-ocean-deep leading-tight">
              {t("hero.founderName")}
            </p>
            <p className="mt-0.5 text-xs font-semibold text-gold">
              {t("hero.founderLabel")} · {t("hero.founderAka")}
            </p>
            <p className="mt-2 text-xs text-charcoal/75 leading-relaxed">
              {t("hero.founderBody")}
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
