import { useEffect, useState } from "react";
import PdfReader from "./PdfReader";
import { subscribeDocuments } from "../services/cmsService";
import { useLanguage } from "../i18n/LanguageContext";

// Personal website of the founder — shown right under "Télécharger le PDF".
const FOUNDER_SITE_URL = "https://marie-makamgue-djembong.up.railway.app/";
const FOUNDER_SITE_LABEL = "marie-makamgue-djembong.up.railway.app";

/**
 * Espace "Fondatrice" — presents the founder's official bio PDF
 * (Marie Nicaise Makamgue Djembong, "Mama Coco") as-is, in a scrollable
 * reading space, with a link to her personal website just below the
 * "Télécharger le PDF" link.
 *
 * The document itself comes from the "Documents" admin panel
 * (DocumentsPanel.tsx / cmsService.ts's documents list, item id
 * "founder") — replaceable, renamable, and even deletable/restorable from
 * there without a new deploy. If that slot is disabled or deleted,
 * PdfReader shows a graceful "no document" state instead of an error.
 */
export default function FounderProfile() {
  const { t } = useLanguage();
  const [src, setSrc] = useState("");

  useEffect(
    () =>
      subscribeDocuments((docs) => {
        const doc = docs.find((d) => d.id === "founder" && d.enabled);
        setSrc(doc?.src ?? "");
      }),
    [],
  );

  return (
    <div className="flex flex-col gap-3">
      <PdfReader src={src} title="Marie Nicaise Makamgue Djembong — Un Geste Divin" />

      {/* Opens the founder's site straight away, in a new tab so the app stays open. */}
      <div className="flex flex-col items-center gap-0.5 text-center text-xs">
        <span className="text-charcoal/60">{t("founder.personalSiteLabel")}</span>
        <a
          href={FOUNDER_SITE_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="break-all font-semibold text-ocean-deep underline"
        >
          {FOUNDER_SITE_LABEL}
        </a>
      </div>
    </div>
  );
}
