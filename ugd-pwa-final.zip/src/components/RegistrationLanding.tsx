import { useEffect, useState } from "react";
import { useLanguage } from "../i18n/LanguageContext";
import { useBackClose } from "../hooks/useBackClose";
import PassRequestForm from "./PassRequestForm";
import { DEFAULT_JMSA_CONFIG, subscribeJmsaConfig, type JmsaConfig } from "../services/cmsService";

const LOGO_OFFICIAL = "/icons/logo-official.jpg";

/**
 * Deep-link registration landing — Section 4 extension.
 *
 * Purpose: a single URL (e.g. `https://<domaine>/?inscription=jmsa2026`)
 * shareable on any platform (WhatsApp, Facebook, SMS…) that opens the app
 * straight onto the registration form, with none of the rest of the JMSA
 * hub (agenda, speakers, sponsoring tiers) in the way. App.tsx detects the
 * `inscription` query param on load and renders this full-screen overlay
 * on top of the normal shell; `onClose` clears the param and drops the
 * visitor into the regular app so they can keep browsing afterwards —
 * available at any time, not just after a successful submission.
 *
 * Event name/dates/location come from the shared, admin-editable JMSA
 * config (see cmsService.ts / JmsaConfigPanel.tsx) rather than a hardcoded
 * data file. If the jmsa-2026 space has been disabled, PassRequestForm
 * itself renders the "closed" message below — this deep link doesn't
 * bypass that gate.
 */
export default function RegistrationLanding({
  onClose,
  onGoToTickets,
}: {
  onClose: () => void;
  /** Paid day picked → close this overlay and open the Billetterie (see App.tsx). */
  onGoToTickets?: () => void;
}) {
  const { t } = useLanguage();
  useBackClose(onClose);
  const [jmsaConfig, setJmsaConfig] = useState<JmsaConfig>(DEFAULT_JMSA_CONFIG);

  useEffect(() => subscribeJmsaConfig(setJmsaConfig), []);

  useEffect(() => {
    document.body.classList.add("drawer-open");
    return () => document.body.classList.remove("drawer-open");
  }, []);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={t("registration.title")}
      className="fixed inset-0 z-[70] flex flex-col overflow-y-auto bg-slate-light"
    >
      <div className="gloss flex-none bg-gradient-to-br from-ocean-deep via-ocean to-emerald-deep px-5 pb-6 pt-[max(1.25rem,env(safe-area-inset-top))] text-white">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <img
              src={LOGO_OFFICIAL}
              alt="UGD — Un Geste Divin"
              className="h-11 w-11 flex-none rounded-full ring-2 ring-white/40 object-cover bg-white"
            />
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-gold-warm">
                {t("registration.eyebrow")}
              </p>
              <p className="font-display text-base leading-snug">{jmsaConfig.eventName}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={t("registration.close")}
            className="flex h-9 w-9 flex-none items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M5 5l14 14M19 5 5 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </button>
        </div>
        <p className="mt-3 text-xs text-white/80">
          {jmsaConfig.dateRange} · {jmsaConfig.location}
        </p>
      </div>

      <div className="mx-auto flex w-full max-w-2xl flex-1 flex-col gap-4 px-4 py-5">
        <p className="text-sm text-charcoal/70 leading-relaxed">{t("registration.subtitle")}</p>

        <div className="gloss rounded-card bg-white p-4 shadow-card">
          <PassRequestForm onGoToTickets={onGoToTickets} />
        </div>

        <button
          type="button"
          onClick={onClose}
          className="mt-1 rounded-full border border-ocean-deep/30 px-4 py-2.5 text-sm font-semibold text-ocean-deep"
        >
          {t("registration.continueSite")}
        </button>
      </div>
    </div>
  );
}
