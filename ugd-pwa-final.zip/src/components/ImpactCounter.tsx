import { useEffect, useRef, useState } from "react";

interface ImpactCounterProps {
  value: number;
  label: string;
  suffix?: string;
}

/**
 * Animates from 0 to `value` once the counter scrolls into view.
 * Respects prefers-reduced-motion by jumping straight to the final value.
 *
 * The value is admin-editable (see ImpactPanel.tsx) and can change after
 * first paint — e.g. the shared config arrives from the server a moment
 * after the defaults were shown. When that happens the counter animates
 * from whatever it currently shows to the new number, rather than staying
 * stuck on the old one.
 */
export default function ImpactCounter({ value, label, suffix = "" }: ImpactCounterProps) {
  const [display, setDisplay] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const visible = useRef(false);
  const displayRef = useRef(0);
  const frame = useRef<number | null>(null);

  function animateTo(target: number) {
    if (frame.current !== null) cancelAnimationFrame(frame.current);
    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const from = displayRef.current;
    if (prefersReducedMotion || from === target) {
      displayRef.current = target;
      setDisplay(target);
      return;
    }
    const duration = 900;
    const start = performance.now();
    function tick(now: number) {
      const progress = Math.min(1, (now - start) / duration);
      const next = Math.round(from + (target - from) * (1 - Math.pow(1 - progress, 3)));
      displayRef.current = next;
      setDisplay(next);
      if (progress < 1) frame.current = requestAnimationFrame(tick);
    }
    frame.current = requestAnimationFrame(tick);
  }

  // Latest target, readable from the observer callback without re-creating it.
  const valueRef = useRef(value);
  valueRef.current = value;

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry.isIntersecting || visible.current) return;
        visible.current = true;
        animateTo(valueRef.current);
      },
      { threshold: 0.4 },
    );
    observer.observe(node);
    return () => {
      observer.disconnect();
      if (frame.current !== null) cancelAnimationFrame(frame.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Value changed after the counter was already revealed.
  useEffect(() => {
    if (visible.current) animateTo(value);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  return (
    <div
      ref={ref}
      // Same saffron "support" for all three counters, gradiented to
      // white toward the top — no corner/watermark icon any more (tried
      // both a visible badge and a subtle watermark; removed per
      // feedback, text-only reads cleaner).
      className="flex min-h-[92px] flex-col items-center justify-center overflow-hidden rounded-card bg-gradient-to-b from-white via-gold/45 to-gold px-2.5 py-3.5 text-center sm:px-3"
    >
      {/* Only the figure is bold — the label underneath stays regular. */}
      <p className="font-display text-2xl font-bold leading-none text-ocean-deep">
        {display.toLocaleString("fr-BE")}
        {suffix}
      </p>
      <p className="mt-1.5 text-[11px] font-normal text-charcoal/75 leading-snug sm:text-xs">{label}</p>
    </div>
  );
}
