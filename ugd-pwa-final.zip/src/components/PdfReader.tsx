import { useEffect, useRef, useState } from "react";
import type { PointerEvent as ReactPointerEvent } from "react";
import * as pdfjsLib from "pdfjs-dist";
import type { PDFDocumentProxy } from "pdfjs-dist";
import "../services/pdfWorker";
// pdf.js's own stylesheet for its text/annotation layers (.textLayer span
// positioning, transparent-but-selectable text, etc.) -- needed for
// renderPdfTextLayer below to look right, not just work.
import "pdfjs-dist/web/pdf_viewer.css";
import { useLanguage } from "../i18n/LanguageContext";
import { renderPdfTextLayer } from "../services/pdfTextLayer";
import PdfPageZoomModal from "./PdfPageZoomModal";

interface PdfReaderProps {
  /** Path/URL to the PDF, served as-is -- never re-encoded or converted. */
  src: string;
  /** Used for the download-fallback filename and aria-labels. */
  title: string;
}

type LoadState = "loading" | "ready" | "error" | "empty";

const SWIPE_THRESHOLD_PX = 50;

/**
 * Reading space for a PDF document -- shown one slide at a time (swipe or
 * the arrow buttons to move between pages), instead of a continuous
 * vertical scroll. The documents used here (founder bio, sponsoring
 * dossiers) are landscape slide decks; stacking every slide full-width in
 * a scrolled list squeezes each one into an unreadably short strip, so a
 * single full-size slide with navigation reads far better, especially on
 * a phone.
 *
 * Tapping the expand button opens the same page in PdfPageZoomModal for
 * pinch-zoom, full-screen reading.
 */
export default function PdfReader({ src, title }: PdfReaderProps) {
  const { t } = useLanguage();
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const textLayerRef = useRef<HTMLDivElement | null>(null);
  const dragStart = useRef<{ x: number; y: number } | null>(null);

  const [pdf, setPdf] = useState<PDFDocumentProxy | null>(null);
  const [numPages, setNumPages] = useState(0);
  const [state, setState] = useState<LoadState>("loading");
  const [containerWidth, setContainerWidth] = useState(0);
  const [index, setIndex] = useState(0);
  const [aspectRatio, setAspectRatio] = useState<number | null>(null); // height / width
  const [rendered, setRendered] = useState(false);
  const [zoomOpen, setZoomOpen] = useState(false);

  const pageNumber = index + 1;

  useEffect(() => {
    let cancelled = false;
    if (!src) {
      // Slot deleted/disabled by the admin — nothing to fetch, and
      // pdf.js's getDocument("") would just reject anyway. Skip straight
      // to a "nothing here yet" state instead of a scary error + a
      // download link that points nowhere.
      setState("empty");
      setPdf(null);
      return;
    }
    setState("loading");
    setIndex(0);
    const loadingTask = pdfjsLib.getDocument(src);
    loadingTask.promise
      .then((doc) => {
        if (cancelled) return;
        setPdf(doc);
        setNumPages(doc.numPages);
        setState("ready");
      })
      .catch(() => {
        if (!cancelled) setState("error");
      });
    return () => {
      cancelled = true;
      loadingTask.destroy();
    };
  }, [src]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const observer = new ResizeObserver((entries) => {
      const width = entries[0]?.contentRect.width;
      if (width) setContainerWidth(Math.floor(width));
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!pdf || !containerWidth) return;
    let cancelled = false;
    setRendered(false);

    (async () => {
      const page = await pdf.getPage(pageNumber);
      if (cancelled) return;
      const baseViewport = page.getViewport({ scale: 1 });
      setAspectRatio(baseViewport.height / baseViewport.width);

      const dpr = Math.min(window.devicePixelRatio || 1, 2.5); // crisp but not wasteful
      const cssScale = containerWidth / baseViewport.width;
      const viewport = page.getViewport({ scale: cssScale * dpr });

      const canvas = canvasRef.current;
      if (!canvas) return;
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      canvas.style.width = `${containerWidth}px`;
      canvas.style.height = `${viewport.height / dpr}px`;

      const context = canvas.getContext("2d");
      if (!context) return;
      await page.render({ canvasContext: context, viewport }).promise;
      if (cancelled) return;
      setRendered(true);

      if (textLayerRef.current) {
        void renderPdfTextLayer(page, textLayerRef.current, cssScale);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [pdf, pageNumber, containerWidth]);

  function goPrev() {
    setIndex((i) => (i - 1 + numPages) % numPages);
  }
  function goNext() {
    setIndex((i) => (i + 1) % numPages);
  }

  function onPointerDown(e: ReactPointerEvent) {
    dragStart.current = { x: e.clientX, y: e.clientY };
  }
  function onPointerUp(e: ReactPointerEvent) {
    const start = dragStart.current;
    dragStart.current = null;
    if (!start || numPages <= 1) return;
    const dx = e.clientX - start.x;
    const dy = e.clientY - start.y;
    if (Math.abs(dx) > SWIPE_THRESHOLD_PX && Math.abs(dx) > Math.abs(dy) * 1.5) {
      if (dx < 0) goNext();
      else goPrev();
    }
  }

  return (
    <div className="flex flex-col gap-3">
      {state === "empty" && (
        <div className="flex flex-col items-center gap-3 rounded-card border border-dashed border-slate-light bg-white px-5 py-10 text-center">
          <p className="text-sm text-charcoal/60">{t("founder.noDocument")}</p>
        </div>
      )}

      {state === "error" && (
        <div className="flex flex-col items-center gap-3 rounded-card border border-slate-light bg-white px-5 py-10 text-center">
          <p className="text-sm text-charcoal/80">{t("founder.loadError")}</p>
          <a
            href={src}
            download
            className="rounded-full bg-ocean-deep px-4 py-2 text-sm font-medium text-white hover:bg-ocean-deep/90"
          >
            {t("founder.download")}
          </a>
        </div>
      )}

      {state !== "error" && state !== "empty" && (
        <div
          ref={containerRef}
          aria-label={title}
          className="w-full rounded-card border border-slate-light bg-slate-light/40 p-2 lg:p-3"
          data-swipe-ignore
        >
          {state === "loading" && (
            <div className="flex items-center justify-center py-16">
              <div className="h-8 w-8 animate-spin rounded-full border-2 border-ocean-deep/30 border-t-ocean-deep" />
            </div>
          )}

          {pdf && containerWidth > 0 && (
            <div
              className="relative mx-auto w-full touch-pan-y select-none overflow-hidden rounded-md bg-white shadow-sm"
              style={aspectRatio ? { aspectRatio: `1 / ${aspectRatio}` } : { minHeight: 160 }}
              onPointerDown={onPointerDown}
              onPointerUp={onPointerUp}
              onPointerCancel={() => (dragStart.current = null)}
            >
              <canvas ref={canvasRef} className="block w-full" />
              <div ref={textLayerRef} className="textLayer" />

              {!rendered && (
                <div className="absolute inset-0 flex items-center justify-center bg-slate-light">
                  <div className="h-6 w-6 animate-spin rounded-full border-2 border-ocean-deep/30 border-t-ocean-deep" />
                </div>
              )}

              <button
                type="button"
                onClick={() => setZoomOpen(true)}
                aria-label={t("founder.expand")}
                className="absolute top-2 right-2 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-charcoal/70 text-white hover:bg-charcoal/90"
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <path
                    d="M9 4H4v5M15 4h5v5M9 20H4v-5M15 20h5v-5"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>

              {numPages > 1 && (
                <>
                  <button
                    type="button"
                    onClick={goPrev}
                    aria-label={t("founder.prevPage")}
                    className="absolute left-2 top-1/2 z-10 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-charcoal/60 text-white hover:bg-charcoal/80"
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                      <path
                        d="M15 5l-7 7 7 7"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </button>
                  <button
                    type="button"
                    onClick={goNext}
                    aria-label={t("founder.nextPage")}
                    className="absolute right-2 top-1/2 z-10 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-charcoal/60 text-white hover:bg-charcoal/80"
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                      <path
                        d="M9 5l7 7-7 7"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </button>
                  <span className="pointer-events-none absolute bottom-2 left-1/2 -translate-x-1/2 rounded-full bg-charcoal/70 px-2.5 py-0.5 text-[11px] font-medium text-white">
                    {pageNumber} / {numPages}
                  </span>
                </>
              )}
            </div>
          )}
        </div>
      )}

      {state === "ready" && (
        <div className="flex flex-none items-center justify-between text-xs text-charcoal/60">
          <span>
            {numPages} {t("founder.pages")}
          </span>
          <a href={src} download className="underline hover:text-charcoal">
            {t("founder.download")}
          </a>
        </div>
      )}

      {pdf && zoomOpen && (
        <PdfPageZoomModal
          pdf={pdf}
          numPages={numPages}
          startPage={pageNumber}
          title={title}
          onClose={() => setZoomOpen(false)}
          downloadHref={src}
        />
      )}
    </div>
  );
}
