import { useEffect, useState } from "react";
import { useClipboard } from "../hooks/useClipboard";
import { paypalAccount } from "../data/donationAccounts";
import type { PaymentAccount } from "../data/donationAccounts";
import { getBankOverrides, isConfirmedValue, subscribeBankOverrides, type BankOverrides } from "../services/cmsService";
import { useLanguage } from "../i18n/LanguageContext";

function CopyRow({ account }: { account: PaymentAccount }) {
  const { copy, copiedId } = useClipboard();
  const { t } = useLanguage();
  const isCopied = copiedId === account.id;

  return (
    <div className="flex items-center justify-between gap-3 rounded-card border border-slate-light px-3 py-2.5">
      <div className="min-w-0">
        <p className="text-xs text-charcoal/50">{account.label}</p>
        <p
          className={`truncate text-sm font-medium ${
            account.isPlaceholder ? "italic text-charcoal/40" : "text-charcoal"
          }`}
        >
          {account.value}
        </p>
      </div>
      <button
        type="button"
        disabled={account.isPlaceholder}
        onClick={() => copy(account.id, account.value)}
        className="btn-sheen flex-none rounded bg-emerald px-3 py-1.5 text-xs font-semibold text-white shadow-emeraldGlow disabled:bg-slate-light disabled:text-charcoal/40 disabled:shadow-none"
      >
        {isCopied ? t("paymentPanel.copied") : t("paymentPanel.copy")}
      </button>
    </div>
  );
}

/**
 * Bank account (IBAN/BIC), Mobile Money (TMoney, Flooz, Orange Money,
 * MTN) and PayPal accounts, each with a one-tap "Copier" action.
 *
 * Extracted out of `DonationsSection.tsx` (Espace 3) so the exact same
 * accounts can also be shown inline under a chosen sponsoring tier in
 * `JMSAHub.tsx` (Espace 2) — a sponsor shouldn't have to hunt down a
 * different section of the app to find out where to send their payment.
 *
 * Bank/mobile-money numbers come from the Bank/Mobile Money Account Editor
 * (Section 5, `admin/panels/BankAccountsPanel.tsx`) via `cmsService` — the
 * "Copier" button unlocks automatically as soon as an admin replaces a
 * placeholder with a confirmed value (see `isConfirmedValue`).
 */
export default function PaymentAccountsPanel() {
  const [bank, setBank] = useState<BankOverrides | null>(null);
  const { lang, t } = useLanguage();

  useEffect(() => {
    getBankOverrides().then(setBank);
    return subscribeBankOverrides(setBank);
  }, []);

  if (!bank) return null;

  const numberPrefix = lang === "en" ? "Number" : "Numéro";

  const ibanAccount: PaymentAccount = {
    id: "iban",
    label: "IBAN",
    value: bank.iban,
    isPlaceholder: !isConfirmedValue(bank.iban),
  };
  const bicAccount: PaymentAccount = {
    id: "bic",
    label: "BIC / SWIFT",
    value: bank.bic,
    isPlaceholder: !isConfirmedValue(bank.bic),
  };

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h3 className="font-display text-sm text-charcoal mb-2">{t("paymentPanel.bankTransfer")}</h3>
        <p className="text-xs text-charcoal/50 mb-2">
          {t("paymentPanel.accountHolder")} {bank.accountHolder}
        </p>
        <div className="flex flex-col gap-2">
          <CopyRow account={ibanAccount} />
          <CopyRow account={bicAccount} />
        </div>
      </div>

      <div>
        <h3 className="font-display text-sm text-charcoal mb-2">{t("paymentPanel.mobileMoney")}</h3>
        <div className="flex flex-col gap-2">
          {bank.mobileMoneyProviders.map((provider) => {
            const value = provider.value;
            const name = lang === "en" && provider.nameEn && provider.nameEn.trim() ? provider.nameEn : provider.name;
            const account: PaymentAccount = {
              id: provider.id,
              label: `${numberPrefix} ${name}`,
              value,
              isPlaceholder: !isConfirmedValue(value),
            };
            return (
              <div key={provider.id} className="flex items-center gap-2">
                <span
                  aria-hidden="true"
                  className="h-2.5 w-2.5 flex-none rounded-full"
                  style={{ backgroundColor: provider.color }}
                />
                <span className="w-28 flex-none text-sm font-medium text-charcoal">{name}</span>
                <div className="flex-1">
                  <CopyRow account={account} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div>
        <h3 className="font-display text-sm text-charcoal mb-2">{t("paymentPanel.paypal")}</h3>
        <CopyRow account={paypalAccount} />
      </div>

      <p className="text-xs text-charcoal/40 leading-relaxed">{t("paymentPanel.footnote")}</p>
    </div>
  );
}
