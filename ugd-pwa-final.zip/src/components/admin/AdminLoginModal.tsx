import { useEffect, useState, type FormEvent } from "react";
import {
  completeAdminSignIn,
  enterDemoMode,
  isAdminSignInLink,
  sendAdminSignInLink,
  storedPendingEmail,
} from "../../services/authService";
import { isDemoMode } from "../../services/demoMode";
import { useLanguage } from "../../i18n/LanguageContext";

type Step = "demo" | "checking-link" | "send-link" | "link-sent" | "confirm-email" | "done-error";

const inputCls =
  "w-full rounded-lg border border-slate-light px-3 py-2.5 text-sm text-charcoal placeholder:text-charcoal/40 focus:border-ocean-deep focus:outline-none";

/**
 * Secret Admin Login Modal — v2 (email-link, shared team list).
 * Opened by the triple-click/triple-tap trigger in Footer.tsx, and also
 * auto-opened by Footer.tsx when the page URL is itself a sign-in link
 * (the admin just clicked it in their inbox).
 *
 * Flow: type email -> Firebase sends a real one-time link -> clicking it
 * (same device, same or another tab) logs the admin in, PROVIDED their
 * email is on the shared team list managed in the "Equipe" tab. No
 * password, no "first admin" step -- see services/authService.ts for why.
 */
export default function AdminLoginModal({ onClose }: { onClose: () => void }) {
  const { t } = useLanguage();
  const [step, setStep] = useState<Step>(isDemoMode ? "demo" : "checking-link");
  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (isDemoMode) return; // démo : pas de lien e-mail à vérifier
    if (!isAdminSignInLink()) {
      setStep("send-link");
      return;
    }
    const remembered = storedPendingEmail();
    if (remembered) {
      setBusy(true);
      completeAdminSignIn(remembered)
        .then(() => onClose())
        .catch((err) => {
          setError(err instanceof Error ? err.message : t("admin.genericError"));
          setStep("done-error");
        })
        .finally(() => setBusy(false));
    } else {
      setStep("confirm-email");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleEnterDemo() {
    setError(null);
    setBusy(true);
    try {
      await enterDemoMode();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("admin.genericError"));
    } finally {
      setBusy(false);
    }
  }

  async function handleSendLink(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await sendAdminSignInLink(email);
      setStep("link-sent");
    } catch (err) {
      setError(err instanceof Error ? err.message : t("admin.genericError"));
    } finally {
      setBusy(false);
    }
  }

  async function handleConfirmEmail(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await completeAdminSignIn(email);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("admin.genericError"));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={t("admin.title")}
      className="fixed inset-0 z-[60] flex items-end justify-center bg-charcoal/60 sm:items-center"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-sm rounded-t-2xl bg-white p-5 shadow-card sm:rounded-2xl"
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-base text-ocean-deep">{t("admin.title")}</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label={t("admin.close")}
            className="flex h-8 w-8 items-center justify-center rounded-full hover:bg-slate-light"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M5 5l14 14M19 5 5 19" stroke="#24313A" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </button>
        </div>

        {step === "demo" && (
          <div className="flex flex-col gap-3">
            <p className="rounded-md bg-gold-warm/10 px-3 py-2 text-xs font-semibold text-gold-warm">
              MODE DÉMO
            </p>
            <p className="text-xs text-charcoal/60 leading-relaxed">
              Ce site n'est pas relié à Firebase. Vous pouvez tester tout le panneau administrateur : vos
              modifications restent enregistrées sur cet appareil uniquement et ne sont pas visibles par les autres
              visiteurs.
            </p>
            {error && <p className="text-xs text-red-600">{error}</p>}
            <button
              type="button"
              onClick={handleEnterDemo}
              disabled={busy}
              className="btn-sheen rounded bg-ocean-deep px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-60"
            >
              Entrer dans le panneau (démo)
            </button>
          </div>
        )}

        {step === "checking-link" && <p className="text-sm text-charcoal/50">{t("admin.loading")}</p>}

        {step === "send-link" && (
          <form onSubmit={handleSendLink} className="flex flex-col gap-3">
            <p className="text-xs text-charcoal/60 leading-relaxed">{t("admin.linkIntro")}</p>
            <input
              required
              type="email"
              placeholder={t("admin.emailOnly")}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={inputCls}
            />
            {error && <p className="text-xs text-red-600">{error}</p>}
            <button
              type="submit"
              disabled={busy}
              className="btn-sheen rounded bg-ocean-deep px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-60"
            >
              {busy ? t("admin.sending") : t("admin.sendLink")}
            </button>
          </form>
        )}

        {step === "link-sent" && (
          <div className="flex flex-col gap-3">
            <p className="text-sm text-charcoal/70 leading-relaxed">
              {t("admin.linkSentBody")} <strong>{email}</strong>.
            </p>
            <p className="text-xs text-charcoal/50 leading-relaxed">{t("admin.linkSentHint")}</p>
            <button
              type="button"
              onClick={onClose}
              className="rounded bg-slate-light px-4 py-2.5 text-sm font-semibold text-charcoal"
            >
              {t("admin.close")}
            </button>
          </div>
        )}

        {step === "confirm-email" && (
          <form onSubmit={handleConfirmEmail} className="flex flex-col gap-3">
            <p className="text-xs text-charcoal/60 leading-relaxed">{t("admin.confirmEmailBody")}</p>
            <input
              required
              type="email"
              placeholder={t("admin.emailOnly")}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={inputCls}
            />
            {error && <p className="text-xs text-red-600">{error}</p>}
            <button
              type="submit"
              disabled={busy}
              className="btn-sheen rounded bg-emerald px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-60"
            >
              {busy ? t("admin.verifying") : t("admin.verify")}
            </button>
          </form>
        )}

        {step === "done-error" && (
          <div className="flex flex-col gap-3">
            {error && <p className="text-xs text-red-600">{error}</p>}
            <button
              type="button"
              onClick={() => {
                setError(null);
                setStep("send-link");
              }}
              className="rounded bg-slate-light px-4 py-2.5 text-sm font-semibold text-charcoal"
            >
              {t("admin.backToLogin")}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
