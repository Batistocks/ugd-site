import { useEffect, useState, type ChangeEvent, type FormEvent } from "react";
import {
  addFlyer,
  getFlyers,
  removeFlyer,
  reorderFlyers,
  updateFlyer,
  type FlyerItem,
} from "../../../services/cmsService";
import { isCloudinaryConfigured, uploadToCloudinary } from "../../../services/cloudinaryService";
import { compressImage, formatBytes } from "../../../services/imageCompression";
import { useLanguage } from "../../../i18n/LanguageContext";

const inputCls =
  "w-full rounded-lg border border-slate-light px-3 py-2 text-sm text-charcoal placeholder:text-charcoal/40 focus:border-ocean-deep focus:outline-none";

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

/**
 * Flyer & Media Manager.
 * Section 5: Secret Admin Panel & CMS Management.
 *
 * Flyers are added either by pasting a URL, or by uploading a file. When
 * Cloudinary is configured (Section 6, `cloudinaryService.ts`) an
 * uploaded file goes straight to Cloudinary and the flyer stores the
 * resulting HD delivery URL. Without Cloudinary configured, the file is
 * converted to a data URL and stored locally instead — so the admin
 * panel keeps working fully offline / with zero setup either way.
 * Changes made here appear immediately in the public flyer gallery
 * (Espace 2, `JMSAHub.tsx`) via `subscribeFlyers`.
 */
export default function FlyerMediaPanel({ actorEmail }: { actorEmail: string }) {
  const { t } = useLanguage();
  const [flyers, setFlyers] = useState<FlyerItem[] | null>(null);
  const [newAlt, setNewAlt] = useState("");
  const [newUrl, setNewUrl] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadPct, setUploadPct] = useState<number | null>(null);
  const [compressionNote, setCompressionNote] = useState<string | null>(null);
  const cloudinaryReady = isCloudinaryConfigured();

  async function refresh() {
    setFlyers(await getFlyers());
  }

  useEffect(() => {
    refresh();
  }, []);

  async function handleFileAdd(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!newAlt.trim()) {
      setError(t("flyersPanel.captionFirst"));
      return;
    }
    setBusy(true);
    setError(null);
    setUploadPct(cloudinaryReady ? 0 : null);
    try {
      // Compress before upload/storage: caps most photos at ~200 KB
      // (resize first, quality second — see imageCompression.ts) so a
      // handful of Cloudinary credits or IndexedDB quota isn't burned by
      // an out-of-camera 8 MB JPEG. PDFs pass through untouched.
      let toStore = file;
      if (file.type.startsWith("image/")) {
        const result = await compressImage(file);
        toStore = result.file;
        if (result.compressedBytes < result.originalBytes) {
          setCompressionNote(
            `${formatBytes(result.originalBytes)} → ${formatBytes(result.compressedBytes)} (${result.width}×${result.height}px)`,
          );
        } else {
          setCompressionNote(null);
        }
      }

      let src: string;
      if (cloudinaryReady) {
        const result = await uploadToCloudinary(toStore, {
          folder: "flyers",
          onProgress: setUploadPct,
        });
        src = result.secureUrl;
      } else {
        src = await fileToDataUrl(toStore);
      }
      await addFlyer(actorEmail, { src, alt: newAlt.trim() });
      setNewAlt("");
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("flyersPanel.addFailed"));
    } finally {
      setBusy(false);
      setUploadPct(null);
    }
  }

  async function handleUrlAdd(e: FormEvent) {
    e.preventDefault();
    if (!newAlt.trim() || !newUrl.trim()) return;
    setBusy(true);
    setError(null);
    try {
      await addFlyer(actorEmail, { src: newUrl.trim(), alt: newAlt.trim() });
      setNewAlt("");
      setNewUrl("");
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("flyersPanel.addFailed"));
    } finally {
      setBusy(false);
    }
  }

  async function handleRemove(id: string) {
    setError(null);
    try {
      await removeFlyer(actorEmail, id);
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("flyersPanel.addFailed"));
    }
  }

  async function handleAltInputChange(id: string, alt: string) {
    setFlyers((prev) => prev && prev.map((f) => (f.id === id ? { ...f, alt } : f)));
  }

  async function handleAltBlur(id: string, alt: string) {
    setError(null);
    try {
      await updateFlyer(actorEmail, id, { alt });
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("flyersPanel.addFailed"));
    }
  }

  async function move(index: number, direction: -1 | 1) {
    if (!flyers) return;
    const target = index + direction;
    if (target < 0 || target >= flyers.length) return;
    const ids = flyers.map((f) => f.id);
    [ids[index], ids[target]] = [ids[target], ids[index]];
    setError(null);
    try {
      await reorderFlyers(actorEmail, ids);
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("flyersPanel.addFailed"));
    }
  }

  if (!flyers) return <p className="text-sm text-charcoal/50">{t("admin.loading")}</p>;

  return (
    <div className="flex flex-col gap-4">
      <form onSubmit={handleUrlAdd} className="flex flex-col gap-2 rounded-lg bg-slate-light/60 p-3">
        <p className="text-xs font-semibold text-charcoal/60">{t("flyersPanel.addTitle")}</p>
        <input
          placeholder={t("flyersPanel.captionPlaceholder")}
          value={newAlt}
          onChange={(e) => setNewAlt(e.target.value)}
          className={inputCls}
        />
        <div className="flex gap-2">
          <input
            placeholder={t("flyersPanel.urlPlaceholder")}
            value={newUrl}
            onChange={(e) => setNewUrl(e.target.value)}
            className={inputCls}
          />
          <button
            type="submit"
            disabled={busy || !newUrl.trim() || !newAlt.trim()}
            className="btn-sheen flex-none rounded bg-ocean-deep px-3 py-2 text-xs font-semibold text-white disabled:opacity-40"
          >
            {t("flyersPanel.add")}
          </button>
        </div>
        <label className="text-xs font-semibold text-emerald underline cursor-pointer self-start">
          {t("flyersPanel.uploadFromDevice")}
          <input type="file" accept="image/*,application/pdf" onChange={handleFileAdd} className="hidden" />
        </label>
        <p className="text-[11px] text-charcoal/40">
          {cloudinaryReady ? t("flyersPanel.cloudinaryReady") : t("flyersPanel.cloudinaryNotReady")}
        </p>
        {compressionNote && (
          <p className="text-[11px] text-emerald">{t("flyersPanel.compressed")} {compressionNote}</p>
        )}
        {uploadPct !== null && (
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-light">
            <div
              className="h-full rounded-full bg-emerald transition-[width]"
              style={{ width: `${uploadPct}%` }}
            />
          </div>
        )}
        {error && <p className="text-xs text-red-600">{error}</p>}
      </form>

      <ul className="flex flex-col gap-2">
        {flyers.map((flyer, index) => (
          <li key={flyer.id} className="flex gap-3 rounded-lg border border-slate-light p-2.5">
            <img src={flyer.src} alt="" className="h-16 w-14 flex-none rounded object-cover" />
            <div className="min-w-0 flex-1">
              <input
                value={flyer.alt}
                onChange={(e) => handleAltInputChange(flyer.id, e.target.value)}
                onBlur={(e) => void handleAltBlur(flyer.id, e.target.value)}
                className="w-full truncate rounded border border-transparent bg-transparent text-sm font-medium text-charcoal hover:border-slate-light focus:border-ocean-deep focus:outline-none"
              />
              <p className="truncate text-[11px] text-charcoal/40">{flyer.src}</p>
            </div>
            <div className="flex flex-none flex-col gap-1">
              <button
                type="button"
                onClick={() => move(index, -1)}
                disabled={index === 0}
                aria-label={t("flyersPanel.up")}
                className="flex h-6 w-6 items-center justify-center rounded-full text-charcoal/50 hover:bg-slate-light disabled:opacity-30"
              >
                ↑
              </button>
              <button
                type="button"
                onClick={() => move(index, 1)}
                disabled={index === flyers.length - 1}
                aria-label={t("flyersPanel.down")}
                className="flex h-6 w-6 items-center justify-center rounded-full text-charcoal/50 hover:bg-slate-light disabled:opacity-30"
              >
                ↓
              </button>
              <button
                type="button"
                onClick={() => handleRemove(flyer.id)}
                aria-label={t("flyersPanel.remove")}
                className="flex h-6 w-6 items-center justify-center rounded-full text-red-500 hover:bg-red-50"
              >
                ✕
              </button>
            </div>
          </li>
        ))}
        {flyers.length === 0 && (
          <p className="text-xs text-charcoal/40 italic">{t("flyersPanel.none")}</p>
        )}
      </ul>
    </div>
  );
}
