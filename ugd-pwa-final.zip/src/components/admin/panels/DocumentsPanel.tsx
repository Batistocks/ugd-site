import { useEffect, useState, type ChangeEvent } from "react";
import {
  DEFAULT_DOCUMENTS,
  subscribeDocuments,
  setDocumentsRemote,
  type DocumentItem,
} from "../../../services/cmsService";
import { isCloudinaryConfigured, uploadToCloudinary } from "../../../services/cloudinaryService";
import { isBackendConfigured } from "../../../services/donationsAdminApi";

const inputCls =
  "w-full rounded-lg border border-slate-light px-3 py-2 text-sm text-charcoal placeholder:text-charcoal/40 focus:border-ocean-deep focus:outline-none";

const KIND_HINT: Record<DocumentItem["kind"], string> = {
  founder: "Espace « Fondatrice » — bio de Marie Nicaise Makamgue Djembong.",
  "jmsa-sponsoring": "Sommet JMSA → onglet Sponsoring.",
  "ugd-marketing": "Missions & Transparence → Rapports.",
  custom: "Document libre — s'affiche aussi dans Missions & Transparence → Rapports.",
};

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

/**
 * Documents — bibliothèque de PDF. Les trois emplacements historiques
 * (bio de la Fondatrice, dossier sponsoring JMSA, dossier marketing UGD)
 * sont maintenant des entrées d'une liste unique, au même titre que
 * n'importe quel document libre ajouté ici : renommables (FR/EN),
 * remplaçables (upload ou URL), réordonnables, activables/désactivables,
 * et supprimables. Un emplacement système supprimé reste restaurable
 * (son code/sa place dans l'app ne disparaît pas) ; un document libre
 * supprimé est définitivement parti.
 *
 * Tout document "libre" ajouté ici apparaît automatiquement dans
 * Missions & Transparence → Rapports, en plus du dossier marketing UGD —
 * c'est la façon de publier un PDF supplémentaire sans toucher au code.
 */
export default function DocumentsPanel({ actorEmail }: { actorEmail: string }) {
  const [documents, setDocumentsState] = useState<DocumentItem[] | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [uploadPct, setUploadPct] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [savedId, setSavedId] = useState<string | null>(null);
  const [urlDrafts, setUrlDrafts] = useState<Record<string, string>>({});
  const [editingId, setEditingId] = useState<string | null>(null);
  const [addingNew, setAddingNew] = useState(false);
  const cloudinaryReady = isCloudinaryConfigured();

  useEffect(() => subscribeDocuments(setDocumentsState), []);

  if (!isBackendConfigured()) {
    return (
      <div className="rounded-card border border-gold-warm/40 bg-gold-warm/10 p-4 text-sm text-charcoal">
        <p className="font-semibold">Backend non configuré</p>
        <p className="mt-1 text-charcoal/70">
          Renseignez <code className="rounded bg-white/60 px-1">VITE_API_BASE_URL</code> dans{" "}
          <code className="rounded bg-white/60 px-1">.env</code>.
        </p>
      </div>
    );
  }

  if (!documents) return <p className="text-sm text-charcoal/50">Chargement…</p>;

  async function persist(next: DocumentItem[]) {
    setDocumentsState(next);
    setError(null);
    try {
      await setDocumentsRemote(actorEmail, next);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Échec de l'enregistrement.");
    }
  }

  async function replaceSrc(id: string, src: string) {
    if (!documents) return;
    setSavedId(null);
    await persist(documents.map((d) => (d.id === id ? { ...d, src } : d)));
    setSavedId(id);
  }

  async function handleFile(id: string, e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file || !documents) return;
    if (file.type !== "application/pdf") {
      setError("Merci de sélectionner un fichier PDF.");
      return;
    }
    setError(null);
    setSavedId(null);
    setBusyId(id);
    setUploadPct(cloudinaryReady ? 0 : null);
    try {
      let src: string;
      if (cloudinaryReady) {
        const result = await uploadToCloudinary(file, { folder: "documents", resourceType: "raw", onProgress: setUploadPct });
        src = result.secureUrl;
      } else {
        // No Cloudinary configured — same offline-friendly fallback as
        // FlyerMediaPanel: store the PDF as a data URL in Firestore/local
        // cache. Fine for reasonably small PDFs; Cloudinary is
        // recommended for anything large.
        src = await fileToDataUrl(file);
      }
      await replaceSrc(id, src);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Échec de l'envoi.");
    } finally {
      setBusyId(null);
      setUploadPct(null);
    }
  }

  async function handleUrlSave(id: string) {
    const url = (urlDrafts[id] ?? "").trim();
    if (!url) return;
    await replaceSrc(id, url);
    setUrlDrafts((prev) => ({ ...prev, [id]: "" }));
  }

  function updateLabel(id: string, label: string) {
    if (!documents) return;
    setDocumentsState(documents.map((d) => (d.id === id ? { ...d, label } : d)));
  }

  function updateLabelEn(id: string, labelEn: string) {
    if (!documents) return;
    setDocumentsState(documents.map((d) => (d.id === id ? { ...d, labelEn } : d)));
  }

  function commitLabel() {
    if (documents) void persist(documents);
    setEditingId(null);
  }

  function toggleEnabled(id: string) {
    if (!documents) return;
    void persist(documents.map((d) => (d.id === id ? { ...d, enabled: !d.enabled } : d)));
  }

  function deleteDoc(id: string) {
    if (!documents) return;
    void persist(documents.filter((d) => d.id !== id));
  }

  function restoreDefault(id: string) {
    if (!documents) return;
    const fallback = DEFAULT_DOCUMENTS.find((d) => d.id === id);
    if (!fallback) return;
    void persist([...documents, fallback]);
  }

  const restorable = DEFAULT_DOCUMENTS.filter((d) => !documents.some((doc) => doc.id === d.id));

  return (
    <div className="flex flex-col gap-4">
      <p className="text-xs text-charcoal/50 leading-relaxed">
        Chaque document peut être renommé (FR/EN), remplacé (upload ou URL), activé/désactivé, ou supprimé. Les trois
        emplacements système supprimés restent restaurables plus bas ; un document libre supprimé est définitivement
        parti. Ajoutez un document libre pour qu'il apparaisse automatiquement dans Missions & Transparence →
        Rapports.
      </p>

      {error && <p className="rounded-md bg-red-50 px-3 py-2 text-xs text-red-600">{error}</p>}
      {!cloudinaryReady && (
        <p className="rounded-md bg-gold-warm/10 px-3 py-2 text-xs text-charcoal/70">
          Cloudinary n'est pas configuré : les PDF envoyés seront stockés directement (data URL), ce qui convient
          pour des fichiers de taille raisonnable.
        </p>
      )}

      {documents.map((doc) => {
        const busy = busyId === doc.id;
        return (
          <div key={doc.id} className="rounded-card border border-slate-light bg-white p-3.5">
            <div className="flex items-start justify-between gap-2">
              {editingId === doc.id ? (
                <div className="flex flex-1 flex-col gap-1">
                  <input
                    autoFocus
                    value={doc.label}
                    onChange={(e) => updateLabel(doc.id, e.target.value)}
                    onBlur={commitLabel}
                    onKeyDown={(e) => e.key === "Enter" && commitLabel()}
                    placeholder="Titre (français)"
                    className="w-full rounded-md border border-slate-light px-2 py-1 text-sm"
                  />
                  <input
                    value={doc.labelEn ?? ""}
                    onChange={(e) => updateLabelEn(doc.id, e.target.value)}
                    onBlur={commitLabel}
                    onKeyDown={(e) => e.key === "Enter" && commitLabel()}
                    placeholder="Title (English) — laisser vide pour reprendre le français"
                    className="w-full rounded-md border border-slate-light px-2 py-1 text-sm text-charcoal/70"
                  />
                </div>
              ) : (
                <button type="button" onClick={() => setEditingId(doc.id)} className="flex-1 text-left" title="Cliquer pour renommer (FR + EN)">
                  <p className="text-sm font-semibold text-charcoal">
                    {doc.label}
                    {doc.labelEn && doc.labelEn.trim() && (
                      <span className="ml-1.5 text-xs font-normal text-charcoal/40">/ {doc.labelEn}</span>
                    )}
                  </p>
                  <p className="mt-0.5 text-xs text-charcoal/50">{KIND_HINT[doc.kind]}</p>
                </button>
              )}

              <button
                type="button"
                onClick={() => toggleEnabled(doc.id)}
                className={`flex-none rounded-full px-2.5 py-1 text-[11px] font-semibold ${
                  doc.enabled ? "bg-emerald/10 text-emerald" : "bg-slate-light text-charcoal/40"
                }`}
              >
                {doc.enabled ? "Activé" : "Désactivé"}
              </button>
              <button
                type="button"
                onClick={() => deleteDoc(doc.id)}
                aria-label="Supprimer"
                title={doc.kind === "custom" ? "Supprimer définitivement" : "Supprimer (restaurable plus bas)"}
                className="flex h-7 w-7 flex-none items-center justify-center rounded-full text-red-500 hover:bg-red-50"
              >
                ✕
              </button>
            </div>

            <div className="mt-2 flex items-center justify-between gap-2 rounded bg-slate-light/50 px-2.5 py-1.5">
              <span className="truncate text-xs text-charcoal/70">{doc.src}</span>
            </div>

            {savedId === doc.id && (
              <p className="mt-2 rounded-md bg-emerald/10 px-2.5 py-1.5 text-xs text-emerald">Document mis à jour.</p>
            )}

            <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-center">
              <label className="flex-1">
                <span className="sr-only">Envoyer un nouveau PDF</span>
                <input
                  type="file"
                  accept="application/pdf"
                  disabled={busy}
                  onChange={(e) => handleFile(doc.id, e)}
                  className="block w-full text-xs text-charcoal/70 file:mr-2 file:rounded-full file:border-0 file:bg-ocean-deep file:px-3 file:py-1.5 file:text-xs file:font-semibold file:text-white disabled:opacity-50"
                />
              </label>
              {busy && uploadPct !== null && <span className="flex-none text-xs text-charcoal/50">{uploadPct}%</span>}
              {busy && uploadPct === null && <span className="flex-none text-xs text-charcoal/50">Envoi…</span>}
            </div>

            <div className="mt-2 flex gap-2">
              <input
                type="url"
                placeholder="…ou coller une URL PDF déjà hébergée"
                value={urlDrafts[doc.id] ?? ""}
                onChange={(e) => setUrlDrafts((prev) => ({ ...prev, [doc.id]: e.target.value }))}
                className={inputCls}
                disabled={busy}
              />
              <button
                type="button"
                onClick={() => handleUrlSave(doc.id)}
                disabled={busy || !(urlDrafts[doc.id] ?? "").trim()}
                className="flex-none rounded-lg bg-ocean-deep px-3 py-2 text-xs font-semibold text-white disabled:opacity-40"
              >
                Enregistrer
              </button>
            </div>
          </div>
        );
      })}

      {restorable.length > 0 && (
        <div className="flex flex-col gap-2 rounded-lg border border-dashed border-slate-light p-3">
          <p className="text-xs font-semibold text-charcoal/60">Emplacements système supprimés — les restaurer :</p>
          <div className="flex flex-wrap gap-2">
            {restorable.map((d) => (
              <button
                key={d.id}
                type="button"
                onClick={() => restoreDefault(d.id)}
                className="rounded-full border border-ocean-deep/40 px-3 py-1 text-xs font-semibold text-ocean-deep hover:bg-ocean-deep/5"
              >
                + Restaurer « {d.label} »
              </button>
            ))}
          </div>
        </div>
      )}

      {addingNew ? (
        <NewDocumentForm
          busy={busyId === "__new__"}
          uploadPct={busyId === "__new__" ? uploadPct : null}
          cloudinaryReady={cloudinaryReady}
          onCancel={() => setAddingNew(false)}
          onCreate={async (draft) => {
            setBusyId("__new__");
            setError(null);
            try {
              const id = `custom-${Date.now().toString(36)}`;
              const doc: DocumentItem = {
                id,
                kind: "custom",
                enabled: true,
                label: draft.label,
                labelEn: draft.labelEn || undefined,
                src: draft.src,
              };
              await persist([...(documents ?? []), doc]);
              setAddingNew(false);
            } catch (err) {
              setError(err instanceof Error ? err.message : "Échec de l'ajout.");
            } finally {
              setBusyId(null);
              setUploadPct(null);
            }
          }}
          onProgress={setUploadPct}
        />
      ) : (
        <button
          type="button"
          onClick={() => setAddingNew(true)}
          className="self-start rounded-full border border-ocean-deep px-3 py-1.5 text-xs font-semibold text-ocean-deep"
        >
          + Nouveau document
        </button>
      )}
    </div>
  );
}

function NewDocumentForm({
  busy,
  uploadPct,
  cloudinaryReady,
  onCancel,
  onCreate,
  onProgress,
}: {
  busy: boolean;
  uploadPct: number | null;
  cloudinaryReady: boolean;
  onCancel: () => void;
  onCreate: (draft: { label: string; labelEn: string; src: string }) => void | Promise<void>;
  onProgress: (pct: number | null) => void;
}) {
  const [label, setLabel] = useState("");
  const [labelEn, setLabelEn] = useState("");
  const [url, setUrl] = useState("");

  async function handleFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (file.type !== "application/pdf") return;
    onProgress(cloudinaryReady ? 0 : null);
    try {
      const src = cloudinaryReady
        ? (await uploadToCloudinary(file, { folder: "documents", resourceType: "raw", onProgress })).secureUrl
        : await fileToDataUrl(file);
      await onCreate({ label: label.trim() || file.name.replace(/\.pdf$/i, ""), labelEn: labelEn.trim(), src });
    } finally {
      onProgress(null);
    }
  }

  return (
    <div className="flex flex-col gap-2 rounded-lg border border-dashed border-ocean-deep/40 p-3">
      <input
        autoFocus
        placeholder="Titre du document (français)"
        value={label}
        onChange={(e) => setLabel(e.target.value)}
        className="w-full rounded-md border border-slate-light px-2 py-1.5 text-sm"
      />
      <input
        placeholder="Title (English) — laisser vide pour reprendre le français"
        value={labelEn}
        onChange={(e) => setLabelEn(e.target.value)}
        className="w-full rounded-md border border-slate-light px-2 py-1.5 text-sm text-charcoal/70"
      />

      <label className="flex-1">
        <span className="sr-only">Envoyer un PDF</span>
        <input
          type="file"
          accept="application/pdf"
          disabled={busy}
          onChange={handleFile}
          className="block w-full text-xs text-charcoal/70 file:mr-2 file:rounded-full file:border-0 file:bg-ocean-deep file:px-3 file:py-1.5 file:text-xs file:font-semibold file:text-white disabled:opacity-50"
        />
      </label>
      {busy && uploadPct !== null && <span className="text-xs text-charcoal/50">{uploadPct}%</span>}
      {busy && uploadPct === null && <span className="text-xs text-charcoal/50">Envoi…</span>}

      <div className="flex gap-2">
        <input
          type="url"
          placeholder="…ou coller une URL PDF déjà hébergée"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          className={inputCls}
          disabled={busy}
        />
        <button
          type="button"
          disabled={busy || !url.trim() || !label.trim()}
          onClick={() => onCreate({ label: label.trim(), labelEn: labelEn.trim(), src: url.trim() })}
          className="flex-none rounded-lg bg-ocean-deep px-3 py-2 text-xs font-semibold text-white disabled:opacity-40"
        >
          Créer
        </button>
      </div>

      <button type="button" onClick={onCancel} className="self-start text-xs font-semibold text-charcoal/50 underline underline-offset-2 hover:text-charcoal">
        Annuler
      </button>
    </div>
  );
}
