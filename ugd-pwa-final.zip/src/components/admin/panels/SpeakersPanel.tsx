import { useEffect, useState, type ChangeEvent } from "react";
import {
  addSpeaker,
  getSpeakers,
  removeSpeaker,
  reorderSpeakers,
  updateSpeaker,
  type BilingualSpeaker,
  type SpeakerFields,
} from "../../../services/cmsService";
import { isCloudinaryConfigured, uploadToCloudinary } from "../../../services/cloudinaryService";
import { compressImage, formatBytes } from "../../../services/imageCompression";
import { useLanguage } from "../../../i18n/LanguageContext";

const inputCls =
  "w-full rounded-lg border border-slate-light px-2.5 py-1.5 text-sm text-charcoal placeholder:text-charcoal/40 focus:border-ocean-deep focus:outline-none";

const EMPTY_FIELDS: SpeakerFields = { name: "", role: "", country: "", badge: "" };

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

/**
 * Speakers (Intervenants) Manager — bilingual.
 * Section 5: Secret Admin Panel & CMS Management.
 *
 * Same shared-Firestore-doc model as FlyerMediaPanel.tsx (settings/site via
 * getSpeakers/setSpeakers-backed cmsService functions), but each card has
 * two text sets (fr/en) instead of one — only the photo is shared. A
 * "Copier vers EN" button next to each French field pre-fills the English
 * field with the French text as a starting point to correct, rather than
 * leaving it empty.
 *
 * Photo upload reuses the exact Cloudinary/compression pipeline from
 * FlyerMediaPanel.tsx (folder "speakers" instead of "flyers").
 *
 * Changes made here appear immediately on the public site (Espace 2,
 * JMSAHub.tsx) via subscribeSpeakers, which falls back to the static
 * jmsaProgramme.ts list if this list is ever empty.
 */
export default function SpeakersPanel({ actorEmail }: { actorEmail: string }) {
  const { t } = useLanguage();
  const [speakers, setSpeakers] = useState<BilingualSpeaker[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const cloudinaryReady = isCloudinaryConfigured();

  // --- New speaker draft --------------------------------------------------
  const [newPhoto, setNewPhoto] = useState("");
  const [newPhotoUrl, setNewPhotoUrl] = useState("");
  const [newFr, setNewFr] = useState<SpeakerFields>(EMPTY_FIELDS);
  const [newEn, setNewEn] = useState<SpeakerFields>(EMPTY_FIELDS);
  const [uploadPct, setUploadPct] = useState<number | null>(null);
  const [compressionNote, setCompressionNote] = useState<string | null>(null);

  async function refresh() {
    setSpeakers(await getSpeakers());
  }

  useEffect(() => {
    refresh();
  }, []);

  async function uploadPhoto(file: File): Promise<string> {
    let toStore = file;
    if (file.type.startsWith("image/")) {
      const result = await compressImage(file);
      toStore = result.file;
      if (result.compressedBytes < result.originalBytes) {
        setCompressionNote(
          `${formatBytes(result.originalBytes)} → ${formatBytes(result.compressedBytes)} (${result.width}×${result.height}px)`,
        );
      } else {
        setCompressionNote(null);
      }
    }
    if (cloudinaryReady) {
      const result = await uploadToCloudinary(file.type.startsWith("image/") ? toStore : file, {
        folder: "speakers",
        onProgress: setUploadPct,
      });
      return result.secureUrl;
    }
    return fileToDataUrl(toStore);
  }

  // --- Add form -------------------------------------------------------------

  async function handleNewPhotoFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setBusy(true);
    setError(null);
    setUploadPct(cloudinaryReady ? 0 : null);
    try {
      setNewPhoto(await uploadPhoto(file));
    } catch (err) {
      setError(err instanceof Error ? err.message : t("speakersPanel.addFailed"));
    } finally {
      setBusy(false);
      setUploadPct(null);
    }
  }

  async function handleAddSpeaker() {
    if (!newFr.name.trim()) {
      setError(t("speakersPanel.namesRequiredFirst"));
      return;
    }
    const photo = newPhoto.trim() || newPhotoUrl.trim();
    setBusy(true);
    setError(null);
    try {
      await addSpeaker(actorEmail, {
        photo,
        fr: { ...newFr, name: newFr.name.trim() },
        en: { ...newEn, name: newEn.name.trim() || newFr.name.trim() },
      });
      setNewPhoto("");
      setNewPhotoUrl("");
      setNewFr(EMPTY_FIELDS);
      setNewEn(EMPTY_FIELDS);
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("speakersPanel.addFailed"));
    } finally {
      setBusy(false);
    }
  }

  // --- Existing speaker edits -------------------------------------------------

  function patchLocal(id: string, lang: "fr" | "en", field: keyof SpeakerFields, value: string) {
    setSpeakers((prev) =>
      prev && prev.map((s) => (s.id === id ? { ...s, [lang]: { ...s[lang], [field]: value } } : s)),
    );
  }

  async function persistField(id: string, lang: "fr" | "en", field: keyof SpeakerFields, value: string) {
    const current = speakers?.find((s) => s.id === id);
    if (!current) return;
    setError(null);
    try {
      await updateSpeaker(actorEmail, id, { [lang]: { ...current[lang], [field]: value } });
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("speakersPanel.addFailed"));
    }
  }

  async function copyToEn(id: string, field: keyof SpeakerFields) {
    const current = speakers?.find((s) => s.id === id);
    if (!current) return;
    const value = current.fr[field] ?? "";
    patchLocal(id, "en", field, value);
    await persistField(id, "en", field, value);
  }

  async function handlePhotoReplace(id: string, e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setBusy(true);
    setError(null);
    setUploadPct(cloudinaryReady ? 0 : null);
    try {
      const photo = await uploadPhoto(file);
      await updateSpeaker(actorEmail, id, { photo });
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("speakersPanel.addFailed"));
    } finally {
      setBusy(false);
      setUploadPct(null);
    }
  }

  async function handleRemove(id: string) {
    setError(null);
    try {
      await removeSpeaker(actorEmail, id);
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("speakersPanel.addFailed"));
    }
  }

  async function move(index: number, direction: -1 | 1) {
    if (!speakers) return;
    const target = index + direction;
    if (target < 0 || target >= speakers.length) return;
    const ids = speakers.map((s) => s.id);
    [ids[index], ids[target]] = [ids[target], ids[index]];
    setError(null);
    try {
      await reorderSpeakers(actorEmail, ids);
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("speakersPanel.addFailed"));
    }
  }

  if (!speakers) return <p className="text-sm text-charcoal/50">{t("admin.loading")}</p>;

  return (
    <div className="flex flex-col gap-4">
      {/* Add form */}
      <div className="flex flex-col gap-3 rounded-lg bg-slate-light/60 p-3">
        <p className="text-xs font-semibold text-charcoal/60">{t("speakersPanel.addTitle")}</p>

        <div className="flex items-center gap-3">
          {(newPhoto || newPhotoUrl) && (
            <img
              src={newPhoto || newPhotoUrl}
              alt=""
              className="h-14 w-14 flex-none rounded-full object-cover object-top"
            />
          )}
          <div className="flex min-w-0 flex-1 flex-col gap-1.5">
            <input
              placeholder={t("speakersPanel.urlPlaceholder")}
              value={newPhotoUrl}
              onChange={(e) => {
                setNewPhotoUrl(e.target.value);
                setNewPhoto("");
              }}
              className={inputCls}
            />
            <label className="text-xs font-semibold text-emerald underline cursor-pointer self-start">
              {t("speakersPanel.uploadFromDevice")}
              <input type="file" accept="image/*" onChange={handleNewPhotoFile} className="hidden" />
            </label>
          </div>
        </div>
        <p className="text-[11px] text-charcoal/40">
          {cloudinaryReady ? t("speakersPanel.cloudinaryReady") : t("speakersPanel.cloudinaryNotReady")}
        </p>
        {compressionNote && (
          <p className="text-[11px] text-emerald">
            {t("speakersPanel.compressed")} {compressionNote}
          </p>
        )}
        {uploadPct !== null && (
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-light">
            <div className="h-full rounded-full bg-emerald transition-[width]" style={{ width: `${uploadPct}%` }} />
          </div>
        )}

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <FieldsColumn
            label={t("speakersPanel.fr")}
            t={t}
            values={newFr}
            onChange={(field, value) => setNewFr((prev) => ({ ...prev, [field]: value }))}
            onCopyToEn={(field) => setNewEn((prev) => ({ ...prev, [field]: newFr[field] ?? "" }))}
            showCopy
          />
          <FieldsColumn
            label={t("speakersPanel.en")}
            t={t}
            values={newEn}
            onChange={(field, value) => setNewEn((prev) => ({ ...prev, [field]: value }))}
          />
        </div>

        <button
          type="button"
          onClick={handleAddSpeaker}
          disabled={busy || !newFr.name.trim()}
          className="btn-sheen self-start rounded bg-ocean-deep px-3 py-2 text-xs font-semibold text-white disabled:opacity-40"
        >
          {t("speakersPanel.add")}
        </button>
        {error && <p className="text-xs text-red-600">{error}</p>}
      </div>

      {/* Existing speakers */}
      <ul className="flex flex-col gap-3">
        {speakers.map((speaker, index) => (
          <li key={speaker.id} className="flex flex-col gap-2.5 rounded-lg border border-slate-light p-3">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <img
                  src={speaker.photo}
                  alt=""
                  className="h-14 w-14 flex-none rounded-full object-cover object-top"
                />
                <label className="text-xs font-semibold text-emerald underline cursor-pointer">
                  {t("speakersPanel.photo")}
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handlePhotoReplace(speaker.id, e)}
                    className="hidden"
                  />
                </label>
              </div>
              <div className="flex flex-none gap-1">
                <button
                  type="button"
                  onClick={() => move(index, -1)}
                  disabled={index === 0}
                  aria-label={t("speakersPanel.up")}
                  className="flex h-6 w-6 items-center justify-center rounded-full text-charcoal/50 hover:bg-slate-light disabled:opacity-30"
                >
                  ↑
                </button>
                <button
                  type="button"
                  onClick={() => move(index, 1)}
                  disabled={index === speakers.length - 1}
                  aria-label={t("speakersPanel.down")}
                  className="flex h-6 w-6 items-center justify-center rounded-full text-charcoal/50 hover:bg-slate-light disabled:opacity-30"
                >
                  ↓
                </button>
                <button
                  type="button"
                  onClick={() => handleRemove(speaker.id)}
                  aria-label={t("speakersPanel.remove")}
                  className="flex h-6 w-6 items-center justify-center rounded-full text-red-500 hover:bg-red-50"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <FieldsColumn
                label={t("speakersPanel.fr")}
                t={t}
                values={speaker.fr}
                onChange={(field, value) => patchLocal(speaker.id, "fr", field, value)}
                onBlurField={(field, value) => persistField(speaker.id, "fr", field, value)}
                onCopyToEn={(field) => copyToEn(speaker.id, field)}
                showCopy
              />
              <FieldsColumn
                label={t("speakersPanel.en")}
                t={t}
                values={speaker.en}
                onChange={(field, value) => patchLocal(speaker.id, "en", field, value)}
                onBlurField={(field, value) => persistField(speaker.id, "en", field, value)}
              />
            </div>
          </li>
        ))}
        {speakers.length === 0 && <p className="text-xs text-charcoal/40 italic">{t("speakersPanel.none")}</p>}
      </ul>
    </div>
  );
}

/** One language column (name/role/country/badge), optionally with a "copy to EN" button per field. */
function FieldsColumn({
  label,
  t,
  values,
  onChange,
  onBlurField,
  onCopyToEn,
  showCopy,
}: {
  label: string;
  t: (key: string) => string;
  values: SpeakerFields;
  onChange: (field: keyof SpeakerFields, value: string) => void;
  onBlurField?: (field: keyof SpeakerFields, value: string) => void;
  onCopyToEn?: (field: keyof SpeakerFields) => void;
  showCopy?: boolean;
}) {
  const fields: { key: keyof SpeakerFields; labelKey: string; multiline?: boolean }[] = [
    { key: "name", labelKey: "speakersPanel.name" },
    { key: "role", labelKey: "speakersPanel.role", multiline: true },
    { key: "country", labelKey: "speakersPanel.country" },
    { key: "badge", labelKey: "speakersPanel.badge" },
  ];

  return (
    <div className="flex flex-col gap-1.5">
      <p className="text-[11px] font-semibold uppercase tracking-wide text-charcoal/40">{label}</p>
      {fields.map(({ key, labelKey, multiline }) => (
        <div key={key} className="flex items-start gap-1.5">
          {multiline ? (
            <textarea
              rows={2}
              placeholder={t(labelKey)}
              value={values[key] ?? ""}
              onChange={(e) => onChange(key, e.target.value)}
              onBlur={(e) => onBlurField?.(key, e.target.value)}
              className={`${inputCls} resize-none`}
            />
          ) : (
            <input
              placeholder={t(labelKey)}
              value={values[key] ?? ""}
              onChange={(e) => onChange(key, e.target.value)}
              onBlur={(e) => onBlurField?.(key, e.target.value)}
              className={inputCls}
            />
          )}
          {showCopy && onCopyToEn && (
            <button
              type="button"
              onClick={() => onCopyToEn(key)}
              title={t("speakersPanel.copyToEn")}
              className="mt-1 flex-none rounded-full bg-ocean-deep/10 px-2 py-1 text-[10px] font-semibold text-ocean-deep hover:bg-ocean-deep/20"
            >
              → EN
            </button>
          )}
        </div>
      ))}
    </div>
  );
}
