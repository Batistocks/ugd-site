import { useEffect, useMemo, useState } from "react";
import {
  fetchRegistrations,
  checkInRegistrationRemote,
  isBackendConfigured,
  type RegistrationRecord,
} from "../../../services/registrationsAdminApi";
import { recordAuditEvent } from "../../../services/auditLog";

/**
 * Inscriptions — panneau de vérification, sur le même modèle que
 * "Dons à vérifier" (DonationsReviewPanel.tsx). Répond au trou signalé en
 * ouverture de conversation : avant ce panneau, l'association n'avait
 * aucun endroit où voir la liste des inscrits — chacun repartait avec son
 * PDF, point final.
 *
 * Parle aux deux Netlify Functions admin-protégées (voir
 * services/registrationsAdminApi.ts + netlify/functions/) :
 *  - listRegistrations   : liste des inscriptions reçues (submitPassRequest).
 *  - checkInRegistration : marque un inscrit présent — utilisé ici pour un
 *    pointage manuel, et par QRScannerModal.tsx pour le pointage à
 *    l'entrée (les deux écrivent dans la même liste partagée).
 */
export default function InscriptionsPanel({ actorEmail }: { actorEmail: string }) {
  const [filter, setFilter] = useState<"all" | "checked" | "not-checked">("all");
  const [dayFilter, setDayFilter] = useState<string>("all");
  const [ticketFilter, setTicketFilter] = useState<string>("all");
  const [items, setItems] = useState<RegistrationRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  function formatDate(ms: number | null): string {
    if (!ms) return "—";
    return new Date(ms).toLocaleString("fr-BE");
  }

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const checkedIn = filter === "all" ? undefined : filter === "checked";
      const data = await fetchRegistrations(checkedIn);
      setItems(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur inconnue.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  async function handleCheckIn(item: RegistrationRecord) {
    setBusyId(item.registrationId);
    try {
      await checkInRegistrationRemote(item.registrationId);
      await recordAuditEvent(actorEmail, "checkin-manual", `${item.registrationId} — ${item.fullName}`);
      setItems((prev) =>
        prev.map((r) => (r.registrationId === item.registrationId ? { ...r, checkedIn: true, checkedInAt: Date.now(), checkedInBy: actorEmail } : r)),
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Échec du pointage.");
    } finally {
      setBusyId(null);
    }
  }

  const dayOptions = useMemo(() => Array.from(new Set(items.map((i) => i.day).filter(Boolean))) as string[], [items]);
  const ticketOptions = useMemo(() => Array.from(new Set(items.map((i) => i.ticketType).filter(Boolean))) as string[], [items]);

  const filteredItems = items.filter(
    (i) => (dayFilter === "all" || i.day === dayFilter) && (ticketFilter === "all" || i.ticketType === ticketFilter),
  );

  const counts = useMemo(() => {
    const byDay = new Map<string, number>();
    const byTicket = new Map<string, number>();
    for (const i of items) {
      if (i.day) byDay.set(i.day, (byDay.get(i.day) ?? 0) + 1);
      if (i.ticketType) byTicket.set(i.ticketType, (byTicket.get(i.ticketType) ?? 0) + 1);
    }
    return { byDay, byTicket, total: items.length, checkedIn: items.filter((i) => i.checkedIn).length };
  }, [items]);

  function exportCsv() {
    const headers = ["registrationId", "fullName", "email", "phone", "organization", "day", "ticketType", "checkedIn", "createdAt"];
    const escape = (v: unknown) => {
      const str = v === undefined || v === null ? "" : String(v);
      return /[",\n]/.test(str) ? `"${str.replace(/"/g, '""')}"` : str;
    };
    const lines = [headers.join(",")];
    for (const i of filteredItems) {
      lines.push(
        headers
          .map((h) => escape(h === "createdAt" ? formatDate(i.createdAt) : (i as unknown as Record<string, unknown>)[h]))
          .join(","),
      );
    }
    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `ugd-inscriptions-${new Date().toISOString().replace(/[:.]/g, "-")}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  if (!isBackendConfigured()) {
    return (
      <div className="rounded-lg border border-gold-warm/40 bg-gold-warm/10 p-4 text-sm text-charcoal">
        <p className="font-semibold">Backend non configuré</p>
        <p className="mt-1 text-charcoal/70">
          Renseignez <code className="rounded bg-white/60 px-1">VITE_API_BASE_URL</code> dans{" "}
          <code className="rounded bg-white/60 px-1">.env</code>.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="rounded-lg border border-slate-light bg-white p-3 text-xs text-charcoal/70">
        <p className="font-semibold text-charcoal">
          {counts.total} inscrit(s) · {counts.checkedIn} présent(s)
        </p>
        {counts.byDay.size > 0 && (
          <p className="mt-1">
            {Array.from(counts.byDay.entries())
              .map(([d, n]) => `${d} : ${n}`)
              .join(" · ")}
          </p>
        )}
        {counts.byTicket.size > 0 && (
          <p className="mt-1">
            {Array.from(counts.byTicket.entries())
              .map(([tk, n]) => `${tk} : ${n}`)
              .join(" · ")}
          </p>
        )}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <div className="flex gap-1">
          {(["all", "checked", "not-checked"] as const).map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setFilter(f)}
              className={`rounded-full px-3 py-1.5 text-xs font-semibold ${
                filter === f ? "bg-ocean-deep text-white" : "bg-white text-charcoal/60 border border-slate-light"
              }`}
            >
              {f === "all" ? "Toutes" : f === "checked" ? "Présents" : "Non présents"}
            </button>
          ))}
        </div>

        {dayOptions.length > 0 && (
          <select value={dayFilter} onChange={(e) => setDayFilter(e.target.value)} className="rounded-full border border-slate-light px-2 py-1.5 text-xs">
            <option value="all">Tous les jours</option>
            {dayOptions.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        )}
        {ticketOptions.length > 0 && (
          <select value={ticketFilter} onChange={(e) => setTicketFilter(e.target.value)} className="rounded-full border border-slate-light px-2 py-1.5 text-xs">
            <option value="all">Tous les billets</option>
            {ticketOptions.map((tk) => (
              <option key={tk} value={tk}>
                {tk}
              </option>
            ))}
          </select>
        )}

        <div className="ml-auto flex gap-2">
          <button type="button" onClick={() => void load()} className="rounded-full border border-slate-light px-3 py-1.5 text-xs font-semibold text-charcoal/70">
            {loading ? "Actualisation…" : "Actualiser"}
          </button>
          <button type="button" onClick={exportCsv} className="rounded-full border border-slate-light px-3 py-1.5 text-xs font-semibold text-charcoal/70">
            Export CSV
          </button>
        </div>
      </div>

      {error && <p className="rounded-md bg-red-50 px-3 py-2 text-xs text-red-600">{error}</p>}

      {!loading && filteredItems.length === 0 && <p className="text-sm text-charcoal/50">Aucune inscription.</p>}

      <ul className="flex flex-col gap-3">
        {filteredItems.map((item) => (
          <li key={item.registrationId} className="rounded-lg border border-slate-light bg-white p-3">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="text-sm font-semibold text-charcoal">{item.fullName}</p>
                <p className="text-xs text-charcoal/60">
                  {item.ticketType ?? "—"} · {item.day ?? "—"}
                  {item.organization && <> · {item.organization}</>}
                </p>
                <p className="mt-1 text-[11px] text-charcoal/40">
                  Réf. {item.registrationId} · {formatDate(item.createdAt)}
                  {item.email && <> · {item.email}</>}
                  {item.phone && <> · {item.phone}</>}
                </p>
              </div>
              {item.checkedIn ? (
                <span className="flex-none rounded-full bg-emerald/10 px-3 py-1.5 text-xs font-semibold text-emerald">
                  Présent
                </span>
              ) : (
                <button
                  type="button"
                  disabled={busyId === item.registrationId}
                  onClick={() => void handleCheckIn(item)}
                  className="btn-sheen flex-none rounded bg-emerald px-3 py-1.5 text-xs font-semibold text-white disabled:opacity-60"
                >
                  {busyId === item.registrationId ? "…" : "Marquer présent"}
                </button>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
