import { useEffect, useState, type DragEvent, type FormEvent } from "react";
import {
  DEFAULT_SPACES,
  setSpacesRemote,
  subscribeSpaces,
  type Space,
} from "../../../services/cmsService";
import { isBackendConfigured } from "../../../services/donationsAdminApi";

const KIND_BADGE: Record<Space["kind"], string> = {
  home: "onglet système",
  founder: "onglet système",
  contact: "onglet système",
  module: "module intégré",
  custom: "espace libre",
};

/**
 * Espaces — la liste ordonnée UNIQUE qui pilote toute la nav publique :
 * Accueil, Fondatrice et Contact (autrefois câblés en dur dans App.tsx)
 * sont maintenant des entrées comme les autres, au même titre que les 4
 * modules historiques (JMSA, Dons, Missions, Médiathèque) et les onglets
 * libres créés par l'admin. Tout est renommable (FR + EN), réordonnable
 * (glisser-déposer ou flèches), activable/désactivable, ET supprimable —
 * il n'y a plus de section "figée" à part.
 *
 * Deux garde-fous techniques, pas de contenu :
 *  - on ne peut pas supprimer ni désactiver le tout dernier onglet visible
 *    (sinon le site public n'aurait plus rien à afficher) ;
 *  - un onglet "système" (accueil/fondatrice/contact/module) supprimé peut
 *    toujours être restauré depuis ses réglages par défaut — son code
 *    reste ; un onglet "espace libre" supprimé, lui, est bien parti pour
 *    de bon, comme n'importe quel contenu libre.
 *
 * Toute modification est poussée vers le backend partagé (setSpacesRemote,
 * fonction Netlify `setSpaces`) donc visible par tous les visiteurs, pas
 * seulement sur cet appareil — voir cmsService.ts.
 */
export default function EspacesPanel({ actorEmail }: { actorEmail: string }) {
  const [spaces, setSpaces] = useState<Space[] | null>(null);
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newTab, setNewTab] = useState<{
    title: string;
    titleEn: string;
    body: string;
    bodyEn: string;
    images: string;
  } | null>(null);

  useEffect(() => subscribeSpaces(setSpaces), []);

  if (!isBackendConfigured()) {
    return (
      <div className="rounded-lg border border-gold-warm/40 bg-gold-warm/10 p-4 text-sm text-charcoal">
        <p className="font-semibold">Backend non configuré</p>
        <p className="mt-1 text-charcoal/70">
          Renseignez <code className="rounded bg-white/60 px-1">VITE_API_BASE_URL</code> dans{" "}
          <code className="rounded bg-white/60 px-1">.env</code> pour que les changements d'espaces s'appliquent
          chez tous les visiteurs.
        </p>
      </div>
    );
  }

  if (!spaces) return <p className="text-sm text-charcoal/50">Chargement…</p>;

  async function persist(next: Space[]) {
    setSpaces(next);
    setSaving(true);
    setError(null);
    try {
      await setSpacesRemote(actorEmail, next);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur inconnue.");
    } finally {
      setSaving(false);
    }
  }

  function move(index: number, direction: -1 | 1) {
    const target = index + direction;
    if (!spaces || target < 0 || target >= spaces.length) return;
    const next = [...spaces];
    [next[index], next[target]] = [next[target], next[index]];
    void persist(next);
  }

  function handleDrop(index: number) {
    if (dragIndex === null || dragIndex === index || !spaces) return;
    const next = [...spaces];
    const [moved] = next.splice(dragIndex, 1);
    next.splice(index, 0, moved);
    setDragIndex(null);
    void persist(next);
  }

  const visibleCount = (spaces ?? []).filter((s) => s.enabled).length;

  function toggleEnabled(id: string) {
    if (!spaces) return;
    const target = spaces.find((s) => s.id === id);
    // Floor: never let the public nav end up with zero visible tabs.
    if (target?.enabled && visibleCount <= 1) {
      setError("Impossible de désactiver le dernier onglet encore visible — le site public doit toujours en garder au moins un.");
      return;
    }
    void persist(spaces.map((s) => (s.id === id ? { ...s, enabled: !s.enabled } : s)));
  }

  function updateTitle(id: string, title: string) {
    if (!spaces) return;
    setSpaces(spaces.map((s) => (s.id === id ? { ...s, title } : s)));
  }

  function updateTitleEn(id: string, titleEn: string) {
    if (!spaces) return;
    setSpaces(spaces.map((s) => (s.id === id ? { ...s, titleEn } : s)));
  }

  function commitTitle() {
    if (spaces) void persist(spaces);
    setEditingId(null);
  }

  function deleteSpace(id: string) {
    if (!spaces) return;
    if (spaces.length <= 1) {
      setError("Impossible de supprimer le dernier onglet — le site public doit toujours en garder au moins un.");
      return;
    }
    void persist(spaces.filter((s) => s.id !== id));
  }

  function restoreDefault(id: string) {
    if (!spaces) return;
    const fallback = DEFAULT_SPACES.find((d) => d.id === id);
    if (!fallback) return;
    void persist([...spaces, fallback]);
  }

  function addCustomTab(e: FormEvent) {
    e.preventDefault();
    if (!spaces || !newTab || !newTab.title.trim()) return;
    const id = `custom-${Date.now().toString(36)}`;
    const images = newTab.images
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);
    const space: Space = {
      id,
      kind: "custom",
      enabled: true,
      title: newTab.title.trim(),
      titleEn: newTab.titleEn.trim() || undefined,
      body: newTab.body.trim() || undefined,
      bodyEn: newTab.bodyEn.trim() || undefined,
      images: images.length > 0 ? images : undefined,
    };
    void persist([...spaces, space]);
    setNewTab(null);
  }

  function updateCustomContent(id: string, patch: Partial<Space>) {
    if (!spaces) return;
    void persist(spaces.map((s) => (s.id === id ? { ...s, ...patch } : s)));
  }

  // System tabs (accueil/fondatrice/contact/module) an admin has deleted —
  // still restorable, since their feature code never went anywhere.
  const restorable = DEFAULT_SPACES.filter((d) => !spaces!.some((s) => s.id === d.id));

  return (
    <div className="flex flex-col gap-4">
      <p className="text-xs text-charcoal/50 leading-relaxed">
        Tous les onglets — Accueil, Fondatrice, Contact, les 4 modules et vos espaces libres — vivent dans une seule
        liste : glissez-déposez ou utilisez les flèches pour réordonner, cliquez un titre pour le renommer (FR + EN),
        activez/désactivez, ou supprimez. Un onglet système supprimé (badge « onglet système » / « module intégré »)
        reste restaurable ci-dessous ; un « espace libre » supprimé est définitivement parti. Le site public garde
        toujours au moins un onglet visible.
      </p>

      {error && <p className="rounded-md bg-red-50 px-3 py-2 text-xs text-red-600">{error}</p>}
      {saving && <p className="text-xs text-charcoal/40">Enregistrement…</p>}

      <ul className="flex flex-col gap-2">
        {spaces.map((space, index) => (
          <li
            key={space.id}
            draggable
            onDragStart={() => setDragIndex(index)}
            onDragOver={(e: DragEvent) => e.preventDefault()}
            onDrop={() => handleDrop(index)}
            className="rounded-lg border border-slate-light bg-white p-3"
          >
            <div className="flex items-center gap-2">
              <span aria-hidden="true" className="text-charcoal/30 cursor-grab">
                ⠿
              </span>

              {editingId === space.id ? (
                <div className="flex flex-1 flex-col gap-1">
                  <input
                    autoFocus
                    value={space.title}
                    onChange={(e) => updateTitle(space.id, e.target.value)}
                    onBlur={commitTitle}
                    onKeyDown={(e) => e.key === "Enter" && commitTitle()}
                    placeholder="Titre (français)"
                    className="w-full rounded-md border border-slate-light px-2 py-1 text-sm"
                  />
                  <input
                    value={space.titleEn ?? ""}
                    onChange={(e) => updateTitleEn(space.id, e.target.value)}
                    onBlur={commitTitle}
                    onKeyDown={(e) => e.key === "Enter" && commitTitle()}
                    placeholder="Title (English) — laisser vide pour reprendre le français"
                    className="w-full rounded-md border border-slate-light px-2 py-1 text-sm text-charcoal/70"
                  />
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setEditingId(space.id)}
                  className="flex-1 truncate text-left text-sm font-medium text-charcoal"
                  title="Cliquer pour renommer (FR + EN)"
                >
                  {space.title}
                  {space.titleEn && space.titleEn.trim() && (
                    <span className="ml-1.5 text-xs font-normal text-charcoal/40">/ {space.titleEn}</span>
                  )}
                  <span className="ml-1.5 rounded-full bg-slate-light px-1.5 py-0.5 text-[10px] font-normal text-charcoal/50">
                    {KIND_BADGE[space.kind]}
                  </span>
                </button>
              )}

              <button
                type="button"
                onClick={() => toggleEnabled(space.id)}
                className={`flex-none rounded-full px-2.5 py-1 text-[11px] font-semibold ${
                  space.enabled ? "bg-emerald/10 text-emerald" : "bg-slate-light text-charcoal/40"
                }`}
              >
                {space.enabled ? "Activé" : "Désactivé"}
              </button>

              <button
                type="button"
                onClick={() => move(index, -1)}
                disabled={index === 0}
                aria-label="Monter"
                className="flex h-7 w-7 flex-none items-center justify-center rounded-full text-charcoal/60 hover:bg-slate-light disabled:opacity-30"
              >
                ↑
              </button>
              <button
                type="button"
                onClick={() => move(index, 1)}
                disabled={index === spaces.length - 1}
                aria-label="Descendre"
                className="flex h-7 w-7 flex-none items-center justify-center rounded-full text-charcoal/60 hover:bg-slate-light disabled:opacity-30"
              >
                ↓
              </button>

              <button
                type="button"
                onClick={() => deleteSpace(space.id)}
                aria-label="Supprimer"
                title={
                  space.kind === "custom"
                    ? "Supprimer définitivement"
                    : "Supprimer (restaurable plus bas)"
                }
                className="flex h-7 w-7 flex-none items-center justify-center rounded-full text-red-500 hover:bg-red-50"
              >
                ✕
              </button>
            </div>

            {space.kind === "custom" && (
              <div className="mt-2 flex flex-col gap-2 border-t border-slate-light pt-2">
                <textarea
                  defaultValue={space.body ?? ""}
                  onBlur={(e) => updateCustomContent(space.id, { body: e.target.value.trim() || undefined })}
                  placeholder="Texte de l'onglet (français)…"
                  rows={3}
                  className="w-full rounded-md border border-slate-light px-2 py-1.5 text-xs text-charcoal"
                />
                <textarea
                  defaultValue={space.bodyEn ?? ""}
                  onBlur={(e) => updateCustomContent(space.id, { bodyEn: e.target.value.trim() || undefined })}
                  placeholder="Tab text (English) — laisser vide pour reprendre le français…"
                  rows={3}
                  className="w-full rounded-md border border-slate-light px-2 py-1.5 text-xs text-charcoal/70"
                />
                <textarea
                  defaultValue={(space.images ?? []).join("\n")}
                  onBlur={(e) =>
                    updateCustomContent(space.id, {
                      images: e.target.value
                        .split("\n")
                        .map((s) => s.trim())
                        .filter(Boolean),
                    })
                  }
                  placeholder="URLs d'images, une par ligne (optionnel)…"
                  rows={2}
                  className="w-full rounded-md border border-slate-light px-2 py-1.5 text-xs text-charcoal"
                />
              </div>
            )}
          </li>
        ))}
      </ul>

      {restorable.length > 0 && (
        <div className="flex flex-col gap-2 rounded-lg border border-dashed border-slate-light p-3">
          <p className="text-xs font-semibold text-charcoal/60">Onglets système supprimés — les restaurer :</p>
          <div className="flex flex-wrap gap-2">
            {restorable.map((d) => (
              <button
                key={d.id}
                type="button"
                onClick={() => restoreDefault(d.id)}
                className="rounded-full border border-ocean-deep/40 px-3 py-1 text-xs font-semibold text-ocean-deep hover:bg-ocean-deep/5"
              >
                + Restaurer « {d.title} »
              </button>
            ))}
          </div>
        </div>
      )}

      {newTab ? (
        <form onSubmit={addCustomTab} className="flex flex-col gap-2 rounded-lg border border-dashed border-ocean-deep/40 p-3">
          <input
            autoFocus
            required
            placeholder="Titre du nouvel onglet (français)"
            value={newTab.title}
            onChange={(e) => setNewTab({ ...newTab, title: e.target.value })}
            className="w-full rounded-md border border-slate-light px-2 py-1.5 text-sm"
          />
          <input
            placeholder="Tab title (English) — laisser vide pour reprendre le français"
            value={newTab.titleEn}
            onChange={(e) => setNewTab({ ...newTab, titleEn: e.target.value })}
            className="w-full rounded-md border border-slate-light px-2 py-1.5 text-sm text-charcoal/70"
          />
          <textarea
            placeholder="Texte de l'onglet (français)…"
            rows={3}
            value={newTab.body}
            onChange={(e) => setNewTab({ ...newTab, body: e.target.value })}
            className="w-full rounded-md border border-slate-light px-2 py-1.5 text-xs"
          />
          <textarea
            placeholder="Tab text (English) — laisser vide pour reprendre le français…"
            rows={3}
            value={newTab.bodyEn}
            onChange={(e) => setNewTab({ ...newTab, bodyEn: e.target.value })}
            className="w-full rounded-md border border-slate-light px-2 py-1.5 text-xs text-charcoal/70"
          />
          <textarea
            placeholder="URLs d'images, une par ligne (optionnel)…"
            rows={2}
            value={newTab.images}
            onChange={(e) => setNewTab({ ...newTab, images: e.target.value })}
            className="w-full rounded-md border border-slate-light px-2 py-1.5 text-xs"
          />
          <div className="flex gap-2">
            <button type="submit" className="btn-sheen rounded bg-ocean-deep px-3 py-1.5 text-xs font-semibold text-white">
              Créer l'onglet
            </button>
            <button
              type="button"
              onClick={() => setNewTab(null)}
              className="rounded-full border border-slate-light px-3 py-1.5 text-xs font-semibold text-charcoal/60"
            >
              Annuler
            </button>
          </div>
        </form>
      ) : (
        <button
          type="button"
          onClick={() => setNewTab({ title: "", titleEn: "", body: "", bodyEn: "", images: "" })}
          className="self-start rounded-full border border-ocean-deep px-3 py-1.5 text-xs font-semibold text-ocean-deep"
        >
          + Nouvel onglet libre
        </button>
      )}
    </div>
  );
}
