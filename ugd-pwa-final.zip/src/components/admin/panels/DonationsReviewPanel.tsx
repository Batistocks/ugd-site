import { useEffect, useState } from "react";
import { fetchDonations, verifyDonation, isBackendConfigured, type DonationRecord } from "../../../services/donationsAdminApi";
import { recordAuditEvent } from "../../../services/auditLog";
import { useLanguage } from "../../../i18n/LanguageContext";
import { normalizeWhatsappNumber } from "../../../services/whatsappLinks";

const KIND_LABEL_KEYS: Record<DonationRecord["kind"], string> = {
  don: "reviewPanel.kindDon",
  sponsoring: "reviewPanel.kindSponsoring",
  billet: "reviewPanel.kindBillet",
};

/** Opens the admin's own email app, prefilled — nothing sent by the server (see verifyDonation.js's file header). */
function buildMailtoLink(item: DonationRecord, lang: "fr" | "en"): string | null {
  if (!item.email || !item.receiptPdfUrl) return null;
  const subject = lang === "en" ? `Your final receipt — ${item.receiptId}` : `Votre reçu définitif — ${item.receiptId}`;
  const body =
    lang === "en"
      ? `Hello ${item.donorName},\n\nThank you for supporting AISBL UN GESTE DIVIN. Your final receipt is available here:\n${item.receiptPdfUrl}\n\nReference: ${item.receiptId}\n\n— The UN GESTE DIVIN team`
      : `Bonjour ${item.donorName},\n\nMerci pour votre soutien à l'AISBL UN GESTE DIVIN. Votre reçu définitif est disponible ici :\n${item.receiptPdfUrl}\n\nRéférence : ${item.receiptId}\n\n— L'équipe UN GESTE DIVIN`;
  return `mailto:${item.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

/**
 * Opens WhatsApp prefilled with a message containing the receipt link —
 * no phone number in the URL on purpose (the donation form doesn't
 * collect one): this opens WhatsApp's own contact picker so the admin
 * chooses who to send it to, rather than failing silently.
 */
function buildWhatsappShareLink(item: DonationRecord, lang: "fr" | "en"): string | null {
  if (!item.receiptPdfUrl) return null;
  const message =
    lang === "en"
      ? `Hello ${item.donorName}, here is your final receipt for ${item.amount} ${item.currency} (ref. ${item.receiptId}):\n${item.receiptPdfUrl}`
      : `Bonjour ${item.donorName}, voici votre reçu définitif pour ${item.amount} ${item.currency} (réf. ${item.receiptId}) :\n${item.receiptPdfUrl}`;
  return `${whatsappBase(item)}?text=${encodeURIComponent(message)}`;
}

/**
 * wa.me base URL: opens the buyer's chat directly when they gave a WhatsApp
 * number with its country code (gala tickets), otherwise WhatsApp's own
 * contact picker so the admin chooses who to send to.
 */
function whatsappBase(item: DonationRecord): string {
  const digits = normalizeWhatsappNumber(item.phone);
  return digits ? `https://wa.me/${digits}` : "https://wa.me/";
}

/** Gala ticket (verified): the message carries the badge link + the final receipt link. */
function ticketMessage(item: DonationRecord, lang: "fr" | "en"): string {
  const ticket = item.ticketName ? ` (${item.ticketName})` : "";
  return lang === "en"
    ? `Hello ${item.donorName},\n\nYour payment is confirmed. Here is your gala ticket${ticket} — show the QR code at the entrance:\n${item.badgePdfUrl}\n\nYour final receipt:\n${item.receiptPdfUrl}\n\nReference: ${item.receiptId}\n\n— The UN GESTE DIVIN team`
    : `Bonjour ${item.donorName},\n\nVotre paiement est confirmé. Voici votre ticket pour la soirée de gala${ticket} — présentez le code QR à l'entrée :\n${item.badgePdfUrl}\n\nVotre reçu définitif :\n${item.receiptPdfUrl}\n\nRéférence : ${item.receiptId}\n\n— L'équipe UN GESTE DIVIN`;
}

function buildBadgeMailto(item: DonationRecord, lang: "fr" | "en"): string | null {
  if (!item.email || !item.badgePdfUrl || !item.receiptPdfUrl) return null;
  const subject = lang === "en" ? `Your gala ticket — ${item.receiptId}` : `Votre ticket de gala — ${item.receiptId}`;
  return `mailto:${item.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(ticketMessage(item, lang))}`;
}

function buildBadgeWhatsapp(item: DonationRecord, lang: "fr" | "en"): string | null {
  if (!item.badgePdfUrl || !item.receiptPdfUrl) return null;
  return `${whatsappBase(item)}?text=${encodeURIComponent(ticketMessage(item, lang))}`;
}

/**
 * Dons & sponsorings à vérifier — Backend & Admin Review.
 *
 * Talks to the two admin-protected Netlify Functions (see
 * src/services/donationsAdminApi.ts):
 *  - listDonations  : pulls the queue submitted by DonationProofForm.tsx
 *                     via the offline sync queue (submitProof function).
 *  - verifyDonation : regenerates the receipt as a definitive PDF
 *                     ("REÇU DÉFINITIF") and stores it — no automatic
 *                     send. The association
 *                     wants full manual control over delivery: once
 *                     verified, this panel offers a ready-to-send e-mail
 *                     draft (opens the admin's own mail app) and a
 *                     ready-to-send WhatsApp message (opens WhatsApp's
 *                     contact picker) — same PDF link either way, the
 *                     admin picks one and sends it themselves.
 *
 * Gala tickets (kind "billet") go one step further: verifying also creates
 * the access badge (PDF with QR code). The "Vérifiés" list then offers ONE
 * message carrying the badge + the receipt — by e-mail, or by WhatsApp
 * straight to the buyer's chat when they gave their number (otherwise via
 * WhatsApp's contact picker). Sponsoring and donations: receipt only.
 */
export default function DonationsReviewPanel({ actorEmail }: { actorEmail: string }) {
  const { lang, t } = useLanguage();
  const dateLocale = lang === "en" ? "en-GB" : "fr-BE";
  const [filter, setFilter] = useState<"en_attente" | "verifie">("en_attente");
  const [items, setItems] = useState<DonationRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);

  function formatDate(ms: number | null): string {
    if (!ms) return "—";
    return new Date(ms).toLocaleString(dateLocale);
  }

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchDonations(filter);
      setItems(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : t("reviewPanel.unknownError"));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  async function handleVerify(item: DonationRecord) {
    setBusyId(item.receiptId);
    setNote(null);
    try {
      await verifyDonation(item.receiptId);
      await recordAuditEvent(
        actorEmail,
        "donation-verified",
        `${item.receiptId} — ${item.donorName} (${item.amount} ${item.currency})`,
      );
      setNote(item.kind === "billet" ? t("reviewPanel.ticketReady") : t("reviewPanel.receiptReady"));
      // Jump to the "Vérifiés" list: that is where the send buttons
      // (receipt, and badge for a gala ticket) are.
      setFilter("verifie");
    } catch (err) {
      setError(err instanceof Error ? err.message : t("reviewPanel.verifyFailed"));
    } finally {
      setBusyId(null);
    }
  }

  async function handleGenerateBadge(item: DonationRecord) {
    setBusyId(item.receiptId);
    setNote(null);
    setError(null);
    try {
      const data = await verifyDonation(item.receiptId);
      setItems((prev) => prev.map((d) => (d.receiptId === item.receiptId ? { ...d, badgePdfUrl: data.badgePdfUrl } : d)));
    } catch (err) {
      setError(err instanceof Error ? err.message : t("reviewPanel.badgeFailed"));
    } finally {
      setBusyId(null);
    }
  }

  if (!isBackendConfigured()) {
    return (
      <div className="rounded-lg border border-gold-warm/40 bg-gold-warm/10 p-4 text-sm text-charcoal">
        <p className="font-semibold">{t("reviewPanel.backendNotConfigured")}</p>
        <p className="mt-1 text-charcoal/70">
          {t("reviewPanel.backendHint1")} <code className="rounded bg-white/60 px-1">VITE_API_BASE_URL</code>{" "}
          {t("reviewPanel.backendHint2")} <code className="rounded bg-white/60 px-1">.env</code>{" "}
          {t("reviewPanel.backendHint3")}
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between gap-2">
        <div className="flex gap-1">
          {(["en_attente", "verifie"] as const).map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setFilter(f)}
              className={`rounded-full px-3 py-1.5 text-xs font-semibold ${
                filter === f ? "bg-ocean-deep text-white" : "bg-white text-charcoal/60 border border-slate-light"
              }`}
            >
              {f === "en_attente" ? t("reviewPanel.filterPending") : t("reviewPanel.filterVerified")}
            </button>
          ))}
        </div>
        <button
          type="button"
          onClick={() => void load()}
          className="rounded-full border border-slate-light px-3 py-1.5 text-xs font-semibold text-charcoal/70"
        >
          {loading ? t("reviewPanel.refreshing") : t("reviewPanel.refresh")}
        </button>
      </div>

      {note && <p className="rounded-md bg-emerald/10 px-3 py-2 text-xs text-emerald">{note}</p>}
      {error && <p className="rounded-md bg-red-50 px-3 py-2 text-xs text-red-600">{error}</p>}

      {!loading && items.length === 0 && (
        <p className="text-sm text-charcoal/50">
          {filter === "en_attente" ? t("reviewPanel.noPending") : t("reviewPanel.noVerified")}
        </p>
      )}

      <ul className="flex flex-col gap-3">
        {items.map((item) => {
          const isTicket = item.kind === "billet";
          // A gala ticket is sent as ONE message (badge + receipt); the other
          // kinds keep the receipt-only drafts.
          const mailtoLink = isTicket ? buildBadgeMailto(item, lang) : buildMailtoLink(item, lang);
          const whatsappLink = isTicket ? buildBadgeWhatsapp(item, lang) : buildWhatsappShareLink(item, lang);
          const sendEmailLabel = isTicket ? t("reviewPanel.sendBadgeByEmail") : t("reviewPanel.sendByEmail");
          const sendWhatsappLabel = isTicket ? t("reviewPanel.sendBadgeByWhatsapp") : t("reviewPanel.sendByWhatsapp");
          return (
            <li key={item.receiptId} className="rounded-lg border border-slate-light bg-white p-3">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-sm font-semibold text-charcoal">
                    {item.donorName} — {item.amount} {item.currency}
                  </p>
                  <p className="text-xs text-charcoal/60">
                    {t(KIND_LABEL_KEYS[item.kind])} · {item.context} · {item.method ?? t("reviewPanel.unknownMethod")}
                  </p>
                  <p className="mt-1 text-[11px] text-charcoal/40">
                    {lang === "en" ? "Ref." : "Réf."} {item.receiptId} · {formatDate(item.createdAt)}
                    {item.email && <> · {item.email}</>}
                    {item.phone && <> · {item.phone}</>}
                  </p>
                </div>
                {item.status === "en_attente" ? (
                  <button
                    type="button"
                    disabled={busyId === item.receiptId}
                    onClick={() => void handleVerify(item)}
                    className="btn-sheen flex-none rounded bg-emerald px-3 py-1.5 text-xs font-semibold text-white shadow-emeraldGlow disabled:opacity-60 disabled:shadow-none"
                  >
                    {busyId === item.receiptId ? "…" : t("reviewPanel.markVerified")}
                  </button>
                ) : (
                  <span className="flex flex-none flex-col items-end gap-1">
                    <span className="rounded-full bg-emerald/10 px-3 py-1.5 text-xs font-semibold text-emerald">
                      {t("reviewPanel.verified")}
                    </span>
                    {isTicket && item.checkedIn && (
                      <span className="rounded-full bg-ocean-deep/10 px-2.5 py-1 text-[11px] font-semibold text-ocean-deep">
                        {t("reviewPanel.checkedInTag")}
                      </span>
                    )}
                  </span>
                )}
              </div>

              <div className="mt-2 flex flex-wrap gap-2 text-xs">
                {item.proofUrl && (
                  <a
                    href={item.proofUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="rounded-full border border-slate-light px-2.5 py-1 text-ocean-deep"
                  >
                    {t("reviewPanel.viewProof")}
                  </a>
                )}
                {item.receiptPdfUrl && (
                  <a
                    href={item.receiptPdfUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="rounded-full border border-slate-light px-2.5 py-1 text-ocean-deep"
                  >
                    {t("reviewPanel.definitiveReceipt")}
                  </a>
                )}
                {isTicket && item.badgePdfUrl && (
                  <a
                    href={item.badgePdfUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="rounded-full border border-slate-light px-2.5 py-1 text-ocean-deep"
                  >
                    {t("reviewPanel.badgePdf")}
                  </a>
                )}
                {isTicket && item.status === "verifie" && !item.badgePdfUrl && (
                  <button
                    type="button"
                    disabled={busyId === item.receiptId}
                    onClick={() => void handleGenerateBadge(item)}
                    className="rounded-full border border-gold-warm/60 px-2.5 py-1 text-gold-warm disabled:opacity-60"
                  >
                    {busyId === item.receiptId ? "…" : t("reviewPanel.generateBadge")}
                  </button>
                )}
                {mailtoLink && (
                  <a href={mailtoLink} className="rounded-full border border-ocean-deep/40 px-2.5 py-1 text-ocean-deep">
                    {sendEmailLabel}
                  </a>
                )}
                {whatsappLink && (
                  <a
                    href={whatsappLink}
                    target="_blank"
                    rel="noreferrer"
                    className="rounded-full border border-whatsapp/50 px-2.5 py-1 text-whatsapp"
                  >
                    {sendWhatsappLabel}
                  </a>
                )}
              </div>

              {item.proofUrl && /\.(png|jpe?g|webp|gif)(\?|$)/i.test(item.proofUrl) && (
                <img
                  src={item.proofUrl}
                  alt={`Proof of transfer — ${item.receiptId}`}
                  className="mt-2 max-h-48 rounded-md border border-slate-light object-contain"
                />
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
