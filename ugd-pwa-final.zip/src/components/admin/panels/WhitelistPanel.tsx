import { useEffect, useState, type FormEvent } from "react";
import { addAdmin, listAdmins, removeAdmin, type AdminListItem } from "../../../services/authService";
import { useLanguage } from "../../../i18n/LanguageContext";

const inputCls =
  "w-full rounded-lg border border-slate-light px-3 py-2 text-sm text-charcoal placeholder:text-charcoal/40 focus:border-ocean-deep focus:outline-none";

/**
 * Shared Team Whitelist Manager.
 *
 * The list lives in Firestore (`admins` collection, one document per
 * email — see services/authService.ts), so it's the same list for every
 * teammate, on every device. Every listed email has EQUAL FULL ACCESS:
 * any admin can add or remove any other admin (there are no
 * "super admins"). The app blocks removing the very last account so the
 * panel can't be locked out from within the app; if the list is ever
 * emptied out from outside the app, the site owner can always add
 * someone back directly in the Firebase console (Firestore → `admins`).
 */
export default function WhitelistPanel({ actorEmail }: { actorEmail: string }) {
  const { lang, t } = useLanguage();
  const [admins, setAdmins] = useState<AdminListItem[] | null>(null);
  const [newEmail, setNewEmail] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function refresh() {
    setAdmins(await listAdmins());
  }

  useEffect(() => {
    refresh();
  }, []);

  async function handleAdd(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await addAdmin(actorEmail, newEmail);
      setNewEmail("");
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("whitelistPanel.error"));
    } finally {
      setBusy(false);
    }
  }

  async function handleRemove(email: string) {
    setError(null);
    try {
      await removeAdmin(actorEmail, email);
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("whitelistPanel.error"));
    }
  }

  if (!admins) return <p className="text-sm text-charcoal/50">{t("admin.loading")}</p>;

  return (
    <div className="flex flex-col gap-4">
      <p className="text-xs text-charcoal/50 leading-relaxed">{t("whitelistPanel.hint")}</p>

      <ul className="flex flex-col gap-2">
        {admins.map((admin) => (
          <li
            key={admin.email}
            className="flex items-center justify-between gap-2 rounded-lg border border-slate-light px-3 py-2.5"
          >
            <div className="min-w-0">
              <p className="truncate text-sm font-medium text-charcoal">
                {admin.email}
                {admin.email === actorEmail && (
                  <span className="ml-1.5 rounded-full bg-emerald/15 px-2 py-0.5 text-[10px] font-semibold text-emerald">
                    {t("whitelistPanel.you")}
                  </span>
                )}
              </p>
              <p className="text-[11px] text-charcoal/40">
                {t("whitelistPanel.addedOn")} {new Date(admin.createdAt).toLocaleDateString(lang === "en" ? "en-GB" : "fr-BE")} {t("whitelistPanel.by")} {admin.createdBy}
              </p>
            </div>
            <button
              type="button"
              onClick={() => handleRemove(admin.email)}
              disabled={admins.length <= 1}
              className="flex-none rounded-full px-3 py-1.5 text-xs font-semibold text-red-600 hover:bg-red-50 disabled:opacity-30"
            >
              {t("whitelistPanel.remove")}
            </button>
          </li>
        ))}
      </ul>

      <form onSubmit={handleAdd} className="flex flex-col gap-2 rounded-lg bg-slate-light/60 p-3">
        <p className="text-xs font-semibold text-charcoal/60">{t("whitelistPanel.addTitle")}</p>
        <input
          required
          type="email"
          placeholder={t("whitelistPanel.emailPlaceholder")}
          value={newEmail}
          onChange={(e) => setNewEmail(e.target.value)}
          className={inputCls}
        />
        {error && <p className="text-xs text-red-600">{error}</p>}
        <button
          type="submit"
          disabled={busy}
          className="btn-sheen self-start rounded bg-ocean-deep px-4 py-2 text-xs font-semibold text-white disabled:opacity-60"
        >
          {busy ? t("whitelistPanel.adding") : t("whitelistPanel.add")}
        </button>
      </form>
    </div>
  );
}
