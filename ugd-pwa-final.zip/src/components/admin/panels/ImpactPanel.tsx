import { useEffect, useState, type FormEvent } from "react";
import {
  DEFAULT_IMPACT,
  setImpactRemote,
  subscribeImpact,
  type ImpactConfig,
} from "../../../services/cmsService";
import { isBackendConfigured } from "../../../services/donationsAdminApi";

const fieldCls = "w-full rounded-md border border-slate-light px-2.5 py-1.5 text-sm text-charcoal";

/**
 * Compteurs — les trois chiffres clés de la page d'accueil (pays
 * d'intervention, années d'engagement, actions terrain). Enregistrés dans
 * la même config partagée que le reste du CMS : la modification apparaît
 * chez tous les visiteurs.
 */
export default function ImpactPanel({ actorEmail }: { actorEmail: string }) {
  // Kept as strings while typing so the field can be emptied/retyped freely.
  const [values, setValues] = useState({
    countries: String(DEFAULT_IMPACT.countries),
    years: String(DEFAULT_IMPACT.years),
    actions: String(DEFAULT_IMPACT.actions),
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(
    () =>
      subscribeImpact((c: ImpactConfig) =>
        setValues({ countries: String(c.countries), years: String(c.years), actions: String(c.actions) }),
      ),
    [],
  );

  if (!isBackendConfigured()) {
    return (
      <div className="rounded-card border border-gold-warm/40 bg-gold-warm/10 p-4 text-sm text-charcoal">
        <p className="font-semibold">Backend non configuré</p>
        <p className="mt-1 text-charcoal/70">
          Renseignez <code className="rounded bg-white/60 px-1">VITE_API_BASE_URL</code> dans{" "}
          <code className="rounded bg-white/60 px-1">.env</code>.
        </p>
      </div>
    );
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSaved(false);
    try {
      const parsed = {
        countries: Number(values.countries),
        years: Number(values.years),
        actions: Number(values.actions),
      };
      if (Object.values(parsed).some((n) => !Number.isFinite(n) || n < 0)) {
        throw new Error("Chaque compteur doit être un nombre positif.");
      }
      await setImpactRemote(actorEmail, parsed);
      setSaved(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur inconnue.");
    } finally {
      setSaving(false);
    }
  }

  const field = (key: keyof typeof values, label: string) => (
    <label className="flex flex-col gap-1 text-xs font-semibold text-charcoal/60">
      {label}
      <input
        type="number"
        min="0"
        step="1"
        inputMode="numeric"
        required
        value={values[key]}
        onChange={(e) => {
          setSaved(false);
          setValues({ ...values, [key]: e.target.value });
        }}
        className={fieldCls}
      />
    </label>
  );

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      <p className="text-xs text-charcoal/50 leading-relaxed">
        Ces trois chiffres s'affichent en gras dans les compteurs de la page d'accueil. Les libellés (« Pays
        d'intervention », etc.) restent inchangés.
      </p>

      {error && <p className="rounded-md bg-red-50 px-3 py-2 text-xs text-red-600">{error}</p>}
      {saved && <p className="rounded-md bg-emerald/10 px-3 py-2 text-xs text-emerald">Compteurs enregistrés.</p>}

      {field("countries", "Pays d'intervention")}
      {field("years", "Années d'engagement")}
      {field("actions", "Actions terrain 2024")}

      <button
        type="submit"
        disabled={saving}
        className="rounded bg-ocean-deep px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-60"
      >
        {saving ? "Enregistrement…" : "Enregistrer les compteurs"}
      </button>
    </form>
  );
}
