import { useEffect, useState } from "react";
import { exportAuditLogCsv, exportCheckinsCsv, exportDatabaseJson } from "../../../services/exportService";
import { getAuditLog, subscribeAuditLog } from "../../../services/auditLog";
import type { AuditLogRecord } from "../../../services/db";
import { useLanguage } from "../../../i18n/LanguageContext";

const buttonCls =
  "btn-sheen rounded bg-ocean-deep px-3.5 py-2 text-xs font-semibold text-white disabled:opacity-60";

/** One-click Database Export (JSON/CSV) and audit logs. */
export default function ExportAuditPanel({ actorEmail }: { actorEmail: string }) {
  const { lang, t } = useLanguage();
  const [log, setLog] = useState<AuditLogRecord[]>([]);
  const [busy, setBusy] = useState<string | null>(null);

  async function refresh() {
    setLog(await getAuditLog(100));
  }

  useEffect(() => {
    refresh();
    return subscribeAuditLog(refresh);
  }, []);

  async function run(name: string, fn: () => Promise<void>) {
    setBusy(name);
    try {
      await fn();
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          disabled={busy !== null}
          onClick={() => run("json", () => exportDatabaseJson(actorEmail))}
          className={buttonCls}
        >
          {busy === "json" ? t("exportPanel.exporting") : t("exportPanel.exportJson")}
        </button>
        <button
          type="button"
          disabled={busy !== null}
          onClick={() => run("checkins", () => exportCheckinsCsv(actorEmail))}
          className={`${buttonCls} bg-emerald`}
        >
          {busy === "checkins" ? t("exportPanel.exporting") : t("exportPanel.exportCheckins")}
        </button>
        <button
          type="button"
          disabled={busy !== null}
          onClick={() => run("audit", () => exportAuditLogCsv(actorEmail))}
          className={`${buttonCls} bg-gold-warm`}
        >
          {busy === "audit" ? t("exportPanel.exporting") : t("exportPanel.exportAudit")}
        </button>
      </div>

      <div>
        <p className="mb-2 text-xs font-semibold text-charcoal/60">
          {t("exportPanel.auditLogTitle")} {log.length} {t("exportPanel.recentEntries")}
        </p>
        <ul className="flex max-h-72 flex-col gap-1.5 overflow-y-auto">
          {log.map((entry) => (
            <li key={entry.id} className="rounded-lg border border-slate-light px-3 py-2 text-xs">
              <p className="font-semibold text-charcoal">{entry.action}</p>
              <p className="text-charcoal/50">
                {new Date(entry.timestamp).toLocaleString(lang === "en" ? "en-GB" : "fr-BE")} · {entry.actorEmail}
              </p>
              {entry.details && <p className="mt-0.5 text-charcoal/60">{entry.details}</p>}
            </li>
          ))}
          {log.length === 0 && <p className="text-xs italic text-charcoal/40">{t("exportPanel.none")}</p>}
        </ul>
      </div>
    </div>
  );
}
