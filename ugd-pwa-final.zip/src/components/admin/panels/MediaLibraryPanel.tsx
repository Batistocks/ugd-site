import { useEffect, useState, type ChangeEvent, type FormEvent } from "react";
import {
  addMediaPhoto,
  addMediaVideo,
  getMediaPhotos,
  getMediaVideos,
  removeMediaPhoto,
  removeMediaVideo,
  reorderMediaPhotos,
  reorderMediaVideos,
  updateMediaPhoto,
  updateMediaVideo,
  type MediaPhotoItem,
  type MediaVideoItem,
} from "../../../services/cmsService";
import { isCloudinaryConfigured, uploadToCloudinary } from "../../../services/cloudinaryService";
import { compressImage, formatBytes } from "../../../services/imageCompression";
import { captureVideoThumbnail } from "../../../services/videoThumbnail";
import { isBackendConfigured } from "../../../services/donationsAdminApi";

const inputCls =
  "w-full rounded-lg border border-slate-light px-3 py-2 text-sm text-charcoal placeholder:text-charcoal/40 focus:border-ocean-deep focus:outline-none";

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

type SubTab = "photos" | "videos";

/**
 * Médiathèque — Photos & Vidéos manager. Section 5: Secret Admin Panel &
 * CMS Management.
 *
 * Same add-by-URL / upload-from-device / remove / reorder pattern as
 * FlyerMediaPanel.tsx, split into two sub-tabs (Photos, Vidéos). Bilingual
 * (FR/EN) fields, since the association keeps both languages on the
 * public Médiathèque (MediaLibrary.tsx) unlike newer admin-only tabs.
 * Changes made here appear immediately in the public Médiathèque via
 * subscribeMediaPhotos/subscribeMediaVideos.
 */
export default function MediaLibraryPanel({ actorEmail }: { actorEmail: string }) {
  const [subTab, setSubTab] = useState<SubTab>("photos");

  if (!isBackendConfigured()) {
    return (
      <div className="rounded-lg border border-gold-warm/40 bg-gold-warm/10 p-4 text-sm text-charcoal">
        <p className="font-semibold">Backend non configuré</p>
        <p className="mt-1 text-charcoal/70">
          Renseignez <code className="rounded bg-white/60 px-1">VITE_API_BASE_URL</code> dans{" "}
          <code className="rounded bg-white/60 px-1">.env</code> pour que les changements de la médiathèque
          s'appliquent chez tous les visiteurs.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <div role="tablist" className="flex border-b border-slate-light">
        {(
          [
            { id: "photos" as const, label: "Photos" },
            { id: "videos" as const, label: "Vidéos" },
          ]
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            role="tab"
            aria-selected={subTab === tab.id}
            onClick={() => setSubTab(tab.id)}
            className={`flex-1 border-b-2 py-2 text-xs font-semibold uppercase tracking-wide transition-colors ${
              subTab === tab.id
                ? "border-gold text-ocean-deep"
                : "border-transparent text-charcoal/45 hover:text-charcoal/70"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {subTab === "photos" ? <PhotosManager actorEmail={actorEmail} /> : <VideosManager actorEmail={actorEmail} />}
    </div>
  );
}

function PhotosManager({ actorEmail }: { actorEmail: string }) {
  const [photos, setPhotos] = useState<MediaPhotoItem[] | null>(null);
  const [newAlt, setNewAlt] = useState("");
  const [newAltEn, setNewAltEn] = useState("");
  const [newUrl, setNewUrl] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadPct, setUploadPct] = useState<number | null>(null);
  const [compressionNote, setCompressionNote] = useState<string | null>(null);
  const cloudinaryReady = isCloudinaryConfigured();

  async function refresh() {
    setPhotos(await getMediaPhotos());
  }

  useEffect(() => {
    refresh();
  }, []);

  async function handleFileAdd(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!newAlt.trim()) {
      setError("Ajoutez d'abord une légende (FR) avant de choisir un fichier.");
      return;
    }
    setBusy(true);
    setError(null);
    setUploadPct(cloudinaryReady ? 0 : null);
    try {
      const result = await compressImage(file);
      const toStore = result.file;
      setCompressionNote(
        result.compressedBytes < result.originalBytes
          ? `${formatBytes(result.originalBytes)} → ${formatBytes(result.compressedBytes)} (${result.width}×${result.height}px)`
          : null,
      );

      let src: string;
      if (cloudinaryReady) {
        const uploaded = await uploadToCloudinary(toStore, { folder: "mediatheque/photos", onProgress: setUploadPct });
        src = uploaded.secureUrl;
      } else {
        src = await fileToDataUrl(toStore);
      }
      await addMediaPhoto(actorEmail, { src, alt: newAlt.trim(), altEn: newAltEn.trim() || undefined });
      setNewAlt("");
      setNewAltEn("");
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Échec de l'ajout de la photo.");
    } finally {
      setBusy(false);
      setUploadPct(null);
    }
  }

  async function handleUrlAdd(e: FormEvent) {
    e.preventDefault();
    if (!newAlt.trim() || !newUrl.trim()) return;
    setBusy(true);
    setError(null);
    try {
      await addMediaPhoto(actorEmail, { src: newUrl.trim(), alt: newAlt.trim(), altEn: newAltEn.trim() || undefined });
      setNewAlt("");
      setNewAltEn("");
      setNewUrl("");
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Échec de l'ajout de la photo.");
    } finally {
      setBusy(false);
    }
  }

  async function handleRemove(id: string) {
    setError(null);
    try {
      await removeMediaPhoto(actorEmail, id);
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Échec de la suppression.");
    }
  }

  function handleFieldChange(id: string, patch: Partial<MediaPhotoItem>) {
    setPhotos((prev) => prev && prev.map((p) => (p.id === id ? { ...p, ...patch } : p)));
  }

  async function handleFieldBlur(id: string, patch: Partial<MediaPhotoItem>) {
    setError(null);
    try {
      await updateMediaPhoto(actorEmail, id, patch);
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Échec de la mise à jour.");
    }
  }

  async function move(index: number, direction: -1 | 1) {
    if (!photos) return;
    const target = index + direction;
    if (target < 0 || target >= photos.length) return;
    const ids = photos.map((p) => p.id);
    [ids[index], ids[target]] = [ids[target], ids[index]];
    setError(null);
    try {
      await reorderMediaPhotos(actorEmail, ids);
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Échec du réordonnancement.");
    }
  }

  if (!photos) return <p className="text-sm text-charcoal/50">Chargement…</p>;

  return (
    <div className="flex flex-col gap-4">
      <form onSubmit={handleUrlAdd} className="flex flex-col gap-2 rounded-lg bg-slate-light/60 p-3">
        <p className="text-xs font-semibold text-charcoal/60">Ajouter une photo</p>
        <input placeholder="Légende (FR)" value={newAlt} onChange={(e) => setNewAlt(e.target.value)} className={inputCls} />
        <input
          placeholder="Légende (EN) — optionnel"
          value={newAltEn}
          onChange={(e) => setNewAltEn(e.target.value)}
          className={inputCls}
        />
        <div className="flex gap-2">
          <input
            placeholder="URL (ex. Cloudinary) — ou choisir un fichier"
            value={newUrl}
            onChange={(e) => setNewUrl(e.target.value)}
            className={inputCls}
          />
          <button
            type="submit"
            disabled={busy || !newUrl.trim() || !newAlt.trim()}
            className="btn-sheen flex-none rounded bg-ocean-deep px-3 py-2 text-xs font-semibold text-white disabled:opacity-40"
          >
            Ajouter
          </button>
        </div>
        <label className="text-xs font-semibold text-emerald underline cursor-pointer self-start">
          ou téléverser un fichier depuis l'appareil
          <input type="file" accept="image/*" onChange={handleFileAdd} className="hidden" />
        </label>
        <p className="text-[11px] text-charcoal/40">
          {cloudinaryReady
            ? "Cloudinary connecté — les fichiers téléversés sont envoyés en HD vers Cloudinary."
            : "Cloudinary non configuré — les fichiers téléversés sont stockés localement (hors ligne)."}
        </p>
        {compressionNote && <p className="text-[11px] text-emerald">Photo compressée : {compressionNote}</p>}
        {uploadPct !== null && (
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-light">
            <div className="h-full rounded-full bg-emerald transition-[width]" style={{ width: `${uploadPct}%` }} />
          </div>
        )}
        {error && <p className="text-xs text-red-600">{error}</p>}
      </form>

      <ul className="flex flex-col gap-2">
        {photos.map((photo, index) => (
          <li key={photo.id} className="flex gap-3 rounded-lg border border-slate-light p-2.5">
            <img src={photo.src} alt="" className="h-16 w-16 flex-none rounded object-cover" />
            <div className="min-w-0 flex-1">
              <input
                value={photo.alt}
                onChange={(e) => handleFieldChange(photo.id, { alt: e.target.value })}
                onBlur={(e) => void handleFieldBlur(photo.id, { alt: e.target.value })}
                placeholder="Légende (FR)"
                className="w-full truncate rounded border border-transparent bg-transparent text-sm font-medium text-charcoal hover:border-slate-light focus:border-ocean-deep focus:outline-none"
              />
              <input
                value={photo.altEn ?? ""}
                onChange={(e) => handleFieldChange(photo.id, { altEn: e.target.value })}
                onBlur={(e) => void handleFieldBlur(photo.id, { altEn: e.target.value })}
                placeholder="Légende (EN)"
                className="w-full truncate rounded border border-transparent bg-transparent text-xs text-charcoal/60 hover:border-slate-light focus:border-ocean-deep focus:outline-none"
              />
            </div>
            <div className="flex flex-none flex-col gap-1">
              <button
                type="button"
                onClick={() => move(index, -1)}
                disabled={index === 0}
                aria-label="Monter"
                className="flex h-6 w-6 items-center justify-center rounded-full text-charcoal/50 hover:bg-slate-light disabled:opacity-30"
              >
                ↑
              </button>
              <button
                type="button"
                onClick={() => move(index, 1)}
                disabled={index === photos.length - 1}
                aria-label="Descendre"
                className="flex h-6 w-6 items-center justify-center rounded-full text-charcoal/50 hover:bg-slate-light disabled:opacity-30"
              >
                ↓
              </button>
              <button
                type="button"
                onClick={() => handleRemove(photo.id)}
                aria-label="Supprimer"
                className="flex h-6 w-6 items-center justify-center rounded-full text-red-500 hover:bg-red-50"
              >
                ✕
              </button>
            </div>
          </li>
        ))}
        {photos.length === 0 && <p className="text-xs text-charcoal/40 italic">Aucune photo pour le moment.</p>}
      </ul>
    </div>
  );
}

function VideosManager({ actorEmail }: { actorEmail: string }) {
  const [videos, setVideos] = useState<MediaVideoItem[] | null>(null);
  const [newTitle, setNewTitle] = useState("");
  const [newTitleEn, setNewTitleEn] = useState("");
  const [newUrl, setNewUrl] = useState("");
  const [newThumbnailUrl, setNewThumbnailUrl] = useState("");
  const [newDuration, setNewDuration] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadPct, setUploadPct] = useState<number | null>(null);
  const [statusNote, setStatusNote] = useState<string | null>(null);
  const cloudinaryReady = isCloudinaryConfigured();

  async function refresh() {
    setVideos(await getMediaVideos());
  }

  useEffect(() => {
    refresh();
  }, []);

  async function handleFileAdd(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!newTitle.trim()) {
      setError("Ajoutez d'abord un titre (FR) avant de choisir un fichier.");
      return;
    }
    setBusy(true);
    setError(null);
    setStatusNote(null);
    setUploadPct(cloudinaryReady ? 0 : null);
    try {
      // Capture the poster frame + duration client-side first, so the
      // video works in the playlist immediately — no separate thumbnail
      // upload step required from the admin.
      let thumbnailFile: File | null = null;
      let duration = "";
      try {
        const captured = await captureVideoThumbnail(file);
        thumbnailFile = captured.thumbnail;
        duration = captured.duration;
      } catch {
        setStatusNote("Vignette automatique indisponible pour ce fichier — ajoutez-la manuellement après coup si besoin.");
      }

      let src: string;
      let thumbnail = "";
      if (cloudinaryReady) {
        const uploaded = await uploadToCloudinary(file, { folder: "mediatheque/videos", onProgress: setUploadPct });
        src = uploaded.secureUrl;
        if (thumbnailFile) {
          const uploadedThumb = await uploadToCloudinary(thumbnailFile, { folder: "mediatheque/videos" });
          thumbnail = uploadedThumb.secureUrl;
        }
      } else {
        src = await fileToDataUrl(file);
        thumbnail = thumbnailFile ? await fileToDataUrl(thumbnailFile) : "";
      }

      await addMediaVideo(actorEmail, {
        src,
        thumbnail,
        title: newTitle.trim(),
        titleEn: newTitleEn.trim() || undefined,
        duration: duration || undefined,
      });
      setNewTitle("");
      setNewTitleEn("");
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Échec de l'ajout de la vidéo.");
    } finally {
      setBusy(false);
      setUploadPct(null);
    }
  }

  async function handleUrlAdd(e: FormEvent) {
    e.preventDefault();
    if (!newTitle.trim() || !newUrl.trim() || !newThumbnailUrl.trim()) return;
    setBusy(true);
    setError(null);
    try {
      await addMediaVideo(actorEmail, {
        src: newUrl.trim(),
        thumbnail: newThumbnailUrl.trim(),
        title: newTitle.trim(),
        titleEn: newTitleEn.trim() || undefined,
        duration: newDuration.trim() || undefined,
      });
      setNewTitle("");
      setNewTitleEn("");
      setNewUrl("");
      setNewThumbnailUrl("");
      setNewDuration("");
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Échec de l'ajout de la vidéo.");
    } finally {
      setBusy(false);
    }
  }

  async function handleRemove(id: string) {
    setError(null);
    try {
      await removeMediaVideo(actorEmail, id);
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Échec de la suppression.");
    }
  }

  function handleFieldChange(id: string, patch: Partial<MediaVideoItem>) {
    setVideos((prev) => prev && prev.map((v) => (v.id === id ? { ...v, ...patch } : v)));
  }

  async function handleFieldBlur(id: string, patch: Partial<MediaVideoItem>) {
    setError(null);
    try {
      await updateMediaVideo(actorEmail, id, patch);
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Échec de la mise à jour.");
    }
  }

  async function move(index: number, direction: -1 | 1) {
    if (!videos) return;
    const target = index + direction;
    if (target < 0 || target >= videos.length) return;
    const ids = videos.map((v) => v.id);
    [ids[index], ids[target]] = [ids[target], ids[index]];
    setError(null);
    try {
      await reorderMediaVideos(actorEmail, ids);
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Échec du réordonnancement.");
    }
  }

  if (!videos) return <p className="text-sm text-charcoal/50">Chargement…</p>;

  return (
    <div className="flex flex-col gap-4">
      <form onSubmit={handleUrlAdd} className="flex flex-col gap-2 rounded-lg bg-slate-light/60 p-3">
        <p className="text-xs font-semibold text-charcoal/60">Ajouter une vidéo</p>
        <input placeholder="Titre (FR)" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} className={inputCls} />
        <input
          placeholder="Titre (EN) — optionnel"
          value={newTitleEn}
          onChange={(e) => setNewTitleEn(e.target.value)}
          className={inputCls}
        />
        <label className="text-xs font-semibold text-emerald underline cursor-pointer self-start">
          Téléverser un fichier vidéo depuis l'appareil (vignette + durée générées automatiquement)
          <input type="file" accept="video/*" onChange={handleFileAdd} className="hidden" />
        </label>
        <p className="text-[11px] text-charcoal/40">— ou renseignez une vidéo déjà hébergée ailleurs —</p>
        <input
          placeholder="URL de la vidéo (ex. Cloudinary, .mp4)"
          value={newUrl}
          onChange={(e) => setNewUrl(e.target.value)}
          className={inputCls}
        />
        <input
          placeholder="URL de la vignette (image .jpg)"
          value={newThumbnailUrl}
          onChange={(e) => setNewThumbnailUrl(e.target.value)}
          className={inputCls}
        />
        <div className="flex gap-2">
          <input
            placeholder="Durée (ex. 0:47) — optionnel"
            value={newDuration}
            onChange={(e) => setNewDuration(e.target.value)}
            className={inputCls}
          />
          <button
            type="submit"
            disabled={busy || !newTitle.trim() || !newUrl.trim() || !newThumbnailUrl.trim()}
            className="btn-sheen flex-none rounded bg-ocean-deep px-3 py-2 text-xs font-semibold text-white disabled:opacity-40"
          >
            Ajouter
          </button>
        </div>
        <p className="text-[11px] text-charcoal/40">
          {cloudinaryReady
            ? "Cloudinary connecté — les fichiers téléversés sont envoyés vers Cloudinary."
            : "Cloudinary non configuré — les fichiers téléversés sont stockés localement (hors ligne, taille limitée)."}
        </p>
        {statusNote && <p className="text-[11px] text-gold-warm">{statusNote}</p>}
        {uploadPct !== null && (
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-light">
            <div className="h-full rounded-full bg-emerald transition-[width]" style={{ width: `${uploadPct}%` }} />
          </div>
        )}
        {error && <p className="text-xs text-red-600">{error}</p>}
      </form>

      <ul className="flex flex-col gap-2">
        {videos.map((video, index) => (
          <li key={video.id} className="flex gap-3 rounded-lg border border-slate-light p-2.5">
            {video.thumbnail ? (
              <img src={video.thumbnail} alt="" className="h-16 w-20 flex-none rounded object-cover" />
            ) : (
              <div className="flex h-16 w-20 flex-none items-center justify-center rounded bg-slate-light text-[10px] text-charcoal/40">
                pas de vignette
              </div>
            )}
            <div className="min-w-0 flex-1">
              <input
                value={video.title}
                onChange={(e) => handleFieldChange(video.id, { title: e.target.value })}
                onBlur={(e) => void handleFieldBlur(video.id, { title: e.target.value })}
                placeholder="Titre (FR)"
                className="w-full truncate rounded border border-transparent bg-transparent text-sm font-medium text-charcoal hover:border-slate-light focus:border-ocean-deep focus:outline-none"
              />
              <input
                value={video.titleEn ?? ""}
                onChange={(e) => handleFieldChange(video.id, { titleEn: e.target.value })}
                onBlur={(e) => void handleFieldBlur(video.id, { titleEn: e.target.value })}
                placeholder="Titre (EN)"
                className="w-full truncate rounded border border-transparent bg-transparent text-xs text-charcoal/60 hover:border-slate-light focus:border-ocean-deep focus:outline-none"
              />
              <input
                value={video.duration ?? ""}
                onChange={(e) => handleFieldChange(video.id, { duration: e.target.value })}
                onBlur={(e) => void handleFieldBlur(video.id, { duration: e.target.value })}
                placeholder="Durée (ex. 0:47)"
                className="w-20 rounded border border-transparent bg-transparent text-[11px] text-charcoal/40 hover:border-slate-light focus:border-ocean-deep focus:outline-none"
              />
            </div>
            <div className="flex flex-none flex-col gap-1">
              <button
                type="button"
                onClick={() => move(index, -1)}
                disabled={index === 0}
                aria-label="Monter"
                className="flex h-6 w-6 items-center justify-center rounded-full text-charcoal/50 hover:bg-slate-light disabled:opacity-30"
              >
                ↑
              </button>
              <button
                type="button"
                onClick={() => move(index, 1)}
                disabled={index === videos.length - 1}
                aria-label="Descendre"
                className="flex h-6 w-6 items-center justify-center rounded-full text-charcoal/50 hover:bg-slate-light disabled:opacity-30"
              >
                ↓
              </button>
              <button
                type="button"
                onClick={() => handleRemove(video.id)}
                aria-label="Supprimer"
                className="flex h-6 w-6 items-center justify-center rounded-full text-red-500 hover:bg-red-50"
              >
                ✕
              </button>
            </div>
          </li>
        ))}
        {videos.length === 0 && <p className="text-xs text-charcoal/40 italic">Aucune vidéo pour le moment.</p>}
      </ul>
    </div>
  );
}
