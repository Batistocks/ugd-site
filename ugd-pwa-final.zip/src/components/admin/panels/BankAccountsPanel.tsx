import { useEffect, useState, type DragEvent } from "react";
import {
  DEFAULT_MOBILE_MONEY,
  getBankOverrides,
  isConfirmedValue,
  setBankOverrides,
  type BankOverrides,
  type MobileMoneyProviderItem,
} from "../../../services/cmsService";
import { useLanguage } from "../../../i18n/LanguageContext";

const inputCls =
  "w-full rounded-lg border border-slate-light px-3 py-2 text-sm text-charcoal placeholder:text-charcoal/40 focus:border-ocean-deep focus:outline-none";

const PALETTE = ["#F59E0B", "#EF4444", "#EA580C", "#B89B55", "#0EA5E9", "#22C55E", "#8B5CF6", "#EC4899"];

/**
 * Bank/Mobile Money Account Editor.
 *
 * IBAN/BIC/titulaire restent une seule valeur (il n'y a qu'un compte
 * bancaire). La liste des opérateurs Mobile Money, elle, n'est plus figée
 * à 4 entrées (TMoney/Flooz/Orange Money/MTN) avec juste leur numéro
 * éditable : c'est maintenant une vraie liste — ajouter un nouvel
 * opérateur, renommer/recolorer/supprimer un existant, réordonner —
 * exactement le même modèle que les onglets (EspacesPanel) et les
 * documents (DocumentsPanel). Un opérateur "par défaut" supprimé reste
 * restaurable ; un opérateur ajouté par l'admin, une fois supprimé, est
 * définitivement parti.
 *
 * Les changements s'appliquent immédiatement à l'espace Dons public
 * (`PaymentAccountsPanel.tsx`) via `subscribeBankOverrides`.
 */
export default function BankAccountsPanel({ actorEmail }: { actorEmail: string }) {
  const { t } = useLanguage();
  const [draft, setDraft] = useState<BankOverrides | null>(null);
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getBankOverrides().then(setDraft);
  }, []);

  if (!draft) return <p className="text-sm text-charcoal/50">{t("admin.loading")}</p>;

  async function save(next: BankOverrides) {
    setDraft(next);
    setSaving(true);
    setError(null);
    try {
      await setBankOverrides(actorEmail, next);
      setSaved(true);
      window.setTimeout(() => setSaved(false), 1500);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur inconnue.");
    } finally {
      setSaving(false);
    }
  }

  function updateProviders(providers: MobileMoneyProviderItem[]) {
    if (!draft) return;
    setDraft({ ...draft, mobileMoneyProviders: providers });
  }

  function moveProvider(index: number, direction: -1 | 1) {
    if (!draft) return;
    const target = index + direction;
    if (target < 0 || target >= draft.mobileMoneyProviders.length) return;
    const next = [...draft.mobileMoneyProviders];
    [next[index], next[target]] = [next[target], next[index]];
    void save({ ...draft, mobileMoneyProviders: next });
  }

  function handleDrop(index: number) {
    if (dragIndex === null || dragIndex === index || !draft) return;
    const next = [...draft.mobileMoneyProviders];
    const [moved] = next.splice(dragIndex, 1);
    next.splice(index, 0, moved);
    setDragIndex(null);
    void save({ ...draft, mobileMoneyProviders: next });
  }

  function deleteProvider(id: string) {
    if (!draft) return;
    void save({ ...draft, mobileMoneyProviders: draft.mobileMoneyProviders.filter((p) => p.id !== id) });
  }

  function restoreDefault(id: string) {
    if (!draft) return;
    const fallback = DEFAULT_MOBILE_MONEY.find((p) => p.id === id);
    if (!fallback) return;
    void save({ ...draft, mobileMoneyProviders: [...draft.mobileMoneyProviders, fallback] });
  }

  function addProvider() {
    if (!draft) return;
    const id = `provider-${Date.now().toString(36)}`;
    const color = PALETTE[draft.mobileMoneyProviders.length % PALETTE.length];
    const provider: MobileMoneyProviderItem = { id, name: "Nouvel opérateur", color, value: "" };
    setDraft({ ...draft, mobileMoneyProviders: [...draft.mobileMoneyProviders, provider] });
    setEditingId(id);
  }

  const restorable = DEFAULT_MOBILE_MONEY.filter((p) => !draft.mobileMoneyProviders.some((d) => d.id === p.id));

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col gap-1.5">
        <label className="text-xs font-semibold text-charcoal/60">{t("bankPanel.accountHolder")}</label>
        <input
          value={draft.accountHolder}
          onChange={(e) => setDraft({ ...draft, accountHolder: e.target.value })}
          className={inputCls}
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-charcoal/60">
            IBAN {isConfirmedValue(draft.iban) && <span className="text-emerald">{t("bankPanel.confirmed")}</span>}
          </label>
          <input value={draft.iban} onChange={(e) => setDraft({ ...draft, iban: e.target.value })} className={inputCls} />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-charcoal/60">
            BIC / SWIFT {isConfirmedValue(draft.bic) && <span className="text-emerald">{t("bankPanel.confirmed")}</span>}
          </label>
          <input value={draft.bic} onChange={(e) => setDraft({ ...draft, bic: e.target.value })} className={inputCls} />
        </div>
      </div>

      <div>
        <div className="mb-2 flex items-center justify-between">
          <p className="text-xs font-semibold text-charcoal/60">{t("bankPanel.mobileMoneyTitle")}</p>
          <button type="button" onClick={addProvider} className="text-xs font-semibold text-ocean-deep underline underline-offset-2">
            + Nouvel opérateur
          </button>
        </div>
        <div className="flex flex-col gap-2">
          {draft.mobileMoneyProviders.map((provider, index) => (
            <div
              key={provider.id}
              draggable
              onDragStart={() => setDragIndex(index)}
              onDragOver={(e: DragEvent) => e.preventDefault()}
              onDrop={() => handleDrop(index)}
              className="flex items-center gap-2 rounded-lg border border-slate-light bg-white p-2"
            >
              <span aria-hidden="true" className="text-charcoal/30 cursor-grab">
                ⠿
              </span>
              <input
                type="color"
                value={provider.color}
                onChange={(e) =>
                  updateProviders(
                    draft.mobileMoneyProviders.map((p) => (p.id === provider.id ? { ...p, color: e.target.value } : p)),
                  )
                }
                className="h-6 w-6 flex-none cursor-pointer rounded-full border-0 bg-transparent p-0"
                aria-label="Couleur"
              />

              {editingId === provider.id ? (
                <div className="flex w-28 flex-none flex-col gap-1">
                  <input
                    autoFocus
                    value={provider.name}
                    onChange={(e) =>
                      updateProviders(
                        draft.mobileMoneyProviders.map((p) => (p.id === provider.id ? { ...p, name: e.target.value } : p)),
                      )
                    }
                    onBlur={() => save(draft)}
                    onKeyDown={(e) => e.key === "Enter" && save(draft)}
                    placeholder="Nom (FR)"
                    className="w-full rounded-md border border-slate-light px-1.5 py-1 text-xs"
                  />
                  <input
                    value={provider.nameEn ?? ""}
                    onChange={(e) =>
                      updateProviders(
                        draft.mobileMoneyProviders.map((p) => (p.id === provider.id ? { ...p, nameEn: e.target.value } : p)),
                      )
                    }
                    onBlur={() => save(draft)}
                    onKeyDown={(e) => e.key === "Enter" && save(draft)}
                    placeholder="Name (EN)"
                    className="w-full rounded-md border border-slate-light px-1.5 py-1 text-xs text-charcoal/60"
                  />
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setEditingId(provider.id)}
                  className="w-28 flex-none truncate text-left text-xs font-medium text-charcoal"
                  title="Cliquer pour renommer (FR + EN)"
                >
                  {provider.name}
                </button>
              )}

              <input
                value={provider.value}
                onChange={(e) =>
                  updateProviders(
                    draft.mobileMoneyProviders.map((p) => (p.id === provider.id ? { ...p, value: e.target.value } : p)),
                  )
                }
                onBlur={() => save(draft)}
                placeholder="Numéro"
                className={`flex-1 ${inputCls}`}
              />
              {isConfirmedValue(provider.value) && <span className="flex-none text-xs text-emerald">✓</span>}

              <button type="button" onClick={() => moveProvider(index, -1)} disabled={index === 0} aria-label="Monter" className="flex h-6 w-6 flex-none items-center justify-center rounded-full text-charcoal/50 hover:bg-slate-light disabled:opacity-30">
                ↑
              </button>
              <button type="button" onClick={() => moveProvider(index, 1)} disabled={index === draft.mobileMoneyProviders.length - 1} aria-label="Descendre" className="flex h-6 w-6 flex-none items-center justify-center rounded-full text-charcoal/50 hover:bg-slate-light disabled:opacity-30">
                ↓
              </button>
              <button type="button" onClick={() => deleteProvider(provider.id)} aria-label="Supprimer" className="flex h-6 w-6 flex-none items-center justify-center rounded-full text-red-500 hover:bg-red-50">
                ✕
              </button>
            </div>
          ))}
        </div>

        {restorable.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-2">
            {restorable.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => restoreDefault(p.id)}
                className="rounded-full border border-ocean-deep/40 px-3 py-1 text-xs font-semibold text-ocean-deep hover:bg-ocean-deep/5"
              >
                + Restaurer « {p.name} »
              </button>
            ))}
          </div>
        )}
      </div>

      {error && <p className="rounded-md bg-red-50 px-3 py-2 text-xs text-red-600">{error}</p>}

      <button
        type="button"
        onClick={() => save(draft)}
        disabled={saving}
        className="btn-sheen self-start rounded bg-ocean-deep px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-60"
      >
        {saving ? "…" : saved ? t("bankPanel.saved") : t("bankPanel.save")}
      </button>
    </div>
  );
}
