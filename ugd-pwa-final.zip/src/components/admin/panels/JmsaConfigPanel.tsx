import { useEffect, useState, type FormEvent } from "react";
import {
  DEFAULT_JMSA_CONFIG,
  setJmsaConfigRemote,
  subscribeJmsaConfig,
  type JmsaConfig,
} from "../../../services/cmsService";
import { isBackendConfigured } from "../../../services/donationsAdminApi";

const fieldCls = "w-full rounded-md border border-slate-light px-2.5 py-1.5 text-sm text-charcoal";

/**
 * Config JMSA — nom/dates/lieu/thème de l'événement + listes de jours et de
 * types de billets, éditables ici plutôt que codés en dur (voir
 * data/jmsaProgramme.ts, désormais juste la valeur de secours par défaut).
 *
 * Ne couvre volontairement pas l'agenda détaillé, les intervenants ni les
 * paliers de sponsoring — ce sont des refontes de contenu à part, pas de la
 * config en libre-service (voir la conversation avec Winner).
 */
export default function JmsaConfigPanel({ actorEmail }: { actorEmail: string }) {
  const [config, setConfig] = useState<JmsaConfig>(DEFAULT_JMSA_CONFIG);
  const [dayOptionsText, setDayOptionsText] = useState("");
  const [ticketOptionsText, setTicketOptionsText] = useState("");
  const [dayOptionsEnText, setDayOptionsEnText] = useState("");
  const [ticketOptionsEnText, setTicketOptionsEnText] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(
    () =>
      subscribeJmsaConfig((c) => {
        setConfig(c);
        setDayOptionsText(c.dayOptions.join("\n"));
        setTicketOptionsText(c.ticketOptions.join("\n"));
        setDayOptionsEnText((c.dayOptionsEn ?? []).join("\n"));
        setTicketOptionsEnText((c.ticketOptionsEn ?? []).join("\n"));
      }),
    [],
  );

  if (!isBackendConfigured()) {
    return (
      <div className="rounded-card border border-gold-warm/40 bg-gold-warm/10 p-4 text-sm text-charcoal">
        <p className="font-semibold">Backend non configuré</p>
        <p className="mt-1 text-charcoal/70">
          Renseignez <code className="rounded bg-white/60 px-1">VITE_API_BASE_URL</code> dans{" "}
          <code className="rounded bg-white/60 px-1">.env</code>.
        </p>
      </div>
    );
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSaved(false);
    try {
      const next: JmsaConfig = {
        ...config,
        dayOptions: dayOptionsText.split("\n").map((s) => s.trim()).filter(Boolean),
        ticketOptions: ticketOptionsText.split("\n").map((s) => s.trim()).filter(Boolean),
        dayOptionsEn: dayOptionsEnText.split("\n").map((s) => s.trim()).filter(Boolean),
        ticketOptionsEn: ticketOptionsEnText.split("\n").map((s) => s.trim()).filter(Boolean),
      };
      await setJmsaConfigRemote(actorEmail, next);
      setSaved(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur inconnue.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      <p className="text-xs text-charcoal/50 leading-relaxed">
        Ces champs alimentent l'en-tête du hub JMSA, la page d'inscription et le badge PDF. L'agenda détaillé, les
        intervenants et les paliers de sponsoring ne sont pas éditables ici (chantier séparé).
      </p>

      {error && <p className="rounded-md bg-red-50 px-3 py-2 text-xs text-red-600">{error}</p>}
      {saved && <p className="rounded-md bg-emerald/10 px-3 py-2 text-xs text-emerald">Configuration enregistrée.</p>}

      <label className="flex flex-col gap-1 text-xs font-semibold text-charcoal/60">
        Titre court (affiché sur le badge, l'onglet)
        <input
          value={config.shortTitle}
          onChange={(e) => setConfig({ ...config, shortTitle: e.target.value })}
          className={fieldCls}
        />
      </label>

      <label className="flex flex-col gap-1 text-xs font-semibold text-charcoal/60">
        Nom complet de l'événement
        <input
          value={config.eventName}
          onChange={(e) => setConfig({ ...config, eventName: e.target.value })}
          className={fieldCls}
        />
      </label>

      <label className="flex flex-col gap-1 text-xs font-semibold text-charcoal/60">
        Slogan
        <input
          value={config.slogan}
          onChange={(e) => setConfig({ ...config, slogan: e.target.value })}
          className={fieldCls}
        />
      </label>

      <div className="grid grid-cols-2 gap-2">
        <label className="flex flex-col gap-1 text-xs font-semibold text-charcoal/60">
          Dates
          <input
            value={config.dateRange}
            onChange={(e) => setConfig({ ...config, dateRange: e.target.value })}
            className={fieldCls}
          />
        </label>
        <label className="flex flex-col gap-1 text-xs font-semibold text-charcoal/60">
          Lieu
          <input
            value={config.location}
            onChange={(e) => setConfig({ ...config, location: e.target.value })}
            className={fieldCls}
          />
        </label>
      </div>

      <div className="rounded-card border border-ocean-deep/20 bg-ocean-deep/5 p-3">
        <label className="flex flex-col gap-1 text-xs font-semibold text-charcoal/60">
          Fin de l'événement (date de fermeture automatique)
          <input
            type="date"
            value={config.eventEndDate}
            onChange={(e) => setConfig({ ...config, eventEndDate: e.target.value })}
            className={fieldCls}
          />
        </label>
        <label className="mt-2.5 flex items-center gap-2 text-xs font-semibold text-charcoal/70">
          <input
            type="checkbox"
            checked={config.autoHideAfterEvent}
            onChange={(e) => setConfig({ ...config, autoHideAfterEvent: e.target.checked })}
            className="h-4 w-4 accent-ocean-deep"
          />
          Masquer automatiquement l'onglet JMSA et fermer les inscriptions après cette date
        </label>
        <p className="mt-1.5 text-[11px] text-charcoal/45 leading-relaxed">
          Décochez pour garder JMSA visible après l'événement (ex. le temps d'y laisser les photos du récap) — vous
          pourrez toujours le masquer manuellement via l'onglet Espaces.
        </p>
      </div>

      <label className="flex flex-col gap-1 text-xs font-semibold text-charcoal/60">
        Thème
        <textarea
          value={config.theme}
          onChange={(e) => setConfig({ ...config, theme: e.target.value })}
          rows={3}
          className={fieldCls}
        />
      </label>

      <div className="grid grid-cols-2 gap-2">
        <label className="flex flex-col gap-1 text-xs font-semibold text-charcoal/60">
          Jours proposés — FR (un par ligne)
          <textarea
            value={dayOptionsText}
            onChange={(e) => setDayOptionsText(e.target.value)}
            rows={3}
            className={fieldCls}
          />
        </label>
        <label className="flex flex-col gap-1 text-xs font-semibold text-charcoal/60">
          Jours proposés — EN (même ordre, même nombre de lignes)
          <textarea
            value={dayOptionsEnText}
            onChange={(e) => setDayOptionsEnText(e.target.value)}
            rows={3}
            className={fieldCls}
          />
        </label>
      </div>
      <p className="-mt-2 text-[11px] text-charcoal/45 leading-relaxed">
        Chaque ligne EN doit correspondre à la même ligne FR (même position). Si la liste EN est vide ou n'a pas le
        même nombre de lignes, le site affiche la version FR aux visiteurs anglophones.
      </p>

      <div className="grid grid-cols-2 gap-2">
        <label className="flex flex-col gap-1 text-xs font-semibold text-charcoal/60">
          Types de billets — FR (un par ligne)
          <textarea
            value={ticketOptionsText}
            onChange={(e) => setTicketOptionsText(e.target.value)}
            rows={5}
            className={fieldCls}
          />
        </label>
        <label className="flex flex-col gap-1 text-xs font-semibold text-charcoal/60">
          Types de billets — EN (même ordre)
          <textarea
            value={ticketOptionsEnText}
            onChange={(e) => setTicketOptionsEnText(e.target.value)}
            rows={5}
            className={fieldCls}
          />
        </label>
      </div>

      <button
        type="submit"
        disabled={saving}
        className="btn-sheen self-start rounded bg-ocean-deep px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
      >
        {saving ? "Enregistrement…" : "Enregistrer"}
      </button>
    </form>
  );
}
