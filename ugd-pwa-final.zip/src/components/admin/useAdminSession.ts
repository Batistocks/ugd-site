import { useEffect, useState } from "react";
import { getSession, subscribeSession, type AdminSession } from "../../services/authService";

/** React binding for the current admin session (see services/authService.ts). */
export function useAdminSession(): AdminSession | null {
  const [session, setSession] = useState<AdminSession | null>(getSession());

  useEffect(() => subscribeSession(setSession), []);

  return session;
}
