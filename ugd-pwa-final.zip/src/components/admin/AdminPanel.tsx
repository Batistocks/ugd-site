import { useEffect, useRef, useState } from "react";
import { useAdminSession } from "./useAdminSession";
import { logout } from "../../services/authService";
import { isDemoMode, resetDemoData } from "../../services/demoMode";
import EspacesPanel from "./panels/EspacesPanel";
import JmsaConfigPanel from "./panels/JmsaConfigPanel";
import FlyerMediaPanel from "./panels/FlyerMediaPanel";
import MediaLibraryPanel from "./panels/MediaLibraryPanel";
import DocumentsPanel from "./panels/DocumentsPanel";
import SpeakersPanel from "./panels/SpeakersPanel";
import BankAccountsPanel from "./panels/BankAccountsPanel";
import WhitelistPanel from "./panels/WhitelistPanel";
import ExportAuditPanel from "./panels/ExportAuditPanel";
import DonationsReviewPanel from "./panels/DonationsReviewPanel";
import InscriptionsPanel from "./panels/InscriptionsPanel";
import ImpactPanel from "./panels/ImpactPanel";
import QRScannerModal from "../QRScannerModal";
import { useLanguage } from "../../i18n/LanguageContext";

type Tab =
  | "return-to-site"
  | "espaces"
  | "impact"
  | "jmsa-config"
  | "speakers"
  | "flyers"
  | "mediatheque"
  | "documents"
  | "bank"
  | "donations"
  | "inscriptions"
  | "whitelist"
  | "export";

/**
 * Secret Admin Panel — shell.
 * Section 5: Secret Admin Panel & CMS Management.
 *
 * Rendered by Footer.tsx once an admin session is active (see
 * services/authService.ts). Structured the same way as the public app —
 * distinct tabs rather than one long scroll — with the QR badge scanner
 * (`QRScannerModal.tsx`) launched as its own full-screen overlay since it
 * needs the camera viewport.
 *
 * Tab navigation is a hamburger dropdown (top-right of the header), not a
 * swipeable/scrollable tab strip like the public site's bottom nav — these
 * admin sections are picked deliberately one at a time, not swiped between,
 * so a compact menu listing each tab by name reads better than a row of
 * cramped labels.
 *
 * "Titres" + "Ordre" (old, local-only tab title/order editors) have been
 * replaced by "Espaces", which does both plus enable/disable plus
 * unlimited custom content tabs, backed by the shared Firestore config
 * instead of the admin's own device — see cmsService.ts. New tabs below
 * (Espaces / Config JMSA / Inscriptions) use plain French labels rather
 * than the t() translation system, matching the app's French-only-going-
 * forward direction; the older tabs keep their existing fr/en labels.
 *
 * "Retour au site" isn't a real content tab — it has no panel body. It
 * calls `onReturnToSite` (from Footer.tsx) to unmount this overlay so the
 * admin sees the public site underneath, still logged in. The triple-tap/
 * click footer gesture brings the panel back (see Footer.tsx).
 */
export default function AdminPanel({ onReturnToSite }: { onReturnToSite: () => void }) {
  const session = useAdminSession();
  const { t } = useLanguage();
  const [tab, setTab] = useState<Tab>("espaces");
  const [scannerOpen, setScannerOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!menuOpen) return;
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [menuOpen]);

  if (!session) return null;
  const actorEmail = session.email;

  const TABS: { key: Tab; label: string }[] = [
    { key: "return-to-site", label: "↩︎ Retour au site" },
    { key: "espaces", label: "Espaces" },
    { key: "impact", label: "Compteurs" },
    { key: "jmsa-config", label: "Config JMSA" },
    { key: "speakers", label: "Intervenants" },
    { key: "flyers", label: t("adminPanel.tabFlyers") },
    { key: "mediatheque", label: "Médiathèque" },
    { key: "documents", label: "Documents" },
    { key: "bank", label: t("adminPanel.tabBank") },
    { key: "donations", label: t("adminPanel.tabDonations") },
    { key: "inscriptions", label: "Inscriptions" },
    { key: "whitelist", label: t("adminPanel.tabWhitelist") },
    { key: "export", label: t("adminPanel.tabExport") },
  ];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={t("adminPanel.title")}
      className="fixed inset-0 z-[65] flex flex-col bg-slate-light"
    >
      <header className="flex flex-none items-center justify-between gap-2 bg-ocean-deep px-4 py-3">
        <div className="min-w-0">
          <p className="font-display text-sm text-white">{t("adminPanel.title")}</p>
          <p className="truncate text-[11px] text-white/60">{actorEmail}</p>
        </div>
        <div className="relative flex flex-none items-center gap-2" ref={menuRef}>
          <button
            type="button"
            onClick={() => setScannerOpen(true)}
            className="rounded-full bg-gold-warm px-3 py-1.5 text-xs font-semibold text-white"
          >
            📷 {t("adminPanel.scanner")}
          </button>
          <button
            type="button"
            onClick={() => logout()}
            className="rounded-full bg-white/10 px-3 py-1.5 text-xs font-semibold text-white hover:bg-white/20"
          >
            {t("adminPanel.logout")}
          </button>
          <button
            type="button"
            onClick={() => setMenuOpen((open) => !open)}
            aria-label="Menu"
            aria-expanded={menuOpen}
            aria-haspopup="true"
            className="flex h-8 w-8 flex-none flex-col items-center justify-center gap-[3px] rounded-full bg-white/10 hover:bg-white/20"
          >
            <span className="block h-0.5 w-4 rounded bg-white" />
            <span className="block h-0.5 w-4 rounded bg-white" />
            <span className="block h-0.5 w-4 rounded bg-white" />
          </button>

          {menuOpen && (
            <div
              role="menu"
              className="absolute right-0 top-full z-10 mt-2 w-56 overflow-hidden rounded-xl border border-slate-light bg-white py-1 shadow-lg"
            >
              {TABS.map((tabItem) => (
                <button
                  key={tabItem.key}
                  type="button"
                  role="menuitem"
                  onClick={() => {
                    setMenuOpen(false);
                    if (tabItem.key === "return-to-site") {
                      onReturnToSite();
                    } else {
                      setTab(tabItem.key);
                    }
                  }}
                  className={`block w-full px-4 py-2.5 text-left text-sm font-semibold transition-colors ${
                    tabItem.key === "return-to-site"
                      ? "text-ocean-deep hover:bg-slate-light/60"
                      : tab === tabItem.key
                        ? "bg-gold/10 text-ocean-deep"
                        : "text-charcoal/70 hover:bg-slate-light/60"
                  }`}
                >
                  {tabItem.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </header>

      {isDemoMode && (
        <div className="flex flex-none items-center justify-between gap-2 bg-gold-warm px-4 py-1.5 text-[11px] font-semibold text-white">
          <span>MODE DÉMO — données enregistrées sur cet appareil uniquement</span>
          <button
            type="button"
            onClick={() => {
              if (!window.confirm("Effacer toutes les données de démo et recharger le site ?")) return;
              resetDemoData();
              // Vide aussi le cache local du CMS (IndexedDB), puis recharge.
              let done = false;
              const reload = () => {
                if (done) return;
                done = true;
                window.location.reload();
              };
              try {
                const req = indexedDB.deleteDatabase("ugd-offline-db");
                req.onsuccess = reload;
                req.onerror = reload;
                req.onblocked = reload;
              } catch {
                reload();
              }
              window.setTimeout(reload, 1500);
            }}
            className="flex-none rounded-full bg-white/20 px-2.5 py-1 hover:bg-white/30"
          >
            Réinitialiser
          </button>
        </div>
      )}

      <main className="flex-1 overflow-y-auto p-4">
        {tab === "espaces" && <EspacesPanel actorEmail={actorEmail} />}
        {tab === "impact" && <ImpactPanel actorEmail={actorEmail} />}
        {tab === "jmsa-config" && <JmsaConfigPanel actorEmail={actorEmail} />}
        {tab === "speakers" && <SpeakersPanel actorEmail={actorEmail} />}
        {tab === "flyers" && <FlyerMediaPanel actorEmail={actorEmail} />}
        {tab === "mediatheque" && <MediaLibraryPanel actorEmail={actorEmail} />}
        {tab === "documents" && <DocumentsPanel actorEmail={actorEmail} />}
        {tab === "bank" && <BankAccountsPanel actorEmail={actorEmail} />}
        {tab === "donations" && <DonationsReviewPanel actorEmail={actorEmail} />}
        {tab === "inscriptions" && <InscriptionsPanel actorEmail={actorEmail} />}
        {tab === "whitelist" && <WhitelistPanel actorEmail={actorEmail} />}
        {tab === "export" && <ExportAuditPanel actorEmail={actorEmail} />}
      </main>

      {scannerOpen && (
        <QRScannerModal actorEmail={actorEmail} onClose={() => setScannerOpen(false)} />
      )}
    </div>
  );
}
