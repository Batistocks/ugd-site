import LanguageSwitcher from "./LanguageSwitcher";
import { useLanguage } from "../i18n/LanguageContext";
import { useOnlineStatus } from "../hooks/useOnlineStatus";
import { usePWAInstall } from "../hooks/usePWAInstall";
import { useClipboard } from "../hooks/useClipboard";

export interface NavTab {
  id: string;
  /** Already-resolved display label (translated / CMS title). */
  label: string;
}

const SITE_URL = "https://www.ungestedivin.org/";

/**
 * Header Navigation.
 * - Logo top-left (tap → back to Accueil).
 * - Premium blue → emerald gradient bar with a gold hairline.
 * - Language switcher (FR/EN).
 * - PWA install trigger.
 * - Share button: replaces the old hamburger/dropdown menu on this bar.
 *   Tab switching itself now lives in the sliding bottom tab bar
 *   (see TopTabBar.tsx) — this header no longer needs a menu at all.
 */
export default function Navbar({
  tabs,
  activeTab,
  onSelectTab,
  homeTabId,
}: {
  tabs?: NavTab[];
  activeTab?: string;
  onSelectTab: (id: string) => void;
  onOpenChat?: () => void;
  /** Tab to jump to on logo tap — the Accueil tab if still visible,
   *  otherwise the first tab in the admin's current order (see App.tsx).
   *  Accueil is no longer a hardcoded id: an admin can rename, reorder,
   *  or even delete it, so the logo can't assume "accueil" still exists. */
  homeTabId?: string;
}) {
  const { t } = useLanguage();
  const isOnline = useOnlineStatus();
  const { canInstall, promptInstall } = usePWAInstall();
  const { copy, copiedId } = useClipboard();

  async function handleShare() {
    const shareData = {
      title: t("share.title"),
      text: t("share.text"),
      url: SITE_URL,
    };
    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch {
        // User cancelled the native share sheet — nothing to do.
      }
      return;
    }
    await copy("app-link", SITE_URL);
  }

  return (
    <header
      className="gloss sticky top-0 z-40 flex items-center justify-between gap-3 bg-ocean-deep px-4 lg:px-8 border-b-2 border-emerald shadow-royal"
      style={{ height: "var(--nav-height)" }}
    >
      <button
        type="button"
        onClick={() => homeTabId && onSelectTab(homeTabId)}
        className="flex items-center gap-2.5 min-w-0 flex-none"
      >
        <img
          src="/icons/icon-192.png"
          alt="UGD — Un Geste Divin"
          className="h-9 w-9 rounded-lg flex-none ring-1 ring-gold/50 object-contain bg-white"
        />
        <span className="min-w-0 flex flex-col justify-center leading-tight">
          <span className="truncate font-display text-white text-sm sm:text-base font-semibold">
            UGD
          </span>
          <span className="truncate text-white/70 text-[10px] sm:text-xs">
            Un Geste Divin
          </span>
        </span>
      </button>

      {tabs && tabs.length > 0 && (
        <nav aria-label="Navigation principale" className="hidden lg:flex items-center gap-6 min-w-0">
          {tabs.map((tab) => {
            const isActive = tab.id === activeTab;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => onSelectTab(tab.id)}
                className={`whitespace-nowrap text-[13px] font-medium tracking-wide uppercase pb-1 border-b-2 transition-colors ${
                  isActive
                    ? "text-white border-emerald"
                    : "text-white/65 border-transparent hover:text-white/90"
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </nav>
      )}

      <div className="flex items-center gap-2 flex-none">
        {!isOnline && (
          <span className="hidden sm:inline-flex items-center gap-1 rounded-full bg-charcoal/60 px-2.5 py-1 text-xs text-white/80">
            <span className="h-1.5 w-1.5 rounded-full bg-gold-warm" />
            {t("offline.badge")}
          </span>
        )}

        {canInstall && (
          <button
            type="button"
            onClick={promptInstall}
            aria-label={t("install.cta")}
            className="hidden sm:flex h-9 w-9 items-center justify-center rounded-full text-white/90 hover:bg-white/10"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path
                d="M12 3v12m0 0 4-4m-4 4-4-4M5 19h14"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
        )}

        <LanguageSwitcher />

        <button
          type="button"
          onClick={handleShare}
          aria-label={t("share.label")}
          className="relative flex h-9 w-9 flex-none items-center justify-center rounded-full bg-gold-warm/90 text-ocean-deep hover:bg-gold shadow-sm"
        >
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <circle cx="18" cy="5" r="2.6" stroke="currentColor" strokeWidth="2" />
            <circle cx="6" cy="12" r="2.6" stroke="currentColor" strokeWidth="2" />
            <circle cx="18" cy="19" r="2.6" stroke="currentColor" strokeWidth="2" />
            <path d="M8.3 10.7 15.7 6.6M8.3 13.3l7.4 4.1" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
          {copiedId === "app-link" && (
            <span className="absolute -bottom-8 right-0 whitespace-nowrap rounded-md bg-charcoal px-2 py-1 text-[11px] text-white shadow-card">
              {t("share.copied")}
            </span>
          )}
        </button>
      </div>
    </header>
  );
}
