import PaymentAccountsPanel from "./PaymentAccountsPanel";
import DonationProofForm from "./DonationProofForm";

/**
 * Espace 3 : Dons & Coordonnées Officielles.
 *
 * The accounts display itself (IBAN/BIC, Mobile Money, PayPal) lives in
 * `PaymentAccountsPanel.tsx` — shared with the inline "Je sponsorise ce
 * tier" flow in `JMSAHub.tsx` (Espace 2), so both entry points show the
 * exact same, always-up-to-date account numbers.
 */
export default function DonationsSection() {
  return (
    <div className="flex flex-col gap-4">
      <PaymentAccountsPanel />

      {/* Transfer proof upload — Section 4: Ticketing, PDF Generation & QR Code System */}
      <div className="rounded-card bg-slate-light/60 p-3.5">
        <DonationProofForm />
      </div>
    </div>
  );
}
