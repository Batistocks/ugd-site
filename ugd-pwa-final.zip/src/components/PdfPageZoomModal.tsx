import { useCallback, useEffect, useRef, useState } from "react";
import type { PointerEvent as ReactPointerEvent, MouseEvent as ReactMouseEvent } from "react";
import type { PDFDocumentProxy } from "pdfjs-dist";
import { useLanguage } from "../i18n/LanguageContext";
import { useBackClose } from "../hooks/useBackClose";
import { renderPdfTextLayer } from "../services/pdfTextLayer";

interface PdfPageZoomModalProps {
  pdf: PDFDocumentProxy;
  numPages: number;
  /** 1-indexed page to open on. */
  startPage: number;
  title: string;
  onClose: () => void;
  /**
   * When set, shows a small download button in the header pointing at the
   * original file -- so a visitor who lands directly on this fullscreen
   * carousel (e.g. from PdfDossierModal) still has a way to save the PDF,
   * not just read it on screen.
   */
  downloadHref?: string;
}

const MIN_SCALE = 1;
const MAX_SCALE = 3;
const DOUBLE_TAP_SCALE = 2;
const DOUBLE_TAP_MS = 300;
const DOUBLE_TAP_MAX_MOVE = 12; // px
const SWIPE_THRESHOLD_PX = 50;

interface Point {
  x: number;
  y: number;
}

/**
 * Fullscreen, pinch-zoomable reading view for a single PDF page — opened
 * from the "expand" button on PdfReader.tsx. Same pointer-gesture model as
 * FlyerZoomModal.tsx (pinch, double-tap/double-click, pan, swipe between
 * items), applied to a canvas + selectable text layer instead of a plain
 * `<img>`: both are drawn once per page/resize at a resolution with
 * headroom for the max pinch scale, then the *pair* is what gets the CSS
 * pinch/pan transform — so the text stays exactly aligned and selectable
 * at any zoom level, not just at 100%.
 */
export default function PdfPageZoomModal({
  pdf,
  numPages,
  startPage,
  title,
  onClose,
  downloadHref,
}: PdfPageZoomModalProps) {
  const { t } = useLanguage();
  useBackClose(onClose);
  const containerRef = useRef<HTMLDivElement>(null);
  const pageBoxRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const textLayerRef = useRef<HTMLDivElement>(null);
  const pageInputRef = useRef<HTMLInputElement>(null);

  const isCarousel = numPages > 1;
  const [index, setIndex] = useState(() => Math.min(Math.max(startPage - 1, 0), numPages - 1));
  const pageNumber = index + 1;
  const [pageInput, setPageInput] = useState(String(pageNumber));

  const [scale, setScale] = useState(1);
  const [translate, setTranslate] = useState<Point>({ x: 0, y: 0 });
  const [boxSize, setBoxSize] = useState<{ width: number; height: number } | null>(null);

  // Live refs so pointer handlers always read the latest transform without
  // re-subscribing listeners on every render.
  const scaleRef = useRef(scale);
  const translateRef = useRef(translate);
  scaleRef.current = scale;
  translateRef.current = translate;

  const pointers = useRef<Map<number, Point>>(new Map());
  const gestureStart = useRef<{
    distance: number;
    scale: number;
    midpoint: Point;
    translate: Point;
  } | null>(null);
  const dragStart = useRef<{ point: Point; translate: Point } | null>(null);
  const lastTap = useRef<{ time: number; point: Point } | null>(null);

  const clampTranslate = useCallback((next: Point, nextScale: number): Point => {
    const container = containerRef.current;
    if (!container) return next;
    const rect = container.getBoundingClientRect();
    const maxX = (rect.width * (nextScale - 1)) / 2;
    const maxY = (rect.height * (nextScale - 1)) / 2;
    return {
      x: Math.min(maxX, Math.max(-maxX, next.x)),
      y: Math.min(maxY, Math.max(-maxY, next.y)),
    };
  }, []);

  const resetTransform = useCallback(() => {
    setScale(1);
    setTranslate({ x: 0, y: 0 });
  }, []);

  const goToIndex = useCallback(
    (updater: (i: number) => number) => {
      setIndex((i) => {
        const count = numPages;
        return ((updater(i) % count) + count) % count;
      });
      resetTransform();
    },
    [numPages, resetTransform],
  );
  const goNext = useCallback(() => goToIndex((i) => i + 1), [goToIndex]);
  const goPrev = useCallback(() => goToIndex((i) => i - 1), [goToIndex]);

  // Keep the page-number input in sync whenever the page changes some
  // other way (swipe, arrows) -- but only while the field isn't focused,
  // so it doesn't clobber what the visitor is currently typing.
  useEffect(() => {
    if (document.activeElement !== pageInputRef.current) {
      setPageInput(String(pageNumber));
    }
  }, [pageNumber]);

  function commitPageInput() {
    const n = parseInt(pageInput, 10);
    if (Number.isFinite(n)) {
      const clamped = Math.min(Math.max(n, 1), numPages);
      goToIndex(() => clamped - 1);
      setPageInput(String(clamped));
    } else {
      setPageInput(String(pageNumber));
    }
  }

  const toggleZoom = useCallback(
    (origin: Point) => {
      const container = containerRef.current;
      if (!container) return;
      const rect = container.getBoundingClientRect();
      const center = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };

      if (scaleRef.current > MIN_SCALE) {
        resetTransform();
        return;
      }
      const next = {
        x: (center.x - origin.x) * (DOUBLE_TAP_SCALE - 1),
        y: (center.y - origin.y) * (DOUBLE_TAP_SCALE - 1),
      };
      setScale(DOUBLE_TAP_SCALE);
      setTranslate(clampTranslate(next, DOUBLE_TAP_SCALE));
    },
    [clampTranslate, resetTransform],
  );

  const onPointerDown = (e: ReactPointerEvent) => {
    (e.target as Element).setPointerCapture(e.pointerId);
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (pointers.current.size === 1) {
      dragStart.current = { point: { x: e.clientX, y: e.clientY }, translate: translateRef.current };

      const now = performance.now();
      const point = { x: e.clientX, y: e.clientY };
      if (
        lastTap.current &&
        now - lastTap.current.time < DOUBLE_TAP_MS &&
        Math.hypot(point.x - lastTap.current.point.x, point.y - lastTap.current.point.y) <
          DOUBLE_TAP_MAX_MOVE
      ) {
        toggleZoom(point);
        lastTap.current = null;
        return;
      }
      lastTap.current = { time: now, point };
    }

    if (pointers.current.size === 2) {
      const [p1, p2] = Array.from(pointers.current.values());
      gestureStart.current = {
        distance: Math.hypot(p2.x - p1.x, p2.y - p1.y),
        scale: scaleRef.current,
        midpoint: { x: (p1.x + p2.x) / 2, y: (p1.y + p2.y) / 2 },
        translate: translateRef.current,
      };
    }
  };

  const onPointerMove = (e: ReactPointerEvent) => {
    if (!pointers.current.has(e.pointerId)) return;
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (pointers.current.size === 2 && gestureStart.current) {
      const [p1, p2] = Array.from(pointers.current.values());
      const distance = Math.hypot(p2.x - p1.x, p2.y - p1.y);
      const ratio = distance / (gestureStart.current.distance || 1);
      const nextScale = Math.min(MAX_SCALE, Math.max(MIN_SCALE, gestureStart.current.scale * ratio));
      setScale(nextScale);
      setTranslate(clampTranslate(gestureStart.current.translate, nextScale));
      return;
    }

    if (pointers.current.size === 1 && dragStart.current && scaleRef.current > MIN_SCALE) {
      const point = pointers.current.get(e.pointerId)!;
      const dx = point.x - dragStart.current.point.x;
      const dy = point.y - dragStart.current.point.y;
      setTranslate(
        clampTranslate(
          { x: dragStart.current.translate.x + dx, y: dragStart.current.translate.y + dy },
          scaleRef.current,
        ),
      );
    }
  };

  const onPointerUp = (e: ReactPointerEvent) => {
    const lastPoint = pointers.current.get(e.pointerId);
    pointers.current.delete(e.pointerId);
    if (pointers.current.size < 2) gestureStart.current = null;

    if (pointers.current.size === 0) {
      if (isCarousel && scaleRef.current <= MIN_SCALE && dragStart.current && lastPoint) {
        const dx = lastPoint.x - dragStart.current.point.x;
        const dy = lastPoint.y - dragStart.current.point.y;
        if (Math.abs(dx) > SWIPE_THRESHOLD_PX && Math.abs(dx) > Math.abs(dy) * 1.5) {
          if (dx < 0) goNext();
          else goPrev();
        }
      }
      dragStart.current = null;
    }

    if (scaleRef.current < MIN_SCALE) resetTransform();
  };

  const onDoubleClick = (e: ReactMouseEvent) => {
    toggleZoom({ x: e.clientX, y: e.clientY });
  };

  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
      if (isCarousel && e.key === "ArrowRight") goNext();
      if (isCarousel && e.key === "ArrowLeft") goPrev();
    }
    window.addEventListener("keydown", onKeyDown);
    document.body.classList.add("drawer-open");
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      document.body.classList.remove("drawer-open");
    };
  }, [onClose, isCarousel, goNext, goPrev]);

  // Available reading area (the container, minus its own padding) — drives
  // the "fit this page inside the screen" size, same job object-fit:contain
  // does for free on an <img>.
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const observer = new ResizeObserver((entries) => {
      const rect = entries[0]?.contentRect;
      if (rect) setBoxSize({ width: rect.width, height: rect.height });
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  // Draw the current page: canvas at a resolution with headroom for
  // MAX_SCALE pinch zoom, text layer sized to match the *displayed*
  // (unzoomed) box so it lines up with the canvas underneath at any scale.
  useEffect(() => {
    if (!boxSize || boxSize.width === 0 || boxSize.height === 0) return;
    let cancelled = false;

    (async () => {
      const page = await pdf.getPage(pageNumber);
      if (cancelled) return;
      const base = page.getViewport({ scale: 1 });
      const padding = 0.96; // small margin so the page never touches the screen edge
      const fitScale = Math.min((boxSize.width * padding) / base.width, (boxSize.height * padding) / base.height);

      const cssWidth = base.width * fitScale;
      const cssHeight = base.height * fitScale;

      const canvas = canvasRef.current;
      const pageBox = pageBoxRef.current;
      if (!canvas || !pageBox) return;

      pageBox.style.width = `${cssWidth}px`;
      pageBox.style.height = `${cssHeight}px`;

      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const renderScale = fitScale * dpr * MAX_SCALE; // headroom so pinching in stays crisp
      const renderViewport = page.getViewport({ scale: renderScale });

      canvas.width = renderViewport.width;
      canvas.height = renderViewport.height;
      canvas.style.width = `${cssWidth}px`;
      canvas.style.height = `${cssHeight}px`;

      const context = canvas.getContext("2d");
      if (!context) return;
      await page.render({ canvasContext: context, viewport: renderViewport }).promise;
      if (cancelled) return;

      if (textLayerRef.current) {
        void renderPdfTextLayer(page, textLayerRef.current, fitScale);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [pdf, pageNumber, boxSize]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`${title} — ${t("founder.pages")} ${pageNumber}`}
      className="fixed inset-0 z-[60] bg-charcoal/95 flex flex-col"
      data-swipe-ignore
    >
      <div className="flex items-center justify-between gap-3 px-4 py-3 flex-none">
        <span className="min-w-0 truncate pr-3 text-sm text-white/80">
          {title}
          {isCarousel && (
            <span className="ml-2 inline-flex items-center gap-1 whitespace-nowrap text-xs text-white/50">
              <input
                ref={pageInputRef}
                type="number"
                inputMode="numeric"
                min={1}
                max={numPages}
                value={pageInput}
                onChange={(e) => setPageInput(e.target.value)}
                onBlur={commitPageInput}
                onKeyDown={(e) => {
                  if (e.key === "Enter") e.currentTarget.blur();
                }}
                onFocus={(e) => e.currentTarget.select()}
                onClick={(e) => e.stopPropagation()}
                aria-label={t("founder.goToPage")}
                className="w-9 rounded bg-white/10 px-1 py-0.5 text-center text-white [appearance:textfield] focus:outline-none focus:ring-1 focus:ring-white/50 [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
              />
              <span>/ {numPages}</span>
            </span>
          )}
        </span>
        <div className="flex flex-none items-center gap-2">
          {downloadHref && (
            <a
              href={downloadHref}
              download
              aria-label={t("founder.download")}
              className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path
                  d="M12 4v11m0 0-4-4m4 4 4-4M5 20h14"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </a>
          )}
          <button
            type="button"
            onClick={onClose}
            aria-label={t("nav.close")}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M5 5l14 14M19 5 5 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </button>
        </div>
      </div>

      <div
        ref={containerRef}
        className="relative flex-1 overflow-hidden touch-none select-none"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        onDoubleClick={onDoubleClick}
      >
        <div
          ref={pageBoxRef}
          className="absolute left-1/2 top-1/2 select-text"
          style={{
            transform: `translate(-50%, -50%) translate(${translate.x}px, ${translate.y}px) scale(${scale})`,
            transition: pointers.current.size > 0 ? "none" : "transform 150ms ease-out",
          }}
        >
          <canvas ref={canvasRef} className="block shadow-2xl" />
          <div ref={textLayerRef} className="textLayer" />
        </div>

        {isCarousel && (
          <>
            <button
              type="button"
              onClick={goPrev}
              aria-label={t("founder.prevPage")}
              className="absolute left-2 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M15 5l-7 7 7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
            <button
              type="button"
              onClick={goNext}
              aria-label={t("founder.nextPage")}
              className="absolute right-2 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M9 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
          </>
        )}
      </div>

      <p className="flex-none text-center text-xs text-white/50 py-2">
        {isCarousel ? t("founder.zoomHintCarousel") : t("founder.zoomHint")}
      </p>
    </div>
  );
}
