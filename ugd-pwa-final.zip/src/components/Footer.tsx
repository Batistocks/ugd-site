import { useEffect, useState, type MouseEvent } from "react";
import { useTripleClick } from "../hooks/useTripleClick";
import AdminLoginModal from "./admin/AdminLoginModal";
import AdminPanel from "./admin/AdminPanel";
import { useAdminSession } from "./admin/useAdminSession";
import { isAdminSignInLink } from "../services/authService";
import LegalModal from "./LegalModal";
import { useLanguage } from "../i18n/LanguageContext";

/**
 * Footer with the Section 5 secret trigger: a triple-tap / triple-click
 * anywhere on this area within 800ms opens the Secret Admin Login Modal.
 * Nothing here visually hints that the area is special beyond the two
 * ordinary legal links — it still looks like an ordinary footer, as
 * required by the "secret" trigger spec.
 *
 * `panelHidden` lets a logged-in admin temporarily dismiss the full-screen
 * AdminPanel (via its "Retour au site" tab) to see the public site as a
 * visitor would, without logging out. The same triple-tap/click gesture
 * that opens the login modal for a logged-out visitor brings the panel
 * back for a logged-in admin — no separate floating button, keeping the
 * footer looking ordinary either way.
 */
export default function Footer() {
  const [loginOpen, setLoginOpen] = useState(false);
  const [panelHidden, setPanelHidden] = useState(false);
  const [legalTab, setLegalTab] = useState<"notice" | "privacy" | null>(null);
  const session = useAdminSession();
  const { t } = useLanguage();
  const triple = useTripleClick(() => {
    if (!session) setLoginOpen(true);
    else setPanelHidden(false);
  });

  // If this page load IS an admin sign-in link (the admin just tapped it
  // in their email inbox), open the login modal automatically instead of
  // requiring the secret triple-tap again.
  useEffect(() => {
    if (isAdminSignInLink()) setLoginOpen(true);
  }, []);

  function openLegal(tab: "notice" | "privacy", e: MouseEvent) {
    e.stopPropagation();
    setLegalTab(tab);
  }

  return (
    <>
      <footer
        {...triple}
        className="mx-auto max-w-2xl lg:max-w-5xl px-4 lg:px-8 py-6 lg:py-10 text-center lg:text-left text-xs text-charcoal/45 select-none border-t border-slate-light"
      >
        <p className="lg:text-charcoal/60 lg:font-semibold lg:uppercase lg:tracking-wide lg:text-[11px]">
          AISBL UN GESTE DIVIN
        </p>
        <p className="mt-2 lg:mt-1">© {new Date().getFullYear()} — {t("footer.rights")}</p>
        <p className="mt-1">{t("app.contactAddress")}</p>
        <p className="mt-2 flex items-center justify-center lg:justify-start gap-3">
          <button
            type="button"
            onClick={(e) => openLegal("notice", e)}
            className="underline decoration-dotted underline-offset-2 hover:text-charcoal/60"
          >
            {t("footer.legalLink")}
          </button>
          <span aria-hidden="true">·</span>
          <button
            type="button"
            onClick={(e) => openLegal("privacy", e)}
            className="underline decoration-dotted underline-offset-2 hover:text-charcoal/60"
          >
            {t("footer.privacyLink")}
          </button>
        </p>
      </footer>

      {legalTab && <LegalModal initialTab={legalTab} onClose={() => setLegalTab(null)} />}
      {loginOpen && !session && <AdminLoginModal onClose={() => setLoginOpen(false)} />}
      {session && !panelHidden && <AdminPanel onReturnToSite={() => setPanelHidden(true)} />}
    </>
  );
}
