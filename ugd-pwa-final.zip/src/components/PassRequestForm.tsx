import { useEffect, useState, type ChangeEvent, type FormEvent } from "react";
import { enqueueMutation } from "../services/db";
import { generateReferenceCode } from "../services/pdfService";
import { useOnlineStatus } from "../hooks/useOnlineStatus";
import { useLanguage } from "../i18n/LanguageContext";
import {
  buildRegistrationWhatsappLink,
  formatWhatsappInput,
  toInternationalNumber,
} from "../services/whatsappLinks";
import {
  DEFAULT_JMSA_CONFIG,
  getLocalizedOptions,
  isJmsaAutoHidden,
  isModuleSpaceEnabled,
  subscribeJmsaConfig,
  subscribeSpaces,
  type JmsaConfig,
  type Space,
} from "../services/cmsService";

type FormState = {
  fullName: string;
  email: string;
  phone: string;
  organization: string;
  day: string;
  ticketType: string;
};

type Status = "idle" | "submitting" | "done" | "error";

const inputCls =
  "w-full rounded-lg border border-slate-light px-3 py-2.5 text-sm text-charcoal placeholder:text-charcoal/40 focus:border-ocean-deep focus:outline-none";

/**
 * Registration form — "Demande de pass" for JMSA 2026.
 * Section 4: Ticketing, PDF Generation & QR Code System.
 *
 * Day/ticket options and the event name/dates printed on the badge come
 * from the admin-editable JMSA config (Section 5 — see JmsaConfigPanel.tsx)
 * rather than being hardcoded, so the same form can be reused for a future
 * edition without a code change. Also respects the "jmsa-2026" space's
 * enabled flag (Section 5 — EspacesPanel.tsx): once the admin disables it
 * (e.g. right after the event), this form stops accepting new requests
 * everywhere it's reachable, including the direct `?inscription=` deep
 * link — see App.tsx / RegistrationLanding.tsx.
 *
 * On submit: the registration is queued in IndexedDB (works fully offline,
 * flushed by the sync manager once back online — see services/syncService.ts)
 * and the confirmation screen appears. The WhatsApp button — which sends the
 * registration details to the association for confirmation — shows up only
 * on that confirmation screen, never before the form is submitted.
 *
 * No badge is generated here: the access badge comes exclusively with a
 * gala ticket bought through the Billetterie (JMSAHub.tsx) — the ticket,
 * with its QR code, is sent by WhatsApp or e-mail once the payment has been
 * verified by the association.
 *
 * Free vs paid day: the FIRST day option of the JMSA config (Friday 20,
 * Bruxelles) is the free one and is a simple registration. Any other
 * option (Saturday 21 in Charleroi, or both days) includes the paid gala,
 * so picking it doesn't register anyone here: the visitor is sent to the
 * Billetterie to pay for a ticket instead (`onGoToTickets`).
 */
export default function PassRequestForm({ onGoToTickets }: { onGoToTickets?: () => void } = {}) {
  const isOnline = useOnlineStatus();
  const { lang, t } = useLanguage();
  const [jmsaConfig, setJmsaConfig] = useState<JmsaConfig>(DEFAULT_JMSA_CONFIG);
  const [spaces, setSpaces] = useState<Space[]>([]);
  const [form, setForm] = useState<FormState>(() => ({
    fullName: "",
    email: "",
    phone: "",
    organization: "",
    day: DEFAULT_JMSA_CONFIG.dayOptions[0],
    ticketType: DEFAULT_JMSA_CONFIG.ticketOptions[1] ?? DEFAULT_JMSA_CONFIG.ticketOptions[0],
  }));
  const [status, setStatus] = useState<Status>("idle");
  const [registrationId, setRegistrationId] = useState<string | null>(null);
  const [whatsappLink, setWhatsappLink] = useState<string | null>(null);
  const [phoneError, setPhoneError] = useState<string | null>(null);

  useEffect(() => subscribeJmsaConfig(setJmsaConfig), []);
  useEffect(() => subscribeSpaces(setSpaces), []);

  // Once the real config loads, re-align the pre-selected day/ticket
  // defaults with whatever the admin currently has configured (only while
  // the visitor hasn't started editing, to avoid clobbering their choice).
  useEffect(() => {
    setForm((f) => ({
      ...f,
      day: jmsaConfig.dayOptions.includes(f.day) ? f.day : jmsaConfig.dayOptions[0] ?? f.day,
      ticketType: jmsaConfig.ticketOptions.includes(f.ticketType) ? f.ticketType : jmsaConfig.ticketOptions[0] ?? f.ticketType,
    }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [jmsaConfig]);

  const update =
    (key: keyof FormState) => (e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
      setForm((f) => ({ ...f, [key]: e.target.value }));

  const registrationsOpen =
    (spaces.length === 0 || isModuleSpaceEnabled(spaces, "jmsa-2026")) && !isJmsaAutoHidden(jmsaConfig);

  // First day option = the free day (see header comment).
  const paidDay = jmsaConfig.dayOptions.length > 0 && form.day !== jmsaConfig.dayOptions[0];

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (paidDay) return;
    if (!form.fullName.trim() || !form.email.trim()) return;

    // The WhatsApp number is mandatory and must start with the country code.
    const phone = toInternationalNumber(form.phone);
    if (!phone) {
      setPhoneError(t("passForm.phoneInvalid"));
      return;
    }
    setPhoneError(null);

    setStatus("submitting");
    try {
      const id = generateReferenceCode("JMSA26");

      await enqueueMutation("pass-request", {
        registrationId: id,
        ...form,
        phone,
        lang,
        createdAt: Date.now(),
      });

      setWhatsappLink(
        buildRegistrationWhatsappLink(lang, {
          fullName: form.fullName.trim(),
          registrationId: id,
          eventShortTitle: jmsaConfig.shortTitle,
          day: form.day,
          ticketType: form.ticketType,
        }),
      );

      setRegistrationId(id);
      setStatus("done");
    } catch {
      setStatus("error");
    }
  }

  function reset() {
    setForm((f) => ({ ...f, fullName: "", email: "", phone: "", organization: "" }));
    setRegistrationId(null);
    setWhatsappLink(null);
    setPhoneError(null);
    setStatus("idle");
  }

  if (!registrationsOpen) {
    return (
      <div className="rounded-card border border-slate-light bg-white p-4 text-sm">
        <p className="font-semibold text-charcoal">Inscriptions closes</p>
        <p className="mt-1 text-charcoal/70 leading-relaxed">
          Les inscriptions pour {jmsaConfig.shortTitle} ne sont plus ouvertes actuellement. Merci de contacter
          l'association si vous avez besoin d'informations complémentaires.
        </p>
      </div>
    );
  }

  if (status === "done" && registrationId) {
    return (
      <div className="rounded-card border border-emerald/30 bg-emerald/5 p-4 text-sm">
        <p className="font-semibold text-emerald">{t("passForm.doneTitle")}</p>
        <p className="mt-1 text-charcoal/70 leading-relaxed">
          {t("passForm.doneBody")} {registrationId}
          {t("passForm.doneBodyEnd")} {!isOnline && t("passForm.doneOffline")}
        </p>

        {whatsappLink && (
          <a
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-sheen mt-3 flex items-center justify-center gap-2 rounded bg-whatsapp px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-whatsapp/30"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
              <path d="M12 2C6.48 2 2 6.48 2 12c0 1.85.5 3.58 1.36 5.07L2 22l5.1-1.33A9.94 9.94 0 0 0 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2Zm0 18c-1.6 0-3.1-.44-4.39-1.2l-.31-.19-3.02.79.8-2.94-.2-.31A7.94 7.94 0 0 1 4 12c0-4.41 3.59-8 8-8s8 3.59 8 8-3.59 8-8 8Zm4.36-5.98c-.24-.12-1.43-.7-1.65-.78-.22-.08-.38-.12-.54.12-.16.24-.62.78-.76.94-.14.16-.28.18-.52.06-.24-.12-1.01-.37-1.92-1.18-.71-.63-1.19-1.41-1.33-1.65-.14-.24-.01-.37.11-.49.11-.11.24-.28.36-.42.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.54-1.3-.74-1.78-.19-.46-.39-.4-.54-.4-.14 0-.3-.02-.46-.02-.16 0-.42.06-.64.3-.22.24-.84.82-.84 2s.86 2.32.98 2.48c.12.16 1.7 2.6 4.12 3.65.58.25 1.03.4 1.38.51.58.18 1.11.16 1.53.1.47-.07 1.43-.58 1.63-1.15.2-.57.2-1.05.14-1.15-.06-.1-.22-.16-.46-.28Z" />
            </svg>
            {t("passForm.whatsappCta")}
          </a>
        )}
        <p className="mt-1.5 text-xs text-charcoal/50 leading-relaxed">{t("passForm.whatsappHint")}</p>

        <button
          type="button"
          onClick={reset}
          className="mt-3 text-xs font-semibold text-ocean-deep underline"
        >
          {t("passForm.newRequest")}
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      <h3 className="font-display text-sm text-charcoal">{t("passForm.title")}</h3>

      {!isOnline && (
        <p className="rounded-md bg-gold-warm/10 px-3 py-2 text-xs text-gold-warm">
          {t("passForm.offlineNotice")}
        </p>
      )}

      <select value={form.day} onChange={update("day")} className={inputCls}>
        {jmsaConfig.dayOptions.map((day, i) => (
          <option key={day} value={day}>
            {getLocalizedOptions(lang, jmsaConfig.dayOptions, jmsaConfig.dayOptionsEn)[i]}
          </option>
        ))}
      </select>

      {paidDay ? (
        <div className="rounded-card border border-gold-warm/40 bg-gold-warm/10 p-3.5 text-sm">
          <p className="font-semibold text-charcoal">{t("passForm.paidDayTitle")}</p>
          <p className="mt-1 leading-relaxed text-charcoal/70">{t("passForm.paidDayBody")}</p>
          {onGoToTickets && (
            <button
              type="button"
              onClick={onGoToTickets}
              className="btn-sheen mt-3 w-full rounded bg-ocean-deep px-4 py-2.5 text-sm font-semibold text-white shadow-royal"
            >
              {t("passForm.paidDayCta")}
            </button>
          )}
        </div>
      ) : (
        <>
          <input
            required
            placeholder={t("passForm.fullName")}
            value={form.fullName}
            onChange={update("fullName")}
            className={inputCls}
          />
          <input
            required
            type="email"
            placeholder={t("passForm.email")}
            value={form.email}
            onChange={update("email")}
            className={inputCls}
          />
          <input
            required
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            placeholder={t("passForm.phone")}
            value={form.phone}
            onChange={(e) => {
              const phone = formatWhatsappInput(e.target.value);
              setForm((f) => ({ ...f, phone }));
              if (phoneError) setPhoneError(null);
            }}
            className={`${inputCls} ${phoneError ? "border-red-500" : ""}`}
          />
          <p className="-mt-1.5 text-xs leading-relaxed text-charcoal/60">{t("passForm.phoneHint")}</p>
          {phoneError && <p className="-mt-1.5 text-xs text-red-600">{phoneError}</p>}
          <input
            placeholder={t("passForm.organization")}
            value={form.organization}
            onChange={update("organization")}
            className={inputCls}
          />

          <select value={form.ticketType} onChange={update("ticketType")} className={inputCls}>
            {jmsaConfig.ticketOptions.map((ticket, i) => (
              <option key={ticket} value={ticket}>
                {getLocalizedOptions(lang, jmsaConfig.ticketOptions, jmsaConfig.ticketOptionsEn)[i]}
              </option>
            ))}
          </select>

          <button
            type="submit"
            disabled={status === "submitting"}
            className="btn-sheen rounded bg-ocean-deep px-4 py-2.5 text-sm font-semibold text-white shadow-royal disabled:opacity-60 disabled:shadow-none"
          >
            {status === "submitting" ? t("passForm.submitting") : t("passForm.submit")}
          </button>
        </>
      )}

      {status === "error" && <p className="text-xs text-red-600">{t("passForm.error")}</p>}
    </form>
  );
}
