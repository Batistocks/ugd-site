import { usePWAInstall } from "../hooks/usePWAInstall";
import { useLanguage } from "../i18n/LanguageContext";

/**
 * PWA Install Banner.
 * Rendered when the browser has fired `beforeinstallprompt` and the
 * person hasn't already installed or dismissed it. Triggerable also
 * from a button in the Navbar (see Navbar.tsx `onInstallClick`).
 * Section 1 (UI) / Section 2 (PWA core).
 */
export default function PWAInstallBanner() {
  const { canInstall, promptInstall, dismiss } = usePWAInstall();
  const { t } = useLanguage();

  if (!canInstall) return null;

  return (
    <div
      role="dialog"
      aria-label={t("install.title")}
      className="fixed inset-x-3 z-40 flex items-center gap-3 rounded-card bg-charcoal text-white px-4 py-3 shadow-card"
      style={{ bottom: "calc(1rem + env(safe-area-inset-bottom))" }}
    >
      <div className="flex h-10 w-10 flex-none items-center justify-center rounded-full bg-gold-warm/20">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path
            d="M12 3v12m0 0 4-4m-4 4-4-4M5 19h14"
            stroke="#B89B55"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold leading-tight">{t("install.title")}</p>
        <p className="text-xs text-white/70 leading-snug mt-0.5">{t("install.body")}</p>
      </div>
      <div className="flex flex-none flex-col gap-1.5">
        <button
          type="button"
          onClick={promptInstall}
          className="rounded-full bg-gold-warm px-3 py-1.5 text-xs font-semibold text-charcoal"
        >
          {t("install.cta")}
        </button>
        <button type="button" onClick={dismiss} className="text-xs text-white/60 underline">
          {t("install.dismiss")}
        </button>
      </div>
    </div>
  );
}
