import { useEffect } from "react";
import { useLanguage } from "../i18n/LanguageContext";
import { useBackClose } from "../hooks/useBackClose";

interface VideoPlayerModalProps {
  src: string;
  poster: string;
  title: string;
  onClose: () => void;
}

/**
 * Lecteur plein écran pour les vidéos de la Médiathèque (Espace 5).
 * Même charpente que FlyerZoomModal.tsx (fond charcoal/95, bouton fermer
 * en haut à droite, fermeture au clavier via Échap) mais avec un lecteur
 * <video> natif (contrôles du navigateur) au lieu d'un lightbox image.
 */
export default function VideoPlayerModal({ src, poster, title, onClose }: VideoPlayerModalProps) {
  const { t } = useLanguage();
  useBackClose(onClose);

  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
    }
    window.addEventListener("keydown", onKeyDown);
    document.body.classList.add("drawer-open");
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      document.body.classList.remove("drawer-open");
    };
  }, [onClose]);

  return (
    <div role="dialog" aria-modal="true" aria-label={title} className="fixed inset-0 z-[60] bg-charcoal/95 flex flex-col">
      {/* Caption on top of the video, always shown in full (wraps, never
          truncated); only scrolls inside its own box if extremely long. */}
      <div className="flex flex-none items-start justify-between gap-3 px-4 pb-3 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <div className="min-w-0 max-h-[30vh] overflow-y-auto pr-1">
          <p className="break-words text-sm font-medium leading-snug text-white">{title}</p>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label={t("mediaLibrary.close")}
          className="flex h-9 w-9 flex-none items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="M5 5l14 14M19 5 5 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>
      </div>

      <div className="relative flex flex-1 items-center justify-center overflow-hidden px-2 pb-4">
        <video
          src={src}
          poster={poster}
          controls
          autoPlay
          playsInline
          className="max-h-full max-w-full rounded-md"
        >
          {t("mediaLibrary.unsupported")}
        </video>
      </div>
    </div>
  );
}
