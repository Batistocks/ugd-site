import { useEffect, useState } from "react";
import { useLanguage } from "../i18n/LanguageContext";
import VideoPlayerModal from "./VideoPlayerModal";
import FlyerZoomModal from "./FlyerZoomModal";
import {
  DEFAULT_MEDIA_PHOTOS,
  DEFAULT_MEDIA_VIDEOS,
  subscribeMediaPhotos,
  subscribeMediaVideos,
  type MediaPhotoItem,
  type MediaVideoItem,
} from "../services/cmsService";

type SubTab = "videos" | "photos";

/**
 * Espace 5 : Médiathèque — playlist vidéo + galerie photo, organisées en
 * sous-onglets (même schéma que MissionsTransparency.tsx). Chaque
 * vignette vidéo ouvre le lecteur plein écran (VideoPlayerModal), chaque
 * photo ouvre le zoom plein écran (FlyerZoomModal).
 *
 * Contenu géré depuis l'Espace admin « Médiathèque »
 * (MediaLibraryPanel.tsx) — voir cmsService.ts — au lieu d'être codé en
 * dur : un ajout/suppression fait par l'admin apparaît immédiatement chez
 * tous les visiteurs. `alt`/`title` est le texte FR (toujours affiché en
 * FR, et utilisé comme repli EN tant que `altEn`/`titleEn` n'a pas été
 * renseigné).
 */
export default function MediaLibrary() {
  const { lang, t } = useLanguage();
  const [photos, setPhotos] = useState<MediaPhotoItem[]>(DEFAULT_MEDIA_PHOTOS);
  const [videos, setVideos] = useState<MediaVideoItem[]>(DEFAULT_MEDIA_VIDEOS);
  const [subTab, setSubTab] = useState<SubTab>("videos");
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [openPhoto, setOpenPhoto] = useState<MediaPhotoItem | null>(null);

  useEffect(() => subscribeMediaPhotos(setPhotos), []);
  useEffect(() => subscribeMediaVideos(setVideos), []);

  const items = videos.map((v) => ({
    ...v,
    displayTitle: lang === "en" && v.titleEn ? v.titleEn : v.title,
  }));
  const openItem = openIndex !== null ? items[openIndex] : null;

  const tabs: { id: SubTab; label: string }[] = [
    { id: "videos", label: t("media.tabVideos") },
    { id: "photos", label: t("media.tabPhotos") },
  ];

  return (
    <div className="flex flex-col gap-4">
      <div role="tablist" className="flex border-b border-slate-light">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            role="tab"
            aria-selected={subTab === tab.id}
            onClick={() => setSubTab(tab.id)}
            className={`flex-1 border-b-2 py-2 text-[11px] font-semibold uppercase tracking-wide transition-colors ${
              subTab === tab.id
                ? "border-gold text-ocean-deep"
                : "border-transparent text-charcoal/45 hover:text-charcoal/70"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {subTab === "videos" && (
        <div className="flex flex-col gap-2">
          {items.map((item, index) => (
            <button
              key={item.src}
              type="button"
              onClick={() => setOpenIndex(index)}
              className="flex items-center gap-3 rounded-card border border-slate-light p-2 text-left"
            >
              <div className="relative flex-none">
                <img src={item.thumbnail} alt="" aria-hidden="true" className="h-14 w-20 rounded-md object-cover" />
                <span className="absolute inset-0 flex items-center justify-center">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-white/85">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="#155D8B" aria-hidden="true">
                      <path d="M8 5v14l11-7Z" />
                    </svg>
                  </span>
                </span>
              </div>
              <span className="min-w-0">
                <span className="block break-words text-sm font-medium leading-snug text-charcoal">{item.displayTitle}</span>
                <span className="text-xs text-charcoal/50">{item.duration}</span>
              </span>
            </button>
          ))}
        </div>
      )}

      {subTab === "photos" && (
        <div>
          {photos.length === 0 ? (
            <p className="text-sm italic text-charcoal/40">{t("media.galleryEmpty")}</p>
          ) : (
            <div className="grid grid-cols-3 gap-1.5">
              {photos.map((photo) => (
                <button
                  key={photo.id}
                  type="button"
                  onClick={() => setOpenPhoto(photo)}
                  className="aspect-square overflow-hidden rounded border border-slate-light"
                  aria-label={lang === "en" && photo.altEn ? photo.altEn : photo.alt}
                >
                  <img src={photo.src} alt="" aria-hidden="true" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {openItem && (
        <VideoPlayerModal
          src={openItem.src}
          poster={openItem.thumbnail}
          title={openItem.displayTitle}
          onClose={() => setOpenIndex(null)}
        />
      )}

      {openPhoto && (
        <FlyerZoomModal
          src={openPhoto.src}
          alt={lang === "en" && openPhoto.altEn ? openPhoto.altEn : openPhoto.alt}
          onClose={() => setOpenPhoto(null)}
        />
      )}
    </div>
  );
}
