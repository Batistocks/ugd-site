import { useEffect, useState, type ChangeEvent, type FormEvent } from "react";
import { enqueueMutation } from "../services/db";
import { downloadBlob, generateReceiptPdf, generateReferenceCode } from "../services/pdfService";
import { useOnlineStatus } from "../hooks/useOnlineStatus";
import { syncQueue } from "../services/syncService";
import { compressImage } from "../services/imageCompression";
import { useLanguage } from "../i18n/LanguageContext";
import {
  buildSponsoringWhatsappLink,
  buildTicketWhatsappLink,
  formatWhatsappInput,
  toInternationalNumber,
  type TransferInfo,
} from "../services/whatsappLinks";
import { DEFAULT_JMSA_CONFIG, subscribeJmsaConfig } from "../services/cmsService";

// Canonical (French) values — stored, queued offline, and printed on the
// official receipt PDF. Only the "Virement bancaire" entry gets a
// translated on-screen label; the others are provider brand names.
const METHODS = ["Virement bancaire", "TMoney", "Flooz", "Orange Money", "MTN Mobile Money", "PayPal"];

// Proof files are capped at 2 MB (the server accepts up to 3 MB of decoded
// file). Photos and screenshots are compressed in the browser first — a
// phone photo of 5 MB ends up well under the cap and stays readable. PDFs
// can't be compressed here, so a PDF over 2 MB is refused with a clear
// message. A base64 data URL runs ~33% larger than the source, which keeps
// the offline-queue entry small enough for low-end phones.
const MAX_FILE_BYTES = 2 * 1024 * 1024;
// Images above this size are re-encoded (screenshots below it are left untouched).
const COMPRESS_TARGET_BYTES = 900 * 1024;

type FormState = {
  donorName: string;
  email: string;
  /** WhatsApp number — asked for gala tickets only. */
  phone: string;
  amount: string;
  method: string;
  file: File | null;
};

function buildEmptyForm(presetAmount?: string): FormState {
  return {
    donorName: "",
    email: "",
    phone: "",
    amount: presetAmount ?? "",
    method: METHODS[0],
    file: null,
  };
}

type Status = "idle" | "submitting" | "done" | "error";

const inputCls =
  "w-full rounded-lg border border-slate-light px-3 py-2.5 text-sm text-charcoal placeholder:text-charcoal/40 focus:border-ocean-deep focus:outline-none";

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

export interface DonationProofFormProps {
  /** Pre-fills the amount field, e.g. "2000" for a 2 000 € sponsoring tier. Still editable. */
  presetAmount?: string;
  /** Shown on the form and stamped on the receipt/queued record, e.g. "Sponsoring — Sponsor Diamant". Defaults to "Don". */
  presetContext?: string;
  /** Reference code prefix, e.g. "SPO26" for sponsors vs the default "DON26". */
  referencePrefix?: string;
  /**
   * When set (Sponsoring / Billetterie), the confirmation screen ends with a
   * WhatsApp button — it only appears AFTER the transfer has been reported,
   * never when a tier/ticket is merely selected. `itemName` is the tier
   * name or the ticket category. Left unset (plain donations), the screen
   * keeps its "send another proof" link instead.
   */
  whatsapp?: { kind: "sponsoring" | "billetterie"; itemName: string };
}

/**
 * Registration form — donation transfer proof upload.
 * Section 4: Ticketing, PDF Generation & QR Code System.
 *
 * On submit: the proof (converted to a data URL) and donor details are
 * queued in IndexedDB for sync (works fully offline — see
 * services/syncService.ts), and a provisional donation receipt PDF is
 * generated and downloaded immediately. The association confirms the
 * final receipt once the transfer is verified (Section 5 admin panel).
 *
 * Gala tickets (Billetterie) additionally REQUIRE a WhatsApp number that
 * starts with the country code (forced "+" prefix, validated on submit and
 * again server-side), because the ticket (badge with QR code) is sent back
 * on WhatsApp once the payment is verified. The e-mail stays optional.
 *
 * Reused as-is for sponsoring (Espace 2, `JMSAHub.tsx`) via
 * `presetAmount` / `presetContext` / `referencePrefix` — same offline
 * queue, same receipt generator, just tagged so the admin panel and the
 * PDF both show "Sponsoring — <tier>" instead of a generic "Don".
 */
export default function DonationProofForm({
  presetAmount,
  presetContext,
  referencePrefix = "DON26",
  whatsapp,
}: DonationProofFormProps = {}) {
  const isOnline = useOnlineStatus();
  const { lang, t } = useLanguage();
  const [form, setForm] = useState<FormState>(() => buildEmptyForm(presetAmount));
  const [status, setStatus] = useState<Status>("idle");
  const [fileError, setFileError] = useState<string | null>(null);
  const [compressing, setCompressing] = useState(false);
  const [contactError, setContactError] = useState<string | null>(null);
  const [receiptId, setReceiptId] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState<TransferInfo | null>(null);
  const [eventShortTitle, setEventShortTitle] = useState(DEFAULT_JMSA_CONFIG.shortTitle);

  useEffect(() => subscribeJmsaConfig((c) => setEventShortTitle(c.shortTitle)), []);

  // If the sponsor changes tier (presetAmount changes) while this form
  // instance is reused, keep the amount field in sync.
  useEffect(() => {
    setForm((f) => ({ ...f, amount: presetAmount ?? f.amount }));
  }, [presetAmount]);

  // A gala ticket (Billetterie) is sent back on WhatsApp once the payment is
  // verified, so a number with country code is mandatory.
  const isTicket = whatsapp?.kind === "billetterie";

  const update =
    (key: "donorName" | "email" | "phone" | "amount" | "method") =>
    (e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
      setForm((f) => ({ ...f, [key]: e.target.value }));

  const updatePhone = (e: ChangeEvent<HTMLInputElement>) => {
    const phone = formatWhatsappInput(e.target.value);
    setForm((f) => ({ ...f, phone }));
    if (contactError) setContactError(null);
  };

  async function handleFile(e: ChangeEvent<HTMLInputElement>) {
    const input = e.target;
    let file = input.files?.[0] ?? null;
    setFileError(null);
    if (!file) {
      setForm((f) => ({ ...f, file: null }));
      return;
    }

    // Photos / screenshots: compress in the browser when they are heavy.
    if (file.type.startsWith("image/") && file.size > COMPRESS_TARGET_BYTES) {
      setCompressing(true);
      try {
        const result = await compressImage(file, { targetBytes: COMPRESS_TARGET_BYTES, minQuality: 0.7 });
        file = result.file;
      } catch {
        // Unreadable format (e.g. HEIC on some browsers): keep the original
        // and let the size check below decide.
      } finally {
        setCompressing(false);
      }
    }

    if (file.size > MAX_FILE_BYTES) {
      setFileError(t("proofForm.fileTooLarge"));
      setForm((f) => ({ ...f, file: null }));
      input.value = "";
      return;
    }
    setForm((f) => ({ ...f, file }));
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!form.donorName.trim() || !form.amount.trim()) return;
    // Gala ticket: a WhatsApp number with its country code is mandatory.
    const ticketPhone = isTicket ? toInternationalNumber(form.phone) : null;
    if (isTicket && !ticketPhone) {
      setContactError(t("proofForm.contactRequired"));
      return;
    }
    setContactError(null);

    setStatus("submitting");
    try {
      const proofDataUrl = form.file ? await fileToDataUrl(form.file) : null;
      const id = generateReferenceCode(referencePrefix);

      await enqueueMutation("donation-proof", {
        receiptId: id,
        donorName: form.donorName.trim(),
        email: form.email.trim() || null,
        phone: ticketPhone,
        ticketName: isTicket ? whatsapp?.itemName ?? null : null,
        amount: form.amount,
        method: form.method,
        context: presetContext ?? t("proofForm.contextDefault"),
        proofFileName: form.file?.name ?? null,
        proofDataUrl,
        lang,
        createdAt: Date.now(),
      });

      const blob = await generateReceiptPdf(
        {
          receiptId: id,
          donorName: form.donorName.trim(),
          donorEmail: form.email.trim() || undefined,
          amount: form.amount,
          method: form.method,
          purpose: presetContext,
          dateLabel: new Date().toLocaleDateString(lang === "en" ? "en-GB" : "fr-BE"),
        },
        lang,
      );
      downloadBlob(blob, `recu-${id}.pdf`);

      setReceiptId(id);
      setSubmitted({
        itemName: whatsapp?.itemName ?? presetContext ?? "",
        donorName: form.donorName.trim(),
        amount: form.amount,
        method: form.method,
        receiptId: id,
      });
      setStatus("done");
      // Try to reach the backend immediately instead of waiting for the
      // next periodic sync pass — no-op (stays queued) if offline or if
      // the backend isn't configured yet.
      void syncQueue();
    } catch {
      setStatus("error");
    }
  }

  function reset() {
    setForm(buildEmptyForm(presetAmount));
    setFileError(null);
    setContactError(null);
    setReceiptId(null);
    setSubmitted(null);
    setStatus("idle");
  }

  if (status === "done" && receiptId) {
    return (
      <div className="rounded-card border border-emerald/30 bg-emerald/5 p-4 text-sm">
        <p className="font-semibold text-emerald">
          {presetContext ? `${presetContext} ${t("proofForm.doneTitleSuffix")}` : t("proofForm.doneTitleGeneric")}
        </p>
        <p className="mt-1 text-charcoal/70 leading-relaxed">
          {t("proofForm.receiptDownloaded")} {receiptId} {t("proofForm.receiptDownloadedEnd")}{" "}
          {!isOnline && `${t("proofForm.doneOffline")} `}
          {presetContext ? t("proofForm.validatingSoonPayment") : t("proofForm.validatingSoonDonation")}
        </p>
        {whatsapp && submitted ? (
          <>
            {/* Appears only now, once the transfer has been reported. */}
            <a
              href={
                whatsapp.kind === "billetterie"
                  ? buildTicketWhatsappLink(lang, eventShortTitle, submitted)
                  : buildSponsoringWhatsappLink(lang, eventShortTitle, submitted)
              }
              target="_blank"
              rel="noopener noreferrer"
              className="btn-sheen mt-3 flex items-center justify-center gap-2 rounded bg-whatsapp px-4 py-2.5 text-center text-sm font-semibold text-white shadow-lg shadow-whatsapp/30"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" className="flex-none">
                <path d="M12 2C6.48 2 2 6.48 2 12c0 1.85.5 3.58 1.36 5.07L2 22l5.1-1.33A9.94 9.94 0 0 0 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2Zm0 18c-1.6 0-3.1-.44-4.39-1.2l-.31-.19-3.02.79.8-2.94-.2-.31A7.94 7.94 0 0 1 4 12c0-4.41 3.59-8 8-8s8 3.59 8 8-3.59 8-8 8Zm4.36-5.98c-.24-.12-1.43-.7-1.65-.78-.22-.08-.38-.12-.54.12-.16.24-.62.78-.76.94-.14.16-.28.18-.52.06-.24-.12-1.01-.37-1.92-1.18-.71-.63-1.19-1.41-1.33-1.65-.14-.24-.01-.37.11-.49.11-.11.24-.28.36-.42.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.54-1.3-.74-1.78-.19-.46-.39-.4-.54-.4-.14 0-.3-.02-.46-.02-.16 0-.42.06-.64.3-.22.24-.84.82-.84 2s.86 2.32.98 2.48c.12.16 1.7 2.6 4.12 3.65.58.25 1.03.4 1.38.51.58.18 1.11.16 1.53.1.47-.07 1.43-.58 1.63-1.15.2-.57.2-1.05.14-1.15-.06-.1-.22-.16-.46-.28Z" />
              </svg>
              {whatsapp.kind === "billetterie" ? t("proofForm.whatsappTicketCta") : t("proofForm.whatsappSponsorCta")}
            </a>
            <p className="mt-1.5 text-xs leading-relaxed text-charcoal/50">
              {whatsapp.kind === "billetterie" ? t("proofForm.whatsappTicketHint") : t("proofForm.whatsappSponsorHint")}
            </p>
          </>
        ) : (
          <button
            type="button"
            onClick={reset}
            className="mt-3 text-xs font-semibold text-ocean-deep underline"
          >
            {t("proofForm.newProof")}
          </button>
        )}
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      <h3 className="font-display text-sm text-charcoal">
        {presetContext ? `${presetContext} ${t("proofForm.subtitleSuffix")}` : t("proofForm.titleGeneric")}
      </h3>

      {!isOnline && (
        <p className="rounded-md bg-gold-warm/10 px-3 py-2 text-xs text-gold-warm">
          {t("proofForm.offlineNotice")}
        </p>
      )}

      <input
        required
        placeholder={t("proofForm.fullName")}
        value={form.donorName}
        onChange={update("donorName")}
        className={inputCls}
      />
      <input
        type="email"
        placeholder={t("proofForm.emailOptional")}
        value={form.email}
        onChange={update("email")}
        className={inputCls}
      />
      {isTicket && (
        <>
          <input
            required
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            placeholder={t("proofForm.phoneWhatsapp")}
            value={form.phone}
            onChange={updatePhone}
            className={`${inputCls} ${contactError ? "border-red-500" : ""}`}
          />
          <p className="-mt-1.5 text-xs leading-relaxed text-charcoal/60">{t("proofForm.contactTicketHint")}</p>
          {contactError && <p className="text-xs text-red-600">{contactError}</p>}
        </>
      )}

      <div className="grid grid-cols-2 gap-2">
        <input
          required
          type="number"
          min="1"
          step="0.01"
          placeholder={t("proofForm.amount")}
          value={form.amount}
          onChange={update("amount")}
          className={inputCls}
        />
        <select value={form.method} onChange={update("method")} className={inputCls}>
          {METHODS.map((method) => (
            <option key={method} value={method}>
              {method === "Virement bancaire" ? t("proofForm.methodBankTransfer") : method}
            </option>
          ))}
        </select>
      </div>

      <label className="text-xs text-charcoal/60">
        {t("proofForm.proofLabel")}
        <input
          type="file"
          accept="image/*,application/pdf"
          onChange={handleFile}
          className="mt-1 block w-full text-xs"
        />
      </label>
      {compressing && <p className="text-xs text-charcoal/60">{t("proofForm.compressing")}</p>}
      {fileError && <p className="text-xs text-red-600">{fileError}</p>}

      <button
        type="submit"
        disabled={status === "submitting" || compressing}
        className="btn-sheen rounded bg-emerald px-4 py-2.5 text-sm font-semibold text-white shadow-emeraldGlow disabled:opacity-60 disabled:shadow-none"
      >
        {status === "submitting" ? t("proofForm.submitting") : t("proofForm.submit")}
      </button>

      {status === "error" && <p className="text-xs text-red-600">{t("proofForm.error")}</p>}
    </form>
  );
}
