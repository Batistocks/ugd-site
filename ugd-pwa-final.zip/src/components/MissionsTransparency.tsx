import { useEffect, useState } from "react";
import type { Lang } from "../i18n/translations";
import { useLanguage } from "../i18n/LanguageContext";
import PdfLinkRow from "./PdfLinkRow";
import { subscribeDocuments, type DocumentItem } from "../services/cmsService";

function docLabel(doc: DocumentItem, lang: Lang): string {
  if (lang === "en" && doc.labelEn && doc.labelEn.trim()) return doc.labelEn;
  return doc.label;
}

type SubTab = "reports" | "news";

/**
 * Espace 4 : Missions & Transparence.
 * Rapports & documents officiels et actualités, organisés en
 * sous-onglets — le rapport financier audité et les futures actus
 * viendront compléter cette structure au fil de l'eau. Le sous-onglet
 * « Nos actions » a été retiré : la Médiathèque (Espace 5, voir
 * MediaLibrary.tsx) montre déjà les actions en photos et vidéos.
 *
 * Tout ce qui concerne le sommet JMSA 2026 (agenda, inscription,
 * sponsoring) vit exclusivement dans l'Espace 2 (JMSAHub.tsx) : cet
 * espace-ci ne doit montrer aucune image ni information JMSA.
 */
export default function MissionsTransparency() {
  const { lang, t } = useLanguage();

  const [subTab, setSubTab] = useState<SubTab>("reports");
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  useEffect(() => subscribeDocuments(setDocuments), []);

  // The system "ugd-marketing" slot (title admin-editable, see
  // DocumentsPanel.tsx) plus any free-form "custom" document an admin has
  // added — this is the only place in the app that surfaces "custom"
  // documents, so adding one here is the way an admin publishes an
  // arbitrary extra report/PDF without a code change.
  const reports = documents.filter((d) => d.enabled && (d.kind === "ugd-marketing" || d.kind === "custom"));

  const tabs: { id: SubTab; label: string }[] = [
    { id: "reports", label: t("missions.tabReports") },
    { id: "news", label: t("missions.tabNews") },
  ];

  return (
    <div className="flex flex-col gap-4">
      <div role="tablist" className="flex border-b border-slate-light">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            role="tab"
            aria-selected={subTab === tab.id}
            onClick={() => setSubTab(tab.id)}
            className={`flex-1 border-b-2 py-2 text-[11px] font-semibold uppercase tracking-wide transition-colors ${
              subTab === tab.id
                ? "border-gold text-ocean-deep"
                : "border-transparent text-charcoal/45 hover:text-charcoal/70"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {subTab === "reports" && (
        <div className="flex flex-col gap-2">
          <h3 className="font-display text-sm text-charcoal">{t("missions.reportsTitle")}</h3>
          {reports.map((doc) => (
            <PdfLinkRow key={doc.id} href={doc.src} label={docLabel(doc, lang)} />
          ))}
          <div className="flex items-center justify-between gap-3 rounded border border-dashed border-slate-light px-3 py-2.5">
            <span className="text-sm italic text-charcoal/40">{t("missions.financialReportPending")}</span>
          </div>
        </div>
      )}

      {subTab === "news" && (
        <div className="rounded-card border border-dashed border-slate-light px-4 py-8 text-center">
          <p className="text-sm font-semibold text-charcoal/60">{t("missions.newsComingSoon")}</p>
          <p className="mt-1 text-xs text-charcoal/40">{t("missions.newsComingSoonDetail")}</p>
        </div>
      )}

    </div>
  );
}
