import { useLanguage } from "../i18n/LanguageContext";
import type { Space } from "../services/cmsService";

/**
 * Renders an admin-created generic content "espace" — title + free text +
 * optional images. No bespoke logic (no forms, no payments): this is the
 * ceiling of what an admin can build without a developer (see EspacesPanel
 * in the admin CMS). Line breaks in `body`/`bodyEn` are preserved; images
 * are shared across both languages and shown as a simple stacked gallery.
 */
export default function CustomSpacePanel({ space }: { space: Space }) {
  const { lang, t } = useLanguage();
  // English text falls back to the French one whenever the admin hasn't
  // filled in bodyEn yet — same rule as titleEn in resolveSpaceLabel.
  const body = lang === "en" && space.bodyEn && space.bodyEn.trim() ? space.bodyEn : space.body;
  const title = lang === "en" && space.titleEn && space.titleEn.trim() ? space.titleEn : space.title;

  return (
    <div className="flex flex-col gap-3">
      {body && <p className="whitespace-pre-line text-sm text-charcoal/80 leading-relaxed">{body}</p>}
      {space.images && space.images.length > 0 && (
        <div className="flex flex-col gap-3">
          {space.images.map((src, i) => (
            <img
              key={`${src}-${i}`}
              src={src}
              alt={`${title} — image ${i + 1}`}
              className="w-full rounded-card border border-slate-light object-cover"
            />
          ))}
        </div>
      )}
      {!body && (!space.images || space.images.length === 0) && (
        <p className="text-sm text-charcoal/40 italic">{t("customSpace.empty")}</p>
      )}
    </div>
  );
}
