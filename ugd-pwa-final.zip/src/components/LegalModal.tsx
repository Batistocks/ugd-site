import { useState } from "react";
import { getLegalNotice, getPrivacyPolicy } from "../data/legalContent";
import { useLanguage } from "../i18n/LanguageContext";
import { useBackClose } from "../hooks/useBackClose";

type Tab = "notice" | "privacy";

/**
 * "Mentions légales" / "Politique de confidentialité" (RGPD) modal,
 * linked from the footer. Content lives in src/data/legalContent.ts —
 * boilerplate drafted from the association's own public details, not a
 * substitute for a lawyer's review before publishing (see the disclaimer
 * rendered at the bottom of the modal, and the comment at the top of
 * legalContent.ts).
 */
export default function LegalModal({
  initialTab = "notice",
  onClose,
}: {
  initialTab?: Tab;
  onClose: () => void;
}) {
  const { lang, t } = useLanguage();
  useBackClose(onClose);
  const [tab, setTab] = useState<Tab>(initialTab);
  const sections = tab === "notice" ? getLegalNotice(lang) : getPrivacyPolicy(lang);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={t("legal.title")}
      className="fixed inset-0 z-[60] flex items-end justify-center bg-charcoal/60 sm:items-center"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="flex max-h-[85vh] w-full max-w-lg flex-col rounded-t-2xl bg-white shadow-card sm:rounded-2xl"
      >
        <div className="flex flex-none items-center justify-between border-b border-slate-light px-5 py-4">
          <h2 className="font-display text-base text-ocean-deep">{t("legal.title")}</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label={t("legal.close")}
            className="flex h-8 w-8 items-center justify-center rounded-full hover:bg-slate-light"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M5 5l14 14M19 5 5 19" stroke="#24313A" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </button>
        </div>

        <div className="flex flex-none gap-1 border-b border-slate-light px-3 py-2">
          {(["notice", "privacy"] as const).map((tabKey) => (
            <button
              key={tabKey}
              type="button"
              onClick={() => setTab(tabKey)}
              className={`flex-1 rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
                tab === tabKey ? "bg-ocean-deep text-white" : "text-charcoal/60 hover:bg-slate-light"
              }`}
            >
              {tabKey === "notice" ? t("legal.tabNotice") : t("legal.tabPrivacy")}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4">
          <div className="flex flex-col gap-4">
            {sections.map((section) => (
              <div key={section.heading}>
                <h3 className="font-display text-sm text-charcoal mb-1.5">{section.heading}</h3>
                <div className="flex flex-col gap-1.5">
                  {section.paragraphs.map((p, i) => (
                    <p key={i} className="text-xs text-charcoal/70 leading-relaxed">
                      {p}
                    </p>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <p className="mt-5 border-t border-slate-light pt-3 text-[11px] italic text-charcoal/40">
            {t("legal.disclaimer")}
          </p>
        </div>
      </div>
    </div>
  );
}
