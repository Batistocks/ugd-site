import { useEffect, useRef, useState, useCallback } from "react";
import type { PointerEvent as ReactPointerEvent, MouseEvent as ReactMouseEvent } from "react";
import { useLanguage } from "../i18n/LanguageContext";
import { useBackClose } from "../hooks/useBackClose";

interface FlyerImage {
  src: string;
  alt: string;
}

interface FlyerZoomModalProps {
  /** Single-image mode (speaker photo, mission photo, ...). Ignored if `items` is provided. */
  src?: string;
  alt?: string;
  /** Carousel mode: full list to browse + which one was tapped to open the modal. */
  items?: FlyerImage[];
  startIndex?: number;
  onClose: () => void;
}

const MIN_SCALE = 1;
const MAX_SCALE = 3;
const DOUBLE_TAP_SCALE = 2;
const DOUBLE_TAP_MS = 300;
const DOUBLE_TAP_MAX_MOVE = 12; // px
const SWIPE_THRESHOLD_PX = 50;

interface Point {
  x: number;
  y: number;
}

/**
 * Lightbox for event flyers (and other single photos: speaker headshots,
 * transparency mission photos).
 *
 * Two modes, same component:
 * - Single image: pass `src` + `alt` (unchanged behavior).
 * - Carousel: pass `items` (the full flyer list) + `startIndex` (which one
 *   was tapped). Adds prev/next arrows, a "n / total" counter, and swipe
 *   left/right to move between flyers — used by the participant flyer
 *   gallery (JMSAHub.tsx) so opening one flyer lets you browse all of them
 *   without closing and reopening the lightbox.
 *
 * Supports: pinch-to-zoom (two-finger), double-tap / double-click zoom
 * toggle (100% -> 200% -> 100%), drag/pan once zoomed in, and — in carousel
 * mode, only while at 100% (nothing to pan yet) — a horizontal swipe moves
 * to the previous/next flyer. Built on the Pointer Events API so touch,
 * mouse and pen all share one code path.
 */
export default function FlyerZoomModal({ src, alt, items, startIndex = 0, onClose }: FlyerZoomModalProps) {
  const { t } = useLanguage();
  useBackClose(onClose);
  const containerRef = useRef<HTMLDivElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);

  const gallery = items && items.length > 0 ? items : [{ src: src ?? "", alt: alt ?? "" }];
  const isCarousel = gallery.length > 1;

  const [index, setIndex] = useState(() => Math.min(Math.max(startIndex, 0), gallery.length - 1));
  const current = gallery[index];

  const [scale, setScale] = useState(1);
  const [translate, setTranslate] = useState<Point>({ x: 0, y: 0 });

  // Live refs so pointer handlers always read the latest transform without
  // re-subscribing listeners on every render.
  const scaleRef = useRef(scale);
  const translateRef = useRef(translate);
  scaleRef.current = scale;
  translateRef.current = translate;

  const pointers = useRef<Map<number, Point>>(new Map());
  const gestureStart = useRef<{
    distance: number;
    scale: number;
    midpoint: Point;
    translate: Point;
  } | null>(null);
  const dragStart = useRef<{ point: Point; translate: Point } | null>(null);
  const lastTap = useRef<{ time: number; point: Point } | null>(null);

  const clampTranslate = useCallback((next: Point, nextScale: number): Point => {
    const container = containerRef.current;
    if (!container) return next;
    const rect = container.getBoundingClientRect();
    // Allow panning only as far as the zoomed image's overflow permits.
    const maxX = (rect.width * (nextScale - 1)) / 2;
    const maxY = (rect.height * (nextScale - 1)) / 2;
    return {
      x: Math.min(maxX, Math.max(-maxX, next.x)),
      y: Math.min(maxY, Math.max(-maxY, next.y)),
    };
  }, []);

  const resetTransform = useCallback(() => {
    setScale(1);
    setTranslate({ x: 0, y: 0 });
  }, []);

  const goToIndex = useCallback(
    (updater: (i: number) => number) => {
      setIndex((i) => {
        const count = gallery.length;
        return ((updater(i) % count) + count) % count;
      });
      resetTransform();
    },
    [gallery.length, resetTransform],
  );
  const goNext = useCallback(() => goToIndex((i) => i + 1), [goToIndex]);
  const goPrev = useCallback(() => goToIndex((i) => i - 1), [goToIndex]);

  const toggleZoom = useCallback(
    (origin: Point) => {
      const container = containerRef.current;
      if (!container) return;
      const rect = container.getBoundingClientRect();
      const center = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };

      if (scaleRef.current > MIN_SCALE) {
        resetTransform();
        return;
      }
      // Zoom in centered roughly on the tap/click point.
      const next = {
        x: (center.x - origin.x) * (DOUBLE_TAP_SCALE - 1),
        y: (center.y - origin.y) * (DOUBLE_TAP_SCALE - 1),
      };
      setScale(DOUBLE_TAP_SCALE);
      setTranslate(clampTranslate(next, DOUBLE_TAP_SCALE));
    },
    [clampTranslate, resetTransform],
  );

  const onPointerDown = (e: ReactPointerEvent) => {
    (e.target as Element).setPointerCapture(e.pointerId);
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (pointers.current.size === 1) {
      dragStart.current = { point: { x: e.clientX, y: e.clientY }, translate: translateRef.current };

      // Double-tap / double-click detection.
      const now = performance.now();
      const point = { x: e.clientX, y: e.clientY };
      if (
        lastTap.current &&
        now - lastTap.current.time < DOUBLE_TAP_MS &&
        Math.hypot(point.x - lastTap.current.point.x, point.y - lastTap.current.point.y) <
          DOUBLE_TAP_MAX_MOVE
      ) {
        toggleZoom(point);
        lastTap.current = null;
        return;
      }
      lastTap.current = { time: now, point };
    }

    if (pointers.current.size === 2) {
      const [p1, p2] = Array.from(pointers.current.values());
      gestureStart.current = {
        distance: Math.hypot(p2.x - p1.x, p2.y - p1.y),
        scale: scaleRef.current,
        midpoint: { x: (p1.x + p2.x) / 2, y: (p1.y + p2.y) / 2 },
        translate: translateRef.current,
      };
    }
  };

  const onPointerMove = (e: ReactPointerEvent) => {
    if (!pointers.current.has(e.pointerId)) return;
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (pointers.current.size === 2 && gestureStart.current) {
      const [p1, p2] = Array.from(pointers.current.values());
      const distance = Math.hypot(p2.x - p1.x, p2.y - p1.y);
      const ratio = distance / (gestureStart.current.distance || 1);
      const nextScale = Math.min(MAX_SCALE, Math.max(MIN_SCALE, gestureStart.current.scale * ratio));
      setScale(nextScale);
      setTranslate(clampTranslate(gestureStart.current.translate, nextScale));
      return;
    }

    if (pointers.current.size === 1 && dragStart.current && scaleRef.current > MIN_SCALE) {
      const point = pointers.current.get(e.pointerId)!;
      const dx = point.x - dragStart.current.point.x;
      const dy = point.y - dragStart.current.point.y;
      setTranslate(
        clampTranslate(
          { x: dragStart.current.translate.x + dx, y: dragStart.current.translate.y + dy },
          scaleRef.current,
        ),
      );
    }
  };

  const onPointerUp = (e: ReactPointerEvent) => {
    const lastPoint = pointers.current.get(e.pointerId);
    pointers.current.delete(e.pointerId);
    if (pointers.current.size < 2) gestureStart.current = null;

    if (pointers.current.size === 0) {
      // Not zoomed in (so a horizontal drag isn't panning anything) and this
      // is a carousel: treat a wide-enough horizontal drag as a swipe to the
      // previous/next flyer instead of a no-op tap.
      if (isCarousel && scaleRef.current <= MIN_SCALE && dragStart.current && lastPoint) {
        const dx = lastPoint.x - dragStart.current.point.x;
        const dy = lastPoint.y - dragStart.current.point.y;
        if (Math.abs(dx) > SWIPE_THRESHOLD_PX && Math.abs(dx) > Math.abs(dy) * 1.5) {
          if (dx < 0) goNext();
          else goPrev();
        }
      }
      dragStart.current = null;
    }

    // Snap back below the minimum scale (can happen after a fast pinch-out).
    if (scaleRef.current < MIN_SCALE) resetTransform();
  };

  const onDoubleClick = (e: ReactMouseEvent) => {
    toggleZoom({ x: e.clientX, y: e.clientY });
  };

  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
      if (isCarousel && e.key === "ArrowRight") goNext();
      if (isCarousel && e.key === "ArrowLeft") goPrev();
    }
    window.addEventListener("keydown", onKeyDown);
    document.body.classList.add("drawer-open");
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      document.body.classList.remove("drawer-open");
    };
  }, [onClose, isCarousel, goNext, goPrev]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={current.alt}
      className="fixed inset-0 z-[60] bg-charcoal/95 flex flex-col"
      data-swipe-ignore
    >
      {/* Caption on top of the photo, always shown in full: it wraps onto
          as many lines as it needs (never truncated with "…"), and only
          scrolls inside its own box if it's extremely long, so the photo
          below always keeps most of the screen. */}
      <div className="flex flex-none items-start justify-between gap-3 px-4 pb-3 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <div className="min-w-0 max-h-[30vh] overflow-y-auto pr-1">
          <p className="break-words text-sm font-medium leading-snug text-white">{current.alt}</p>
          {isCarousel && (
            <p className="mt-0.5 text-xs text-white/60">
              {index + 1} / {gallery.length}
            </p>
          )}
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label={t("nav.close")}
          className="flex h-9 w-9 flex-none items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="M5 5l14 14M19 5 5 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>
      </div>

      <div
        ref={containerRef}
        className="relative flex-1 overflow-hidden touch-none select-none"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        onDoubleClick={onDoubleClick}
      >
        <img
          ref={imgRef}
          src={current.src}
          alt={current.alt}
          draggable={false}
          className="absolute left-1/2 top-1/2 max-h-full max-w-full"
          style={{
            transform: `translate(-50%, -50%) translate(${translate.x}px, ${translate.y}px) scale(${scale})`,
            transition: pointers.current.size > 0 ? "none" : "transform 150ms ease-out",
          }}
        />

        {isCarousel && (
          <>
            <button
              type="button"
              onClick={goPrev}
              aria-label={t("flyerZoom.prev")}
              className="absolute left-2 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M15 5l-7 7 7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
            <button
              type="button"
              onClick={goNext}
              aria-label={t("flyerZoom.next")}
              className="absolute right-2 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M9 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
          </>
        )}
      </div>

      <p className="flex-none text-center text-xs text-white/50 py-2">
        {isCarousel ? t("flyerZoom.hintCarousel") : t("flyerZoom.hint")}
      </p>
    </div>
  );
}
