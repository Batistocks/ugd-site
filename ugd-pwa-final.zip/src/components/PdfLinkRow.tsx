import { useState } from "react";
import PdfDossierModal from "./PdfDossierModal";

interface PdfLinkRowProps {
  href: string;
  label: string;
  /** Badge text, defaults to "PDF". */
  meta?: string;
}

/**
 * Row used for every standalone PDF the app links to (JMSAHub's
 * sponsoring dossier, MissionsTransparency's marketing dossier, …).
 * Same visual as the old `<a href download>` row, but tapping it opens
 * PdfDossierModal (the scrollable/zoomable/selectable reading space)
 * instead of silently downloading or handing off to the OS's PDF viewer —
 * a direct download link is still offered from inside that reading space.
 */
export default function PdfLinkRow({ href, label, meta = "PDF" }: PdfLinkRowProps) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="flex w-full items-center justify-between gap-3 rounded border border-slate-light px-3 py-2.5 text-left hover:bg-slate-light/40"
      >
        <span className="text-sm font-medium text-charcoal">{label}</span>
        <span className="flex-none rounded bg-ocean-deep/10 px-2 py-0.5 text-xs font-semibold text-ocean-deep">
          {meta}
        </span>
      </button>
      {open && <PdfDossierModal src={href} title={label} onClose={() => setOpen(false)} />}
    </>
  );
}
