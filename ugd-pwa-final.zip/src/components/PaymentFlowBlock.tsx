import { useEffect, useRef, useState } from "react";
import PaymentAccountsPanel from "./PaymentAccountsPanel";
import DonationProofForm from "./DonationProofForm";
import { useLanguage } from "../i18n/LanguageContext";

interface PaymentFlowBlockProps {
  /** "Vous sponsorisez : <b>Sponsor Or</b> — 1 500 €" line. */
  summary: React.ReactNode;
  /** One-line instruction shown above the form. */
  intro: string;
  presetAmount: string;
  presetContext: string;
  referencePrefix: string;
  whatsapp: { kind: "sponsoring" | "billetterie"; itemName: string };
}

/**
 * What opens when a sponsoring tier or a gala ticket is chosen: a short
 * summary, the payment accounts (collapsed behind one tap so they don't push
 * the form off screen) and the proof form.
 *
 * It scrolls itself into view the moment it appears, and the form sits
 * right under the summary line — the visitor sees the sheet to fill in
 * straight away, with no scrolling down to find it. The WhatsApp button is
 * NOT shown here: it appears inside the form's confirmation screen, after
 * the transfer has been reported (see DonationProofForm.tsx).
 */
export default function PaymentFlowBlock({
  summary,
  intro,
  presetAmount,
  presetContext,
  referencePrefix,
  whatsapp,
}: PaymentFlowBlockProps) {
  const { t } = useLanguage();
  const ref = useRef<HTMLDivElement>(null);
  const [accountsOpen, setAccountsOpen] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    // Wait one frame so the block has its final height before measuring.
    const id = requestAnimationFrame(() =>
      node.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" }),
    );
    return () => cancelAnimationFrame(id);
  }, []);

  return (
    <div ref={ref} className="mt-3 scroll-mt-2 rounded-card border border-ocean-deep/30 bg-white p-3.5">
      <p className="text-sm font-semibold text-charcoal">{summary}</p>
      <p className="mt-1 text-xs leading-relaxed text-charcoal/60">{intro}</p>

      <div className="mt-3 rounded-lg border border-slate-light">
        <button
          type="button"
          aria-expanded={accountsOpen}
          onClick={() => setAccountsOpen((o) => !o)}
          className="flex w-full items-center justify-between gap-2 px-3 py-2 text-left text-xs font-semibold text-ocean-deep"
        >
          {accountsOpen ? t("jmsa.hideAccounts") : t("jmsa.showAccounts")}
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            aria-hidden="true"
            className={`flex-none transition-transform ${accountsOpen ? "rotate-180" : ""}`}
          >
            <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        {accountsOpen && (
          <div className="border-t border-slate-light p-2.5">
            <PaymentAccountsPanel />
          </div>
        )}
      </div>

      <div className="mt-3 rounded-card bg-slate-light/60 p-3.5">
        <DonationProofForm
          presetAmount={presetAmount}
          presetContext={presetContext}
          referencePrefix={referencePrefix}
          whatsapp={whatsapp}
        />
      </div>
    </div>
  );
}
