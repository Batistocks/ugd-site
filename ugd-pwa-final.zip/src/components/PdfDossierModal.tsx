import { useEffect, useState } from "react";
import * as pdfjsLib from "pdfjs-dist";
import type { PDFDocumentProxy } from "pdfjs-dist";
import "../services/pdfWorker";
import { useLanguage } from "../i18n/LanguageContext";
import { useBackClose } from "../hooks/useBackClose";
import PdfPageZoomModal from "./PdfPageZoomModal";

interface PdfDossierModalProps {
  /** Path/URL to the PDF, served as-is -- never re-encoded or converted. */
  src: string;
  title: string;
  onClose: () => void;
}

type LoadState = "loading" | "ready" | "error";

/**
 * Fullscreen reading space for a standalone PDF document (a sponsoring
 * dossier, the marketing dossier, etc.). These are landscape slide decks,
 * so the reading experience is PdfPageZoomModal's one-slide-at-a-time
 * carousel (swipe/arrows, pinch-zoom, selectable text) rather than a
 * scrolled list of tiny thumbnails -- opened straight to page 1 as soon as
 * the document is loaded.
 */
export default function PdfDossierModal({ src, title, onClose }: PdfDossierModalProps) {
  const { t } = useLanguage();
  useBackClose(onClose);
  const [pdf, setPdf] = useState<PDFDocumentProxy | null>(null);
  const [numPages, setNumPages] = useState(0);
  const [state, setState] = useState<LoadState>("loading");

  useEffect(() => {
    let cancelled = false;
    setState("loading");
    const loadingTask = pdfjsLib.getDocument(src);
    loadingTask.promise
      .then((doc) => {
        if (cancelled) return;
        setPdf(doc);
        setNumPages(doc.numPages);
        setState("ready");
      })
      .catch(() => {
        if (!cancelled) setState("error");
      });
    return () => {
      cancelled = true;
      loadingTask.destroy();
    };
  }, [src]);

  if (state === "ready" && pdf) {
    return (
      <PdfPageZoomModal
        pdf={pdf}
        numPages={numPages}
        startPage={1}
        title={title}
        onClose={onClose}
        downloadHref={src}
      />
    );
  }

  return (
    <div role="dialog" aria-modal="true" aria-label={title} className="fixed inset-0 z-[55] flex flex-col bg-charcoal/95" data-swipe-ignore>
      <div className="flex flex-none items-center justify-between gap-3 px-4 py-3">
        <span className="min-w-0 truncate pr-3 text-sm text-white/80">{title}</span>
        <button
          type="button"
          onClick={onClose}
          aria-label={t("nav.close")}
          className="flex h-9 w-9 flex-none items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="M5 5l14 14M19 5 5 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>
      </div>

      <div className="flex flex-1 items-center justify-center px-4">
        {state === "loading" && (
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-white/30 border-t-white" />
        )}
        {state === "error" && (
          <div className="flex flex-col items-center gap-3 text-center">
            <p className="text-sm text-white/80">{t("founder.loadError")}</p>
            <a
              href={src}
              download
              className="rounded-full bg-white px-4 py-2 text-sm font-medium text-charcoal hover:bg-white/90"
            >
              {t("founder.download")}
            </a>
          </div>
        )}
      </div>
    </div>
  );
}
