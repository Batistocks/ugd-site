import { useEffect, useRef, useState } from "react";
import { useLanguage } from "../i18n/LanguageContext";

// Official UGD contact number (from the organisation's dossiers). Exported
// so other flows that should also end up on WhatsApp (e.g. the badge
// registration success screen, see PassRequestForm.tsx) reuse the exact
// same number instead of a second hardcoded copy.
export const WHATSAPP_NUMBER = "32472285039";

const BUTTON_SIZE = 56; // h-14 / w-14
const EDGE_MARGIN = 8;
const DRAG_THRESHOLD = 6; // px of movement before a tap becomes a drag
const STORAGE_KEY = "ugd-whatsapp-btn-pos";

interface Point {
  x: number;
  y: number;
}

function clamp(value: number, min: number, max: number) {
  return Math.min(Math.max(value, min), max);
}

/** Keeps a saved position inside the current viewport (e.g. after rotation/resize). */
function clampToViewport(pos: Point): Point {
  const maxX = window.innerWidth - BUTTON_SIZE - EDGE_MARGIN;
  const maxY = window.innerHeight - BUTTON_SIZE - EDGE_MARGIN;
  return {
    x: clamp(pos.x, EDGE_MARGIN, Math.max(EDGE_MARGIN, maxX)),
    y: clamp(pos.y, EDGE_MARGIN, Math.max(EDGE_MARGIN, maxY)),
  };
}

/**
 * Floating WhatsApp Support Button.
 * Defaults to bottom-right, above the mobile tab bar / safe area — but any
 * visitor can drag it anywhere on screen. The chosen spot is remembered
 * (per device, via localStorage) for their next visit.
 * Section 1: Header Navigation.
 */
export default function WhatsAppButton() {
  const { t } = useLanguage();
  const defaultMessage = encodeURIComponent(t("whatsapp.defaultMessage"));
  const linkRef = useRef<HTMLAnchorElement>(null);

  const [pos, setPos] = useState<Point | null>(null);
  const draggingRef = useRef(false);
  const movedRef = useRef(false);
  const startRef = useRef<{ pointer: Point; origin: Point }>({
    pointer: { x: 0, y: 0 },
    origin: { x: 0, y: 0 },
  });

  // Restore a previously saved position, clamped in case the viewport changed size.
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        setPos(clampToViewport(JSON.parse(saved)));
      }
    } catch {
      // Corrupt/blocked storage — just fall back to the default corner.
    }
  }, []);

  useEffect(() => {
    function handleResize() {
      setPos((prev) => (prev ? clampToViewport(prev) : prev));
    }
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  function handlePointerDown(e: React.PointerEvent<HTMLAnchorElement>) {
    const el = linkRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    draggingRef.current = true;
    movedRef.current = false;
    startRef.current = {
      pointer: { x: e.clientX, y: e.clientY },
      origin: { x: rect.left, y: rect.top },
    };
    el.setPointerCapture(e.pointerId);
  }

  function handlePointerMove(e: React.PointerEvent<HTMLAnchorElement>) {
    if (!draggingRef.current) return;
    const dx = e.clientX - startRef.current.pointer.x;
    const dy = e.clientY - startRef.current.pointer.y;
    if (!movedRef.current && Math.hypot(dx, dy) < DRAG_THRESHOLD) return;
    movedRef.current = true;
    setPos(
      clampToViewport({
        x: startRef.current.origin.x + dx,
        y: startRef.current.origin.y + dy,
      })
    );
  }

  function handlePointerUp(e: React.PointerEvent<HTMLAnchorElement>) {
    if (!draggingRef.current) return;
    draggingRef.current = false;
    linkRef.current?.releasePointerCapture(e.pointerId);
    if (movedRef.current) {
      // It was a drag, not a tap — don't follow the WhatsApp link, just save the spot.
      e.preventDefault();
      setPos((current) => {
        if (current) {
          try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(current));
          } catch {
            // Ignore storage failures — position just won't persist.
          }
        }
        return current;
      });
    }
  }

  const draggedStyle: React.CSSProperties = pos
    ? { left: pos.x, top: pos.y, right: "auto", bottom: "auto" }
    : { bottom: "calc(1rem + env(safe-area-inset-bottom))" };

  return (
    <a
      ref={linkRef}
      href={`https://wa.me/${WHATSAPP_NUMBER}?text=${defaultMessage}`}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={t("whatsapp.label")}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      className={`fixed z-40 flex h-14 w-14 items-center justify-center rounded-full bg-whatsapp text-white shadow-lg shadow-whatsapp/30 transition-transform hover:scale-105 active:scale-95 ${
        pos ? "" : "right-4"
      }`}
      style={{ ...draggedStyle, touchAction: "none", userSelect: "none" }}
    >
      <svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
        <path d="M12 2C6.48 2 2 6.48 2 12c0 1.85.5 3.58 1.36 5.07L2 22l5.1-1.33A9.94 9.94 0 0 0 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2Zm0 18c-1.6 0-3.1-.44-4.39-1.2l-.31-.19-3.02.79.8-2.94-.2-.31A7.94 7.94 0 0 1 4 12c0-4.41 3.59-8 8-8s8 3.59 8 8-3.59 8-8 8Zm4.36-5.98c-.24-.12-1.43-.7-1.65-.78-.22-.08-.38-.12-.54.12-.16.24-.62.78-.76.94-.14.16-.28.18-.52.06-.24-.12-1.01-.37-1.92-1.18-.71-.63-1.19-1.41-1.33-1.65-.14-.24-.01-.37.11-.49.11-.11.24-.28.36-.42.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.54-1.3-.74-1.78-.19-.46-.39-.4-.54-.4-.14 0-.3-.02-.46-.02-.16 0-.42.06-.64.3-.22.24-.84.82-.84 2s.86 2.32.98 2.48c.12.16 1.7 2.6 4.12 3.65.58.25 1.03.4 1.38.51.58.18 1.11.16 1.53.1.47-.07 1.43-.58 1.63-1.15.2-.57.2-1.05.14-1.15-.06-.1-.22-.16-.46-.28Z" />
      </svg>
    </a>
  );
}
