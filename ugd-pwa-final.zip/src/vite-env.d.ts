/// <reference types="vite/client" />
/// <reference types="vite-plugin-pwa/client" />

// Section 5 — QRScannerModal.tsx: the Shape Detection API's BarcodeDetector
// is not yet part of TypeScript's built-in DOM lib. Minimal ambient typing
// so the QR badge scanner compiles; feature-detected at runtime via
// `"BarcodeDetector" in window` before use.
interface DetectedBarcode {
  rawValue: string;
}

interface BarcodeDetectorOptions {
  formats?: string[];
}

declare class BarcodeDetector {
  constructor(options?: BarcodeDetectorOptions);
  detect(source: CanvasImageSource): Promise<DetectedBarcode[]>;
}
