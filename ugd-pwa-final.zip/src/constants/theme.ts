// UGD Design System — Section 1
// Single source of truth for brand colors, referenced by Tailwind config
// and by any component that needs a raw hex value (inline SVG, canvas, etc).

export const colors = {
  primary: "#155D8B",
  primaryAlt: "#3B8FC7",
  secondary: "#2F6B57",
  secondaryAlt: "#1F4A3C",
  accent: "#B89B55",
  accentAlt: "#9C8144",
  charcoal: "#24313A",
  white: "#FCFCFA",
  slateLight: "#EEF1F0",
} as const;

export const brand = {
  name: "UGD",
  fullName: "Un Geste Divin",
  legalName: "AISBL UN GESTE DIVIN",
  tagline: "Unis pour un monde plus juste et plus sûr",
} as const;

export type ThemeColors = typeof colors;
