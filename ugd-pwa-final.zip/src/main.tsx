import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";

// Registered by vite-plugin-pwa; auto-updates the service worker in the
// background and reloads once a new version has taken control.
// See Section 2: PWA Core & Offline-First Infrastructure.
import { registerSW } from "virtual:pwa-register";

registerSW({
  immediate: true,
  // `registerType: "autoUpdate"` (vite.config.ts) already reloads the
  // page as soon as a newly-deployed service worker takes control — but
  // the browser only *checks* for a new one on its own once every 24h,
  // or right when this line runs. Someone who leaves the app open for
  // hours (a booth volunteer, an admin doing entries all afternoon)
  // would otherwise not see today's deploy until they fully close and
  // reopen the tab. Forcing a manual check every 20 minutes closes that
  // gap without needing GitHub-based deploy hooks or anything server-side.
  onRegisteredSW(_swUrl, registration) {
    if (!registration) return;
    setInterval(() => {
      registration.update();
    }, 20 * 60 * 1000);
  },
});

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
