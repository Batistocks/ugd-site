import { useCallback, useState } from "react";

/**
 * Copies text to the clipboard and exposes a short-lived `copiedId` flag
 * so a "Copy number" button can show a confirmation ("Copié !") without
 * needing its own local state everywhere it's used.
 */
export function useClipboard(resetAfterMs = 2000) {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copy = useCallback(
    async (id: string, text: string) => {
      try {
        await navigator.clipboard.writeText(text);
      } catch {
        // Fallback for browsers without Clipboard API permission (e.g. some
        // in-app webviews): use a hidden textarea + execCommand.
        const textarea = document.createElement("textarea");
        textarea.value = text;
        textarea.style.position = "fixed";
        textarea.style.opacity = "0";
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand("copy");
        document.body.removeChild(textarea);
      }
      setCopiedId(id);
      window.setTimeout(() => setCopiedId((current) => (current === id ? null : current)), resetAfterMs);
    },
    [resetAfterMs],
  );

  return { copy, copiedId };
}
