import { useRef } from "react";

/**
 * Secret Trigger — Section 5: Secret Admin Panel & CMS Management.
 *
 * Detects a triple-tap / triple-click within 800ms anywhere on the element
 * it's attached to (the footer area, per the spec) and calls `onTrigger`.
 * Works for both mouse clicks and touch taps since both fire a `click`
 * event on mobile browsers.
 */
export function useTripleClick(onTrigger: () => void, windowMs = 800) {
  const clicksRef = useRef<number[]>([]);

  function handleClick() {
    const now = Date.now();
    const recent = clicksRef.current.filter((t) => now - t < windowMs);
    recent.push(now);
    clicksRef.current = recent;
    if (recent.length >= 3) {
      clicksRef.current = [];
      onTrigger();
    }
  }

  return { onClick: handleClick };
}
