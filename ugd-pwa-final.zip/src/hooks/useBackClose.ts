import { useEffect, useRef } from "react";

let overlaySeq = 0;

/**
 * Makes the phone's Back button (or the browser's Back button on a
 * computer) close the overlay that is currently open — a photo/video
 * viewer, the registration screen, a PDF zoom — instead of leaving the
 * whole site. Call it inside a component that is only mounted while the
 * overlay is open.
 *
 * How: on open it pushes one history entry tagged with a token. If the
 * visitor presses Back, that entry is popped and `onClose` runs. If the
 * overlay is closed another way (✕ button, Escape, tapping outside), the
 * entry it pushed is removed again with `history.back()` so Back doesn't
 * need an extra press afterwards.
 *
 * React StrictMode (dev only) mounts effects twice in a row; the `live`
 * ref plus a deferred cleanup keep that from popping the entry by mistake.
 */
export function useBackClose(onClose: () => void): void {
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  const tokenRef = useRef<number | null>(null);
  const liveRef = useRef(false);
  const closedByPopRef = useRef(false);

  useEffect(() => {
    liveRef.current = true;

    if (tokenRef.current === null) {
      tokenRef.current = ++overlaySeq;
      window.history.pushState({ ...(window.history.state ?? {}), __overlay: tokenRef.current }, "");
    }
    const token = tokenRef.current;

    function onPopState() {
      // Still sitting on our own entry (e.g. a nested overlay on top of us
      // was just popped) — nothing to do. Otherwise we've gone back past it.
      if (window.history.state?.__overlay === token) return;
      closedByPopRef.current = true;
      onCloseRef.current();
    }
    window.addEventListener("popstate", onPopState);

    return () => {
      liveRef.current = false;
      window.removeEventListener("popstate", onPopState);
      setTimeout(() => {
        if (liveRef.current || closedByPopRef.current) return;
        if (window.history.state?.__overlay === token) window.history.back();
      }, 0);
    };
  }, []);
}
